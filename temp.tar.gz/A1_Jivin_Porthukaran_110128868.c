#define _XOPEN_SOURCE 500
#include <stdint.h>
#include <ftw.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>

char *target;
int found = 0;
int flag3=0;//for argument 3 when i have to print all files 
char *sourcefilepath;
#define MAX_PATHS 1000
char *filePaths[MAX_PATHS]; 
int numPaths = 0;
char *filenames[MAX_PATHS];
int counter=0;
#define MAX_TOKENS 100 // Maximum number of tokens
char *tokens[MAX_TOKENS];
int numTokens;


// NFTW callback function to check filepaths matching with target file 
int nftwCallbackFunction(const char *fpath, const struct stat *sb, int typeflag, struct FTW *ftwbuf) {
    // Extract file name after last '/'
    const char *filename = strrchr(fpath, '/');

    if (filename == NULL) 
    {
        // use whole path as filename if no '/' 
        filename = fpath;
    } 
    else 
    {
        // skip / by moving  a character ahead
        filename++;
    }

    // Check if the current filename matches the target filename
    if (strcmp(filename, target) == 0) 
    {   
        if(flag3 == 1){
        printf("%s\n", fpath);
        }
        if(flag3 == 5){
        printf("Search Successful\n");
        }
        
        // copying filepath to global variable to use later
        size_t fpathLength = strlen(fpath);
        sourcefilepath = (char *)malloc(fpathLength + 1); //+1
        strcpy(sourcefilepath, fpath);

        found=1;

        return 1;
        
    }

    // continue traversal
    return 0;
}

int callNftwToFindFilePath(char *path, char *val){
        if(strcmp(val,"") != 0){
            flag3=0;
        }
        int result = nftw(path, nftwCallbackFunction, 20, FTW_DEPTH);

        if (result == -1)
        {
            if (strcmp(val,"root") == 0)
            {
                printf("Invalid root_directory\n");
            }
            if (strcmp(val,"storage") == 0)
            {
                printf("Invalid storage_directory\n");
            }
            exit(0);
            
        }
        // if file not found 
        if (found==0)
        {
            printf("Search Unsuccessful\n");
            exit(0);
        }
}

int copyfile(char *storage_dir){
    char *runcopy;

    asprintf(&runcopy, "cp %s %s", sourcefilepath, storage_dir);
    // execute command
    int flag = system(runcopy);
    free(runcopy);

    if (flag == 0) {
        printf("File copied to the storage_dir\n");
    } else {
        fprintf(stderr, "file not copied\n");
    }
}

int movefile(char *storage_dir){
    char *runmove;
    asprintf(&runmove, "mv %s %s", sourcefilepath, storage_dir);
    // execute command
    int flag = system(runmove);
    free(runmove);

    if (flag == 0) {
        printf("File moved to storage_dir\n");
    } else {
        fprintf(stderr, "file not found\n");
    }
}

// helper function to append slash at end of the string 
char* addSlash(const char* path) {
    char* newpath = (char*)malloc(strlen(path) + 2);
    strcpy(newpath, path);
    int len = strlen(newpath);
    if (newpath[len - 1] != '/') 
    {
        strcat(newpath, "/");
    }
    return newpath;
}

// check if extension exists
int hasExtension(const char *filename, const char *extension) {
    const char *dot = strrchr(filename, '.'); // Find the last '.' in the filename
    if (dot != NULL && strcmp(dot, extension) == 0) {
        return 1; // Extension found
    }
    return 0; // Extension not found
}

int filenameExists(char *filename) {
    for (int i = 0; i < counter; i++) {
        if (strcmp(filename, filenames[i]) == 0) {
            return 1; // return 1 if filename exist in array
        }
    }
    return 0; // return 0 if filename exist in array
}

// nftw callback function in argc =4 to check if file has extensioton and to take unique paths
int callback(const char *fpath, const struct stat *sb, int typeflag, struct FTW *ftwbuf) {
    if (typeflag == FTW_F) { // Check if it's a regular file
        const char *filename = strrchr(fpath, '/');
        if (filename == NULL) {
            filename = fpath; // use whole path as filename if no '/' 
        } else {
            filename++; // skip / by moving  a character ahead
        }

        if (hasExtension(filename, target)) {
            if (filenameExists(filename)==0)
            {
                filePaths[numPaths] = strdup(fpath);
                numPaths++;
            }                     
            filenames[counter] = strdup(filename);
            counter++;  
        }
    }
    return 0; //continue to traverse
}

// CREATE DIRECTORY IF DIRECTORY NOT PRESENT
int tokenizeString(const char *str) 
{
    // Create a copy of the input string to avoid modifying the original
    char *strCopy = strdup(str);

    char *token = strtok(strCopy, "/");
    int count = 0;
    while (token != NULL && count < MAX_TOKENS) {
        tokens[count++] = strdup(token);
        token = strtok(NULL, "/");
        
    }

    free(strCopy);

    return count;
}

int callback2(const char *fpath, const struct stat *sb, int typeflag, struct FTW *ftwbuf) {
    return 1;
}

int isvalid(char *intermediatepath){ 
    if (nftw(intermediatepath, callback2, 20, FTW_DEPTH)!=-1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

// Function to make directories given a path and directory name
int makeDirectories(char *path)
{
    int status = mkdir(path, 0777);
    if (status == -1) {

        return 0; // if directory not created
    }
    return 1; // if directory created
}

void constructPaths()
{
    char path[MAX_TOKENS * (MAX_TOKENS + 1)];
    if((tokens[0][0] == 'h')){
    path[0] = '/';
    }
    for (int i = 0; i < numTokens; i++) {
        strcat(path, tokens[i]); 
        strcat(path, "/"); 
        if (!isvalid(path))
        {
            makeDirectories(path);
        }    
    }
}


char* concatenateStrings(const char *str1, const char *str2) {
    char *concatenated = malloc(strlen(str1) + strlen(str2) + 1);
    strcpy(concatenated, str1);
    strcat(concatenated, str2);
    return (concatenated);
}

char * printStrings(const char *strings[]) {
    char *string = "";
    char *temp1=NULL;
    for (int i = 0; i < numPaths; i++) {
            temp1=strdup(strings[i]);
            if(strlen(temp1) > 1 && temp1[1] == 'h'){
            memmove(temp1, temp1 + 1, strlen(temp1));
        }
        char *temp = concatenateStrings(string, temp1);
        string = temp;
        char *temp2 = concatenateStrings(string, " ");
        string = temp2;
    }
    return string;
}

void createTheTar(char * destination){
    char * temp;
    asprintf(&temp, "tar -cvf %s/a1.tar -C / %s", destination, printStrings((filePaths)));
    system(temp);
}


int main(int argc, char *argv[]) {
    int result;
    //part 1 printf file and extracting source file path into a global varaible called source filepath
    if (argc == 3) 
    {   
        // fileutil [root_dir]  filename
        //   0            1           2  
        flag3=1;
        char *path = addSlash(argv[1]);
        target = argv[2];
        callNftwToFindFilePath(path,"");
    }

    else if(argc == 5)
    {
        // fileutil [root_dir] [storage_dir] [options] filename
        //   0            1           2           3       4
        char *path =  addSlash(argv[1]);
        target = argv[4];
        char *options=argv[3];
        char *storage_dir=addSlash(argv[2]);
        
        // check if valid root_dir
        callNftwToFindFilePath(path,"root");
        
        // check if valid storage_dir
        callNftwToFindFilePath(storage_dir,"storage");

        //find path and store in sourcefilepath
        flag3 = 5;
        callNftwToFindFilePath(path,"");
        
        if (strcmp(options,"-cp")==0)
        {   
            copyfile(storage_dir);
            
        }
        else if (strcmp(options,"-mv")==0)
        {
            movefile(storage_dir);
        }
        
        else{
            fprintf(stderr, " error: to move/copy a file -> Usage: %s [root_dir] [storage_dir] [options] filename\n options: copy: <-cp> move :<-mv> \n", argv[0]);
        }
    }
    else if (argc == 4) //tar file
    {
        // fileutil [root_dir] [storage_dir] extension
        //   0            1           2           3
        char *path = argv[1];
        char *storage_dir=argv[2];
        target=argv[3];
        int result = nftw(path, callback, 20, FTW_DEPTH);
        if (result == -1) {
            perror("nftw");
            return 1;
        }

        numTokens = tokenizeString(storage_dir);
        constructPaths();
         createTheTar(storage_dir);

        return 0;
    }
    else{
        fprintf(stderr, " to find a file -> Usage: %s [ root_dir] filename \n", argv[0]);
        fprintf(stderr, " to move/copy a file -> Usage: %s [root_dir] [storage_dir] [options] filename\n", argv[0]);
        fprintf(stderr, " to find a file -> Usage: %s  [root_dir] [storage_dir] [options] filename\n", argv[0]);
        return 1;
    }
    return 0;
}
