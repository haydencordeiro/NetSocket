#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<unistd.h>

int main(){
    umask(0000);
    int fd=open("check.txt",O_CREAT|O_RDWR,0700);
    if (fd==-1)//error handling if file created successfully
    {
        printf("file couldnt be created successfully");
        return 0;
    }
    // create a string
    char* string;
    string="COMP 8567";

    // writing two times
    int w =write(fd,string,9);
    w=write(fd,string,9);
    printf("value printed 2 times: length will be 18\n");

    close(fd);

    // wrriting two times  after seek cur
    fd=open("check.txt",O_RDWR);
    
    int offset= lseek(fd,50,SEEK_CUR);
    w=write(fd,string,9);
    w=write(fd,string,9);
    close(fd);
    printf("length of entire string will be  68 at this point\n");

    // write once after seek end
    fd=open("check.txt",O_RDWR);

    offset= lseek(fd,12,SEEK_END);
    w=write(fd,string,9);
    printf("length of entire string will be  89 at this point\n");

    // write into a list  by reading all values into a list
    char list[89];
    offset=lseek(fd,0,SEEK_SET);

    printf("offset %d \n",offset);

    int reading=read(fd,list,87);

// checking for null characters and replacing.
    for (int i = 0; i < 87; i++)
    {   
        if (list[i]=='\0')
        {
            list[i]='$';
        }
    }
    // setting pointer at the start of the file using seek set to overwrite
    offset=lseek(fd,0,SEEK_SET);
    w=write(fd,list,87);
    close(fd);
    
    return 0;
}