#include<stdio.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
int main(){
// set umask to 0000 to get desired permission of ile	
umask(0000);
// create and open file in 0744 permission
int sfd = open("sample.txt",O_CREAT|O_RDWR,0744);
if(sfd==-1){
	// error habdling 
	printf("unable to create file");
}else{
	// ptr to univ of windsor
	char *ptr = "Univ of Windsor";
	//write operation 3 concecutive times.
	int n = write(sfd,ptr, sizeof(ptr));
	n = write(sfd,ptr, sizeof(ptr));
	n = write(sfd,ptr, sizeof(ptr));
	//close file
	close(sfd);

	//open file again in read write mode
	int ofd = open("sample.txt", O_RDWR);
	if(ofd==-1){
		printf("Unable to open file");
	}else{
		int noffset = lseek(ofd,10,SEEK_END);
		n = write(sfd,ptr, sizeof(ptr));
		n = write(sfd,ptr, sizeof(ptr));
		// check the offset after SEEK_END
		noffset = lseek(ofd,10,SEEK_CUR);
        n = write(sfd,ptr, sizeof(ptr));
        n = write(sfd,ptr, sizeof(ptr));
		char readarray[76];
	
                noffset = lseek(ofd,0,SEEK_SET);
		n =  read(ofd,readarray,76);
	//	printf("\n %s \n",readarray);		
		
		for(int i=0;i<76;i++){
			// check if the character is null then replace it with #
		if(readarray[i]=='\0'){
			readarray[i]='#';
		}
		}
	//	printf("\n %s \n",readarray);		
	
		noffset = lseek(ofd,0,SEEK_SET);
		n = write(ofd, readarray,sizeof(readarray));
		// close ofd
		close(ofd);

	
	}
}

return 0;
}
