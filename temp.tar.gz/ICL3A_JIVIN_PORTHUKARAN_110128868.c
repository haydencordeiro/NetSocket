#include<stdio.h>
#include<unistd.h>

int main(){

//three consecutive system calls;
int p1 = fork();
int p2 = fork();
int p3 = fork();

if(p1==-1)
{
printf("Unable to fork");
}

//third level: other than direct descendants 
if((p1==0 && p2==0 && p3>0) ||(p1==0 &&  p2==0 && p3==0) || (p1>0 && p2==0 && p3==0) || (p1==0 && p2>0 && p3==0))
{
 printf("PID : %d PPID : %d\n", getpid(),getppid());
}

return 0;

}

