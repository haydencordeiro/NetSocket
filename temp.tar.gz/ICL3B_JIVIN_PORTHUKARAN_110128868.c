#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<stdlib.h>

int main(){
    int p1=fork();
    if (p1==-1)
    {
        printf("unable to fork");
    }else if (p1==0)
    {
        // child processes
        int val;
        printf("Enter 1 for normal exit\n");
        printf("Enter 2 for exit(0) \n");
        printf("enter 3 for exit with interval \n");
        scanf("%d",&val);
        if (val==1)
        {
            printf(" child PID : %d PPID : %d\n", getpid(),getppid());
        }
        else if (val==2)
        {
            printf("  child  PID : %d PPID : %d\n", getpid(),getppid());
            exit(0);
        }
        else if (val==3)
        {
            for (int i = 0; i < 3; i++)
            {
                printf( " child  PID : %d PPID : %d\n", getpid(),getppid());
                sleep(1);
                
            }
            int num=num/0;
        }
    }
    else
    {
        // parent
        int status;
        int childrenid = wait(&status);
        if(WIFEXITED(status))
        {
            // normal
            printf("child terminated normally with  PID %d and return value is %d \n", childrenid,WEXITSTATUS(status));
        }
        else
        {
        //abnormal
            printf("child terminated abnormally with PID %d and signal value is %d \n", childrenid, WTERMSIG(status));
        }
    }
      
     
    return 0;
}