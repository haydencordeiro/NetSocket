#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>

int main(){
    int p1;
    int p2;
    int p3;

    p1 = fork();
    p2 = fork();
    p3 = fork();


    if(p1 > 0 && p2 > 0 && p3 > 0)
    {   
        // parent execution
        printf("Parent waiting for child 3: \n");
        int status;

        int child_process_id=waitpid(p3, &status, 0);
        
        if(WIFEXITED(status))
        {
			printf("\n Normal termination of child 3 with process id :%d and exit status:  %d", child_process_id, WEXITSTATUS(status));
		}
        else
        {
			printf("\n Abnormal termination of child 3 with process id :%d and exit status:  %d", child_process_id,WTERMSIG(status));
		}
    }
    else if(p1 > 0 && p2 > 0 && p3 == 0)
    {
        // third child execution
        printf("Third Child executing\n"); 

        // changing directory to specified path 
        
        if (chdir("/home/jivin/chapter5/child3")==-1)
        {
            printf("unable to change directory");
        }
        else
        {
            // execvp execution
            char *program = "ls";
            char *args[] = {"ls","-1","/home/jivin/chapter5/child3",NULL};

            int ex = execvp(program,args);
        
            if(ex == -1){
                printf("\n execution failed for excevp system call \n");
            }
        }


    }

}