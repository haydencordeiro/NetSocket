#include <stdio.h>
#include <stdlib.h>
#include <sys/signal.h>

int six_secondpass = 0;
void alarmhandler(int signo)
{
    six_secondpass = 2;
}

void siginhandler(int signo)
{
    if (six_secondpass == 0)
    {
        six_secondpass = 1;
        alarm(6);
    }
    else if(six_secondpass == 1){
        // ctrl c
        exit(0);
    }
    else if(six_secondpass == 2){
        // ctrl z
        kill(getpid(), SIGSTOP);
    }

}

int main(int argc, char *argv[])
{
    signal(SIGALRM, alarmhandler);
    signal(SIGINT, siginhandler);
    while (1)
    {
        printf("Only One CTR-C does not work on this program\n");
        sleep(1);
    }
}