#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

int main()
{
    int pipe1[2];
    int child2,child1;
    if (pipe(pipe1) == -1)
    {
        printf("error creating pipe");
        exit(0);
    }

    child1=fork();
    if (child1>0)//parent
    {
        close(pipe1[0]);//close read
        dup2(pipe1[1],1);//write into pipe
        execlp("ls", "ls", "-1", "-t", NULL);// redirecting output to pipe1
    }
    if (child1==0)
    {
        // child1
        close(pipe1[1]);//close write since reading only
                        
            int pipe2[2];// create  a pipe from child1
            if (pipe(pipe2)==-1)
            {
                printf("error creating pipe2");
                exit(0);
            }
            child2=fork();// create a child 2 for piping
            if (child2>0)
            {
                //child1 is parent of child 2
                close(pipe2[0]);//close read since i have to write
                dup2(pipe1[0],0);// read input from pipe 1
                dup2(pipe2[1],1);//write into pipe2
                execlp("grep","grep",".c",NULL);

            }
            else{
                // child2
                close(pipe2[1]); //closing write since only reading
                dup2(pipe2[0],0);
                int filedescriptor = open("output.txt", O_CREAT|O_RDWR, 0777);
                dup2(filedescriptor, 1);//redirecting output of pipe to output.txt
                execlp("wc","wc",NULL);

            }                                   
                                     
    }    
    return 0;
    
}