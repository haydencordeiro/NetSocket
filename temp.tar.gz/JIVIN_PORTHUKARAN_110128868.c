#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/signal.h>
#include <sys/types.h>


int flag = 1;

int parentPPID;
// handle ctrl c
void sigIntHandler()
{
    flag = 0;
    // send SIGCHLD to entire group
    kill(-parentPPID, SIGCHLD);
}

// Set Flag to 0
void flagHandler()
{
    flag = 0;
}

void sigStop(pid)
{
    kill(pid, SIGSTOP);
}

void sigCont(pid){
    kill(pid, SIGCONT);
}

int main()
{
    parentPPID = getppid();
    int parentPID = getpid();
    int child1 = fork();
    int child2 = fork();

    // grandchild  
    if (child1 == 0 && child2 == 0)
    {
        signal(SIGINT, sigIntHandler);
        // set group id
        setpgid(0, parentPID);
    }
    else
    {
        // child2
        signal(SIGCHLD, flagHandler);
        setpgid(0, parentPPID);
    }

    while (flag == 1)
    {
        printf("From process (%d)\n", getpid());
        sleep(2);
    }
    if (child1 == 0 && child2 > 0)
    {
        // Stop Child1
        sigStop(getpid());
        while (1)
        {
            printf("\nFrom process (%d)", getpid());
            sleep(2);
            sigCont(parentPID);
            // Pause Child1
            sigStop(getpid());
        }
    }

        if (child1 > 0 && child2 == 0)
    {

        while (1)
        {
            printf("\nFrom process (%d)", getpid());
            sleep(2);
            sigCont(parentPID);
            // Pause child2
            sigStop(getpid());
        }
    }

    if (child1 > 0 && child2 > 0)
    {

        while (1)
        {
            // pause parent
            kill(parentPID, SIGSTOP);
            printf("\nFrom process (%d)", getpid());
            sleep(2);
            // Continue Child 1
            sigCont(child1);
            // Pause Parent
            sigStop(getpid());
            // continue child2
            sigCont(child2);
        }
    }
    return 0;
}