#include<stdio.h>
#include<pthread.h>

// initialize the lock
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

// declare global variable
int num=10;

// pointer to function that accepts generic pointer
void * decrement(void * arg){
	// put a lock
	pthread_mutex_lock(&lock);
	// prints thread id and decrement num by one if it is joinable mode 
	if(*(int *) arg == PTHREAD_CREATE_JOINABLE){
		printf("\n Thread id %lu and value of n is %d ",pthread_self(),--num);
	}
	// release lock
	pthread_mutex_unlock(&lock);
	return NULL;
}
int main(){
	// threads array
	pthread_t threads[10];
	// detach array
	int d[10];

	for(int i=0;i<10;i++){
		//declare and initialize thread attribute
		pthread_attr_t attr;
		pthread_attr_init(&attr);
	
		if(i%2==0){
			d[i] = PTHREAD_CREATE_DETACHED;
 		}else {
			d[i] = PTHREAD_CREATE_JOINABLE;
		}
		// create a thread in joinable and detached state
		pthread_attr_setdetachstate(&attr,d[i]);
		// create a thread
		pthread_create(&threads[i],&attr,decrement,(d+i));
		// destory thread attribute
		pthread_attr_destroy(&attr);
	}

	for(int i=0;i<10;i++){
		// wait for the thread if it is created in joinable state
		if(d[i] == PTHREAD_CREATE_JOINABLE)
			pthread_join(threads[i],NULL);
	}
	// the final value of num 
	printf("\n the value num of %d ", num);
}
