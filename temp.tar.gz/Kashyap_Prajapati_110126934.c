#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>
#include<sys/wait.h>

int main(){
//two pipes to implement command
int fdpipe1[2],fdpipe2[2];
int a,b;

if(pipe(fdpipe1)==-1){
	printf("Error while executing the pipe 1 \n");
	exit(EXIT_FAILURE);
}

if(pipe(fdpipe2)==-1){
	printf("Error while executing the pipe 2\n");
	exit(EXIT_FAILURE);
}

a=fork(); // first fork
if(a==-1){
	printf(" Error while executing the fork 1");
	exit(EXIT_FAILURE);
}

if(a==0){
	// output redirection to  pipe 1
	dup2(fdpipe1[1],1);
	close(fdpipe1[0]); // close read end
	close(fdpipe1[1]); // close write end
	execlp("cat","cat","w24.txt",NULL); // execute commands
	exit(0);
}

b=fork(); // second fork

if(b==-1){
	printf(" Error while executing the fork 2");
	exit(EXIT_FAILURE);
}
if(b==0){
	dup2(fdpipe1[0],0); // get input from pipe 1
	close(fdpipe1[0]); // close read end
	close(fdpipe1[1]); // close write end

	dup2(fdpipe2[1],1); // output redirection to pipe 2
	close(fdpipe2[0]); //close read end
	close(fdpipe2[1]); // close  write end
	execlp("grep","grep","01234",NULL); // execute command
	exit(0);
}

close(fdpipe1[0]);
close(fdpipe1[1]);
close(fdpipe2[1]);


int c=fork(); // third fork
	
if(c==-1){
	printf(" Error while executing the fork 3");
	exit(EXIT_FAILURE);
}

if(c==0){
	
	dup2(fdpipe2[0],0); // get input from pipe 2
	close(fdpipe2[0]); // close read end
	close(fdpipe2[1]); // close write end
	execlp("wc","wc",NULL); // execute the command
	exit(0);
}
// main process started here
close(fdpipe1[0]);
close(fdpipe1[1]);
close(fdpipe2[0]);
close(fdpipe2[1]);

wait(NULL); // wait for any child process
wait(NULL); // wait for any child process
wait(NULL); // wait for any child process
return 0;

}
