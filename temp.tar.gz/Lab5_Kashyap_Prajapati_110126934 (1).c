#include<stdio.h>
#include<sys/wait.h>
#include<stdlib.h>

// global variable to check ctr-c is pressed or not
int press = 0 ;
// Handler for alarm
void alarmHandler(int signo){
	press=0;
}

// Handler for ctr-c
void sigintHandler(int signo){
	if(press==0){
		// if it is pressed first time make it toggle
		press=1;
		alarm(6);
	}else{
		// if it is pressed second time withing 5 seconds call exit.
		exit(0);
	}
}

int main(){
	//register the handler for when user press CTR-C 
	signal(SIGINT,sigintHandler);
	//register the handler for  alrm handler
	signal(SIGALRM,alarmHandler);
	//infinite loop printing only on ctr-c does not work on this program
	while(1==1){
		printf("Only one CTR-C does not work on this program\n");
		sleep(1);
	}

}
