#include <stdio.h>  // Importing the standard input/output library
#include <pthread.h>  // Importing the pthread library for creating and manipulating threads

#define NUM_THREADS 5  // Defining the number of threads

// Initializing the shared variable 'num' with a value of 10
// This variable will be accessed and modified by multiple threads
int num = 10;

// Initializing the mutex lock 'mutex'
// This will be used to synchronize access to the shared variable 'num'
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

// Function: decrement
// This function is used as the thread routine for both joinable and detached threads.
// It decrements the shared variable 'num' after acquiring the mutex lock.
// The thread ID and the updated value of 'num' are printed to the console.
void* decrement(void* arg) {
    // Storing the current thread ID
    pthread_t tid = pthread_self();

    // Storing the joinable state of the current thread as an integer value
    int joinable = *((int*)arg);

    // If the current thread is joinable, acquire the mutex lock
    if (joinable) {
        pthread_mutex_lock(&mutex);

        // Decrement the shared variable 'num'
        num--;

        // Print the thread ID and the updated value of 'num' to the console
        printf("Thread ID %ld, num = %d\n", tid, num);

        // Release the mutex lock
        pthread_mutex_unlock(&mutex);
    }

    // Exit the thread
    pthread_exit(NULL);
}

// Function: main
// This is the main function where all the threads are created, joined, and managed.
// It also prints the final value of 'num' after all the threads have completed their execution.
int main() {
    // Creating an array of pthread_t objects to store thread IDs
    pthread_t threads[NUM_THREADS * 2];

    // Initializing a pthread_attr_t object
    pthread_attr_t attr;

    // Initializing the pthread_attr_t object with default attributes
    pthread_attr_init(&attr);

    // Creating joinable threads (NUM_THREADS)
    for (int i = 0; i < NUM_THREADS; ++i) {
        // Creating a new joinable thread
        pthread_create(&threads[i], &attr, decrement, (void*)&i);
    }

    // Setting the created threads to be detached
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

    // Creating detached threads (NUM_THREADS)
    for (int i = NUM_THREADS; i < NUM_THREADS * 2; ++i) {
        // Creating a new detached thread
        pthread_create(&threads[i], &attr, decrement, (void*)&i);
    }

    // Waiting for joinable threads to complete
    for (int i = 0; i < NUM_THREADS; ++i) {
        // Joining the thread and waiting for its completion
        pthread_join(threads[i], NULL);
    }

    // Destroying the pthread_attr_t object
    pthread_attr_destroy(&attr);

    // Destroying the mutex lock
    pthread_mutex_destroy(&mutex);

    // Printing the final value of 'num' to the console
    printf("Final value of num: %d\n", num);

    // Returning 0 to indicate successful execution
    return 0;
}