#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h> // Include the necessary header file

// Global variables to track the process IDs of child processes
pid_t child1_pid, child2_pid;

// Signal handler for SIGINT (Ctrl-C)
void sigint_handler(int signum) {
    // Terminate only the grandchild process
    if (getpid() != child2_pid) {
        kill(child2_pid, SIGTERM);
    }
}

int main() {
    // Set signal handler for SIGINT
    signal(SIGINT, sigint_handler);

    // Fork first child
    child1_pid = fork();

    if (child1_pid < 0) {
        perror("fork");
        exit(EXIT_FAILURE);
    } else if (child1_pid == 0) {
        // Child process 1
        setpgid(0, 0); // Set its process group ID to its own PID

        // Infinite loop printing process ID
        while (1) {
            printf("From process %d\n", getpid());
            sleep(2);
        }
    } else {
        // Fork second child from the parent
        child2_pid = fork();

        if (child2_pid < 0) {
            perror("fork");
            exit(EXIT_FAILURE);
        } else if (child2_pid == 0) {
            // Child process 2
            setpgid(0, child1_pid); // Set its process group ID to child1's PID

            // Infinite loop printing process ID
            while (1) {
                printf("From process %d\n", getpid());
                sleep(2);
            }
        } else {
            // Main parent process
            while (1) {
                // Wait for child2 to terminate
                waitpid(child2_pid, NULL, 0);

                // Print from main process
                printf("This is from process %d\n", getpid());
                sleep(2);

                // Send SIGSTOP to child1 to pause it
                kill(child1_pid, SIGSTOP);
                // Send SIGCONT to child2 to resume it
                kill(child2_pid, SIGCONT);

                // Wait for child1 to be paused
                waitpid(child1_pid, NULL, WUNTRACED);

                // Print from main process
                printf("This is from process %d\n", getpid());
                sleep(2);

                // Send SIGSTOP to child2 to pause it
                kill(child2_pid, SIGSTOP);
                // Send SIGCONT to child1 to resume it
                kill(child1_pid, SIGCONT);

                // Wait for child2 to be paused
                waitpid(child2_pid, NULL, WUNTRACED);
            }
        }
    }

    return 0;
}
