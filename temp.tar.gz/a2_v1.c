#include<stdio.h>
#include <stdlib.h>
#define MAX_LINE_LENGTH 256

int main(int argc, char const *argv[])
{
// a2prc [process_id] [root_process] [OPTION] 
    int process_id = atoi(argv[1]);
    int root_process = atoi(argv[2]);
    char *option = argv[3];
    printf("%d %d %s \n", process_id ,root_process, option);
    

    
    
    return 0;
}
