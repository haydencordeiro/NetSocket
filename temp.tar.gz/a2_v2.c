#include <stdio.h>
#include <stdlib.h>

#define MAX_LINE_LENGTH 256
#define MAX_NUMBERS 100

void readData(int data[][2], int *num_entries) {
    FILE *fp;
    char line[MAX_LINE_LENGTH];
    int pid, ppid;
    *num_entries = 0;

    // Open the command for reading
    fp = popen("ps -ef | grep a.out | awk '{print $2, $3}'", "r");

    // Read the output line by line and parse the numbers
    while (fgets(line, MAX_LINE_LENGTH, fp) != NULL) {
        // Parse the line to extract PID and PPID
        printf(" yolo%s",line);
        if (sscanf(line, "%d %d", &pid, &ppid) == 2) {
            printf("ola %d %d\n",pid,ppid);
            // Store the data into the array
            data[*num_entries][0] = pid;
            data[*num_entries][1] = ppid;
            *num_entries++;

            // Check if we've reached the maximum number of entries
            if (*num_entries >= MAX_NUMBERS) {
                fprintf(stderr, "Maximum number of entries reached\n");
                break;
            }
        }
    }

    // Close the file pointer
    pclose(fp);
}

int main(int argc, char const *argv[]) {
    // a2prc [process_id] [root_process] [OPTION] 
    int process_id = atoi(argv[1]);
    int root_process = atoi(argv[2]);
    char *option = argv[3];
    printf("%d %d %s \n", process_id ,root_process, option);
    


    // check parent root
    if (argc == 3)
    {
        int data[MAX_NUMBERS][2];
        int num_entries, i;

        // Read the data into the array
        readData(data, &num_entries);

        // Print the data in the array
        for (i = 0; i < num_entries; i++) 
        {
            printf("%d %d\n", data[i][0], data[i][1]);
        }
    }
    
    

    return 0;
}
