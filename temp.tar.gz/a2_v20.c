// completed completed rp pr xc only xn zn. had to change in  zs from  ps -ef to ps -u completed xz descendant zombie process
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

#define MAX_LINES 1000
#define MAX_LINE_LENGTH 256
#define MAX_NUMBERS 1000
#define MAX_CHILD_PROCESSES 100
#define MAX_PROCESS_IDS 10000
int child_count;
int defunct_processes_count = 0;
int grandchild_flag;
int grandchild_flag_2=0;
int print_defunct_process=0;
int processes_count = 0;
int print_process=0;
int non_direct_descendant_flag=0;

int* readDefunctProcesses() {
    FILE *fp;
    char command[100];
    char line[100];
    int *defunct_processes = malloc(MAX_LINES * sizeof(int));
    defunct_processes_count = 0;

    // Construct the command
    snprintf(command, sizeof(command), "ps -u | grep defunct | awk '{print $2}'");

    // Open the command for reading
    fp = popen(command, "r");

    // Read the output line by line and store the values into the array
    while (fgets(line, sizeof(line), fp) != NULL) {
        // Convert the string representation of PID to integer
        int pid = atoi(line);
        // Store the PID into the array
        defunct_processes[defunct_processes_count++] = pid;
        // Check if the array size exceeds the maximum limit
        if (defunct_processes_count >= MAX_LINES) {
            fprintf(stderr, "Maximum number of lines reached\n");
            break;
        }
    }
    pclose(fp);

    // Resize the array to the number of actual lines read
    defunct_processes = realloc(defunct_processes, defunct_processes_count * sizeof(int));

    return defunct_processes;
}

// READ PROCESSES IN AN ARRAY
int* readProcesses() 
{ 
    FILE *fp;
    char command[100];
    char line[100];
    int *processes = malloc(MAX_LINES * sizeof(int));
    processes_count = 0;
    // Construct the command
    snprintf(command, sizeof(command), "ps -u | awk '{print $2}'");
    fp = popen(command, "r");
    // Read the output line by line and store the values into the array
    while (fgets(line, sizeof(line), fp) != NULL) {
        int pid = atoi(line);
        processes[processes_count++] = pid;
        if (processes_count >= MAX_LINES) {
            fprintf(stderr, "Maximum number of lines reached\n");
            break;
        }
    }
    pclose(fp);
    // Resize the array to the number of actual lines read
    processes = realloc(processes, processes_count * sizeof(int));
    return processes;
}

// FUNCTION TO CREATE A FILE IN WORKING DIRECTORY AND WRITE PAUSED PROCESSES
void writeProcessIdToFile(int process_id) {
    FILE *file = fopen("pause.txt", "a"); // Open file in append mode
    if (file == NULL) {
        perror("Failed to create/open file");
        return;
    }
    fprintf(file, "%d\n", process_id);
    fclose(file);
}

int TraverseTree(process_id,root_process){
    int parent_id;
    parent_id = GetParent(process_id);
    if (parent_id ==root_process)
    {
        return 1;
    }
    if (parent_id<root_process)
    {
        return 0;
    }
    return TraverseTree(parent_id,root_process);
}
// FUNCTION TO READ FILE IN WORKING DIRECTORY AND WRITE PAUSED PROCESSES
void readProcessIdsFromFile(root_process) {
    FILE *file = fopen("pause.txt", "r");
    int currentprocess_ids;
    int process_id;
    int count = 0;

    while (fscanf(file, "%d", &process_id) == 1) {
        if (TraverseTree(process_id,root_process))
        {
            char command[50];
            sprintf(command, "kill -CONT %d", process_id);
            int result = system(command);
        }
    }
    printf("all process belonging to the same tree has been unpaused\n");
    fclose(file);
}

// getParent and if not parent process do not exist
int GetParent(int process_id) {
    FILE *fp;
    char command[100];
    char output[100];
    int parent_id;

    // Construct the command
    snprintf(command, sizeof(command), "ps -o ppid= %d", process_id);

    fp = popen(command, "r");
    if (fp == NULL) {
        perror("popen");
        exit(EXIT_FAILURE);
    }

    // Read the output value (parent process ID) into parent_id variable
    if (fgets(output, sizeof(output), fp) != NULL) {
        parent_id = atoi(output);
    } else {
        return 0;
    }
    pclose(fp);
    return parent_id; // Return the parent process ID
}

// GET CHILD PROCESSES IN AN ARRAY
int* GetChild(int parent_id) {
    FILE *fp;
    char command[100];
    char line[100];
    int *child_pids = malloc(MAX_CHILD_PROCESSES * sizeof(int));
    child_count = 0;

    // Construct the command
    snprintf(command, sizeof(command), "ps --ppid %d -o pid=", parent_id);
    fp = popen(command, "r");
    if (fp == NULL) {
        perror("popen");
        exit(EXIT_FAILURE);
    }

    // Read the output line by line and store the PIDs into the array
    while (fgets(line, sizeof(line), fp) != NULL) {
        int pid = atoi(line);
        child_pids[child_count++] = pid;
        if (child_count >= MAX_CHILD_PROCESSES) {
            fprintf(stderr, "Maximum number of child processes reached\n");
            break;
        }
    }
    pclose(fp);
    child_pids = realloc(child_pids, child_count * sizeof(int));
    return child_pids;
}


int main(int argc, char const *argv[]) 
{
    // a2prc [process_id] [root_process] [OPTION] 
    int process_id = atoi(argv[1]);
    int root_process = atoi(argv[2]);
    char *option = argv[3];
    if (argc==3)
    {   
        
        int result=TraverseTree(process_id,root_process);
        if (result ==0)
        {
            printf("Does not belong to the process tree\n");
        }
        if (result==1)
        {
            printf("%d %d\n",process_id,GetParent(process_id));
        }        
    }
    if (argc==4)
    {
        if (strcmp(option,"-xd")==0)
        {   
            // check if it is part of tree and then get childs
            int result=TraverseTree(process_id,root_process);
            if (result ==0)
            {
                printf("Does not belong to the process tree\n");
            }
            if (result==1)
            {
                int *child_pids;
                int i;
        
                child_pids = GetChild(process_id); // Call GetChild function               
                if (child_pids==0)
                {
                    printf("No direct descendants\n");
                    exit(0);
                }
                for (i = 0;i<child_count; i++) {
                    printf("%d\n", child_pids[i]);
                }
                free(child_pids); 
            }    
        }
        else if (strcmp(option,"-xg")==0)
        {   
            // check if it is part of tree and then get childs
            int result=TraverseTree(process_id,root_process);
            if (result ==0)
            {
                printf("Does not belong to the process tree\n");
                exit(0);
            }
            if (result==1)
            {
                int *child_pids;
                int i;    
                child_pids = GetChild(process_id); // Call GetChild function               
                if (child_pids==0)
                {
                    printf("No grandchildren \n");
                    exit(0);
                }
                // create  copy of child
                int *copy_of_child_pids = malloc(MAX_CHILD_PROCESSES * sizeof(int));
                int copy_child_count=0;
                for (i = 0;i<child_count; i++) {
                    copy_of_child_pids[copy_child_count++] =child_pids[i];
                    
                }
                free(child_pids);
                // now pass that each child to gechild again
                for (i = 0;i<copy_child_count; i++) 
                {
                    // Call GetChild function
                    child_pids = GetChild(copy_of_child_pids[i]);                
                    if (child_pids==0)
                    {   
                        if (grandchild_flag_2==0)
                        {
                            grandchild_flag=1;
                        }
                        continue;
                        
                    }
                    //ONLY PRINT child IF there was a child
                    for (int j = 0;j<child_count; j++) {
                        grandchild_flag=0;
                        grandchild_flag_2=1;          //
                        printf("%d\n", child_pids[j]);
                    }
                    free(child_pids); 
                } 
                if (grandchild_flag==1)
                    {
                        printf("No grandchildren\n");
                        grandchild_flag_2=0;
                    }                 
            }

   
        }
        else if (strcmp(option,"-xs")==0)//sibling
        {
            int result=TraverseTree(process_id,root_process);
            if (result ==0)
            {
                printf("Does not belong to the process tree\n");
                exit(0);
            }
            if (result==1){
                int parent_id=GetParent(process_id);
                int *child_pids;
                int i;
                // Call GetChild function
                child_pids = GetChild(parent_id);
                if (child_count==1)
                {
                    printf("No siblings/s\n");
                    exit(0);
                }
                for (i = 0;i<child_count; i++) {
                    if (child_pids[i]==process_id)
                    {
                        continue;
                    }
                    printf("%d\n",child_pids[i]);
                }
            }
        }
        else if (strcmp(option,"-zs")==0)
        {   
            int result=TraverseTree(process_id,root_process);
            if (result ==0)
            {
                printf("Does not belong to the process tree\n");
                exit(0);
            }
            int *defunct_processes;
            int i;
            defunct_processes = readDefunctProcesses();
            for (i = 0; i<defunct_processes_count; i++) {
                if (defunct_processes[i]==process_id)
                {
                    printf("Defunct\n");
                    free(defunct_processes);
                    exit(0);
                }
            }
            printf("Not Defunct\n");
            free(defunct_processes);
        }
        else if (strcmp(option,"-xt")==0)//pause a given process using SIGSTOP
        {
            int result=TraverseTree(process_id,root_process);
            if (result ==0)
            {
                printf("Does not belong to the process tree\n");
                exit(0);
            }
            kill(process_id, SIGSTOP);
            writeProcessIdToFile(process_id);
            printf("process %d has been stopped\n",process_id);
        }
        else if (strcmp(option,"-xc")==0)
        {
            readProcessIdsFromFile(root_process);
            
        }
        else if (strcmp(option,"-rp")==0)
        {
            int result=TraverseTree(process_id,root_process);
            if (result ==0)
            {
                printf("Does not belong to the process tree\n");
                exit(0);
            }
            printf("killed process %d\n",process_id);
            kill(process_id, SIGKILL);
        }
        else if (strcmp(option,"-pr")==0)
        {
            int result=TraverseTree(process_id,root_process);
            if (result ==0)
            {
                printf("Does not belong to the process tree\n");
                exit(0);
            }
            printf("killed root process %d\n",root_process);
            kill(root_process, SIGKILL);
        }
        else if (strcmp(option,"-xz")==0) //descendant zombie process/es
        {
            int result=TraverseTree(process_id,root_process);
            if (result ==0)
            {
                printf("Does not belong to the process tree\n");
                exit(0);
            }
            int *defunct_processes;
            int i;
            defunct_processes = readDefunctProcesses();
            for (i = 0; i<defunct_processes_count; i++) {
                if(TraverseTree(*(defunct_processes+i),process_id)){
                    print_defunct_process=1;
                    printf("defunct processes %d\n",*(defunct_processes+i));
                }
            }
            if (print_defunct_process!=1)
            {
                printf("No descendant zombie process/es \n");
            }
            free(defunct_processes);
        }
        else if (strcmp(option,"-xn") == 0) //non direct descendants
        {
            int result=TraverseTree(process_id,root_process);
            if (result == 0)
            {
                printf("Does not belong to the process tree\n");
                exit(0);
            }
            int *processes;
            int i;

            processes = readProcesses(); //READ ALL PROCESSES
            //IN ALL PROCESS IF IT BELONG TO SAME TREE AND PRINT THE PROCESSES EXCLUDING THE IMMEDIATE CHILD PROCESSES
            for (i = 0; i < processes_count; i++) 
            {
                if (*(processes+i)!=0)
                {
                    if(TraverseTree(*(processes+i),process_id))
                    {
                        int p=GetParent(*(processes+i));
                        if (process_id!=p)
                        {   
                            non_direct_descendant_flag=1;
                            printf("%d\n",*(processes+i));
                        }
                        
                    }
                }
            }
            if (non_direct_descendant_flag==0)
            {
                printf("No non-direct descendants\n");
            }
            
            free(processes);
        }    
    }
    return 0;
}
