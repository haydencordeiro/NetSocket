#include <stdio.h>
#include <stdlib.h>

#define MAX_PIDS 100

int readParentProcessPids(int parent_pid, int *pid_array) {
    FILE *fp;
    char command[100];
    char line[100];
    int count = 0;

    // Construct the command
    snprintf(command, sizeof(command), "ps --ppid %d -o pid=", parent_pid);

    // Open the command for reading
    fp = popen(command, "r");


    // Read the output line by line and store the PIDs into the array
    while (fgets(line, sizeof(line), fp) != NULL) {
        // Convert the string representation of PID to integer
        int pid = atoi(line);
        // Store the PID into the array
        pid_array[count++] = pid;
        // Check if the array size exceeds the maximum limit
        if (count >= MAX_PIDS) {
            fprintf(stderr, "Maximum number of PIDs reached\n");
            break;
        }
    }

    // Close the file pointer
    pclose(fp);

    // Return the number of PIDs read
    return count;
}

int main(int argc, char const *argv[]) {
    // a2prc [process_id] [root_process] [OPTION] 
    int process_id = atoi(argv[1]);
    int root_process = atoi(argv[2]);
    char *option = argv[3];
    printf("%d %d %s \n", process_id ,root_process, option);
    if (argc==3)
    {
        // int parent_pid = 1234; // Replace 1234 with the actual parent process ID
        int pid_array[MAX_PIDS];
        int num_pids, i;

        // Read the parent process PIDs into the array
        num_pids = readParentProcessPids(root_process, pid_array);

        // Print the PIDs stored in the array
        printf("PIDs of processes with parent PID %d:\n", root_process);
        for (i = 0; i < num_pids; i++) {
            printf("%d\n", pid_array[i]);
        }
    }
    


    return 0;
}
