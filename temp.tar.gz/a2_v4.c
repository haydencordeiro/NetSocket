#include <stdio.h>
#include <stdlib.h>

#define MAX_LINE_LENGTH 256
#define MAX_NUMBERS 1000


void ReadData(int data[][2], int *num_entries) {
    FILE *fp;
    char line[MAX_LINE_LENGTH];
    int pid, ppid;
    *num_entries = 0;

    // Open the command for reading
    fp = popen("ps -ef | awk '{print $2, $3}'", "r");
    if (fp == NULL) {
        perror("popen");
        exit(EXIT_FAILURE);
    }

    // Read the output line by line and parse the numbers
    while (fgets(line, MAX_LINE_LENGTH, fp) != NULL) {
        // Parse the line to extract PID and PPID
        if (sscanf(line, "%d %d", &pid, &ppid) == 2) {
            // Store the data into the array
            data[*num_entries][0] = pid;
            data[*num_entries][1] = ppid;
            (*num_entries)++;

            // Check if we've reached the maximum number of entries
            if (*num_entries >= MAX_NUMBERS) {
                fprintf(stderr, "Maximum number of entries reached\n");
                break;
            }
        }
    }

    // Close the file pointer
    pclose(fp);
}

int TraverseTree(process_id,root_process){
    int parent_id;
    parent_id = GetParent(process_id);
    if (parent_id ==root_process)
    {
        return 1;
    }
    if (parent_id<root_process)
    {
        return 0;
    }
    return TraverseTree(parent_id,root_process);
    
    
    
    // return parent_id;
}
// getParent and if not parent process do not exist
int GetParent(int process_id) {
    FILE *fp;
    char command[100];
    char output[100];
    int parent_id;

    // Construct the command
    snprintf(command, sizeof(command), "ps -o ppid= %d", process_id);

    // Open the command for reading
    fp = popen(command, "r");
    if (fp == NULL) {
        perror("popen");
        exit(EXIT_FAILURE);
    }

    // Read the output value (parent process ID) into parent_id variable
    if (fgets(output, sizeof(output), fp) != NULL) {
        parent_id = atoi(output);
    } else {
        // fprintf(stderr, "Failed to read parent process ID :parent does not exist : does not belong to process tree\n");
        return 0;
    }

    // Close the file pointer
    pclose(fp);

    // Return the parent process ID
    return parent_id;
}

int main(int argc, char const *argv[]) {
    // a2prc [process_id] [root_process] [OPTION] 
    int process_id = atoi(argv[1]);
    int root_process = atoi(argv[2]);
    char *option = argv[3];
    // printf("%d %d %s \n", process_id ,root_process, option);
    
    if (argc==3)
    {
        int data[MAX_NUMBERS][2];
        int num_entries, i;
        
        // Read the data into the array
        ReadData(data, &num_entries);

        // Print the data in the array
        // for (i = 0; i < num_entries; i++) {
        //     printf("%d %d\n", data[i][0], data[i][1]);
        // }

        int result=TraverseTree(process_id,root_process);
        if (result ==0)
        {
            printf("Failed to read parent process ID :parent does not exist : does not belong to process tree");
        }
        if (result==1)
        {
            printf("%d %d\n",process_id,GetParent(process_id));
        }
        
        // printf("h %d\n", result);

        
    }
    
    

    return 0;
}
