// completed SIBLINGS PROCESS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_LENGTH 256
#define MAX_NUMBERS 1000
#define MAX_CHILD_PROCESSES 100
int child_count;
int grandchild_flag;
int grandchild_flag_2=0;

void ReadData(int data[][2], int *num_entries) {
    FILE *fp;
    char line[MAX_LINE_LENGTH];
    int pid, ppid;
    *num_entries = 0;

    // Open the command for reading
    fp = popen("ps -ef | awk '{print $2, $3}'", "r");
    if (fp == NULL) {
        perror("popen");
        exit(EXIT_FAILURE);
    }

    // Read the output line by line and parse the numbers
    while (fgets(line, MAX_LINE_LENGTH, fp) != NULL) {
        // Parse the line to extract PID and PPID
        if (sscanf(line, "%d %d", &pid, &ppid) == 2) {
            // Store the data into the array
            data[*num_entries][0] = pid;
            data[*num_entries][1] = ppid;
            (*num_entries)++;

            // Check if we've reached the maximum number of entries
            if (*num_entries >= MAX_NUMBERS) {
                fprintf(stderr, "Maximum number of entries reached\n");
                break;
            }
        }
    }

    // Close the file pointer
    pclose(fp);
}

int TraverseTree(process_id,root_process){
    int parent_id;
    parent_id = GetParent(process_id);
    if (parent_id ==root_process)
    {
        return 1;
    }
    if (parent_id<root_process)
    {
        return 0;
    }
    return TraverseTree(parent_id,root_process);
    
    
    
    // return parent_id;
}
// getParent and if not parent process do not exist
int GetParent(int process_id) {
    FILE *fp;
    char command[100];
    char output[100];
    int parent_id;

    // Construct the command
    snprintf(command, sizeof(command), "ps -o ppid= %d", process_id);

    // Open the command for reading
    fp = popen(command, "r");
    if (fp == NULL) {
        perror("popen");
        exit(EXIT_FAILURE);
    }

    // Read the output value (parent process ID) into parent_id variable
    if (fgets(output, sizeof(output), fp) != NULL) {
        parent_id = atoi(output);
    } else {
        // fprintf(stderr, "Failed to read parent process ID :parent does not exist : does not belong to process tree\n");
        return 0;
    }

    // Close the file pointer
    pclose(fp);

    // Return the parent process ID
    return parent_id;
}

int* GetChild(int parent_id) {
    // printf("child %d\n",parent_id);
    FILE *fp;
    char command[100];
    char line[100];
    int *child_pids = malloc(MAX_CHILD_PROCESSES * sizeof(int));
    child_count = 0;

    // Construct the command
    snprintf(command, sizeof(command), "ps --ppid %d -o pid=", parent_id);

    // Open the command for reading
    fp = popen(command, "r");
    if (fp == NULL) {
        perror("popen");
        exit(EXIT_FAILURE);
    }

    // Read the output line by line and store the PIDs into the array
    while (fgets(line, sizeof(line), fp) != NULL) {
        // Convert the string representation of PID to integer
        int pid = atoi(line);
        // Store the PID into the array
        child_pids[child_count++] = pid;
        // Check if the array size exceeds the maximum limit
        if (child_count >= MAX_CHILD_PROCESSES) {
            fprintf(stderr, "Maximum number of child processes reached\n");
            break;
        }
    }

    // Close the file pointer
    pclose(fp);

    // Resize the array to the number of actual child processes found
    child_pids = realloc(child_pids, child_count * sizeof(int));
    // printf(" count : %d\n",child_count);

    return child_pids;
}


int main(int argc, char const *argv[]) 
{
    // a2prc [process_id] [root_process] [OPTION] 
    int process_id = atoi(argv[1]);
    int root_process = atoi(argv[2]);
    char *option = argv[3];
    // printf("%d %d %s \n", process_id ,root_process, option);
    
    // int data[MAX_NUMBERS][2];
    // int num_entries, i;
    //     // Read the data into the array
    // ReadData(data, &num_entries);

    // // Print the data in the array
    // for (i = 0; i < num_entries; i++) {
    //     printf("%d %d\n", data[i][0], data[i][1]);
    // }

    if (argc==3)
    {   
        
        int result=TraverseTree(process_id,root_process);
        if (result ==0)
        {
            printf("Failed to read parent process ID :parent does not exist : does not belong to process tree\n");
        }
        if (result==1)
        {
            printf("%d %d\n",process_id,GetParent(process_id));
        }    
        // printf("h %d\n", result);    
    }
    if (argc==4)
    {
        if (strcmp(option,"-xd")==0)
        {   
            // check if it is part of tree and then get childs
            int result=TraverseTree(process_id,root_process);
            if (result ==0)
            {
                printf(" 2: Failed to read parent process ID :parent does not exist : does not belong to process tree\n");
            }
            if (result==1)
            {

                // 
                int *child_pids;
                int i;
                // Call GetChild function
                child_pids = GetChild(process_id);                
                // Print the child process IDs
                // printf("Child process IDs of parent process %d:\n", process_id);
                // printf("child_pids : %d\n",child_pids);
                if (child_pids==0)
                {
                    printf("No direct descendants\n");
                    exit(0);
                }
                
                for (i = 0;i<child_count; i++) {
                    printf("%d\n", child_pids[i]);
                }
                // Free the dynamically allocated memory
                free(child_pids);
                // 
            }

            
        }
        else if (strcmp(option,"-xg")==0)
        {   
            // check if it is part of tree and then get childs
            int result=TraverseTree(process_id,root_process);
            if (result ==0)
            {
                printf(" 2: Failed to read parent process ID :parent does not exist : does not belong to process tree\n");
                exit(0);
            }
            if (result==1)
            {
                // 
                int *child_pids;
                int i;
                // Call GetChild function
                child_pids = GetChild(process_id);                

                if (child_pids==0)
                {
                    printf("No grandchildren \n");
                    exit(0);
                }
                
                // create  copy of child
                int *copy_of_child_pids = malloc(MAX_CHILD_PROCESSES * sizeof(int));
                int copy_child_count=0;
                for (i = 0;i<child_count; i++) {
                    // printf(" parent %d\n",child_pids[i]);
                    copy_of_child_pids[copy_child_count++] =child_pids[i];
                    
                }
                free(child_pids);
                // now pass that each child to gechild again
                for (i = 0;i<copy_child_count; i++) 
                {
                                   // 
                    // int *child_pids;
                    // int i;
                    // Call GetChild function
                    child_pids = GetChild(copy_of_child_pids[i]);                
                    // Print the child process IDs
                    // printf("Child process IDs of parent process %d:\n", process_id);
                    // printf("child_pids : %d\n",child_pids);
                    if (child_pids==0)
                    {   
                        // temporary fix becauuse if the parent was second last element it was not printing if child didnt exist
                        if (grandchild_flag_2==0)//needed one more flag for printing logic
                        {
                            grandchild_flag=1;
                        }
                        
                        
                        // printf("what?");
                        // printf("No direct descendants\n");
                        // exit(0);
                        continue;
                        
                    }
                    
                    for (int j = 0;j<child_count; j++) {
                        grandchild_flag=0;// i have an assumption that if child is being printed it means there was a child
                        grandchild_flag_2=1;          //
                        printf("%d\n", child_pids[j]);
                    }
                    // Free the dynamically allocated memory
                    free(child_pids);
                    
                    
                    // 
                }
                // 
                if (grandchild_flag==1)
                    {
                        printf("No grandchildren\n");
                        grandchild_flag_2=0;
                    }                 
            }

   
        }
        else if (strcmp(option,"-xs")==0)
        {
            int result=TraverseTree(process_id,root_process);
            if (result ==0)
            {
                printf(" 2: Failed to read parent process ID :parent does not exist : does not belong to process tree\n");
                exit(0);
            }
            if (result==1){
                int parent_id=GetParent(process_id);
                // printf("parent_di : %d\n",parent_id);
                int *child_pids;
                int i;
                // Call GetChild function
                child_pids = GetChild(parent_id);
                // printf(" number of child pids: %d\n",*child_pids);
                if (child_count==1)
                {
                    printf("No siblings/s\n");
                    exit(0);
                }
                for (i = 0;i<child_count; i++) {
                    if (child_pids[i]==process_id)
                    {
                        continue;
                    }
                    printf("%d\n",child_pids[i]);
                    // copy_of_child_pids[copy_child_count++] =child_pids[i];   
                }
            }
        }
        
        

        
    }
    
    
    

    return 0;
}
