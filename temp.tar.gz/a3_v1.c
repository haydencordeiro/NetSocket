#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_TOKENS 100
#define MAX_TOKEN_LEN 50

char **separateAndStore(char *input) {
    char **output = (char **)malloc(MAX_TOKENS * sizeof(char *));
    if (output == NULL) {
        perror("Memory allocation failed");
        exit(EXIT_FAILURE);
    }

    int i = 0;
    int index = 0;
    int tokenStart = 0;
    int len = strlen(input);

    while (i < len && index < MAX_TOKENS - 1) {
        if (input[i] == '&' && input[i + 1] == '&' && (i + 2 == len || input[i + 2] == ' ')) {
            if (i > tokenStart) {
                output[index] = (char *)malloc((i - tokenStart + 1) * sizeof(char));
                if (output[index] == NULL) {
                    perror("Memory allocation failed");
                    exit(EXIT_FAILURE);
                }
                strncpy(output[index], input + tokenStart, i - tokenStart);
                output[index][i - tokenStart] = '\0';
                index++;
            }
            output[index] = (char *)malloc(3 * sizeof(char)); // Allocate memory for "&&"
            if (output[index] == NULL) {
                perror("Memory allocation failed");
                exit(EXIT_FAILURE);
            }
            strcpy(output[index], "&&");
            index++;
            i += 2; // Skip '&&'
            tokenStart = i + 1;
        } else if (input[i] == '|' && input[i + 1] == '|' && (i + 2 == len || input[i + 2] == ' ')) {
            if (i > tokenStart) {
                output[index] = (char *)malloc((i - tokenStart + 1) * sizeof(char));
                if (output[index] == NULL) {
                    perror("Memory allocation failed");
                    exit(EXIT_FAILURE);
                }
                strncpy(output[index], input + tokenStart, i - tokenStart);
                output[index][i - tokenStart] = '\0';
                index++;
            }
            output[index] = (char *)malloc(3 * sizeof(char)); // Allocate memory for "||"
            if (output[index] == NULL) {
                perror("Memory allocation failed");
                exit(EXIT_FAILURE);
            }
            strcpy(output[index], "||");
            index++;
            i += 2; // Skip '||'
            tokenStart = i + 1;
        }
        i++;
    }

    if (i > tokenStart) {
        output[index] = (char *)malloc((i - tokenStart + 1) * sizeof(char));
        if (output[index] == NULL) {
            perror("Memory allocation failed");
            exit(EXIT_FAILURE);
        }
        strncpy(output[index], input + tokenStart, i - tokenStart);
        output[index][i - tokenStart] = '\0';
        index++;
    }

    output[index] = NULL; // Null-terminate the array

    return output;
}
    
int main() {
    char input[] = "ls -1 -t && yoloy && grep a.c || folor";

    char **output = separateAndStore(input);

    // Printing the stored tokens
    for (int i = 0; output[i] != NULL; i++) {
        printf("%s\n", output[i]);
        free(output[i]); // Free the memory allocated for each token
    }

    free(output); // Free the memory allocated for the array of pointers

    return 0;
}
