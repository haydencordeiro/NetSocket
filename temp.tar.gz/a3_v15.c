// sequential done with version2 optimieze of tokenizecommand
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <pwd.h>

#define MAX_TOKENS 100
#define MAX_TOKEN_LEN 50
#define COMMAND_LENGTH 1000
#define MAX_PROCESS_COUNT 100
#define TOTAL_ARGUMENTS 5
char *terminal_id;
char *process_file;
int last_value;

char **separateAndStore(char *input) {
    char **output = (char **)malloc(MAX_TOKENS * sizeof(char *));
    if (output == NULL) {
        perror("Memory allocation failed");
        exit(EXIT_FAILURE);
    }

    int i = 0;
    int index = 0;
    int tokenStart = 0;
    int len = strlen(input);

    while (i < len && index < MAX_TOKENS - 1) {
        if (input[i] == '&' && input[i + 1] == '&' && (i + 2 == len || input[i + 2] == ' ')) {
            if (i > tokenStart) {
                output[index] = (char *)malloc((i - tokenStart + 1) * sizeof(char));
                if (output[index] == NULL) {
                    perror("Memory allocation failed");
                    exit(EXIT_FAILURE);
                }
                strncpy(output[index], input + tokenStart, i - tokenStart);
                output[index][i - tokenStart] = '\0';
                index++;
            }
            output[index] = (char *)malloc(3 * sizeof(char)); // Allocate memory for "&&"
            if (output[index] == NULL) {
                perror("Memory allocation failed");
                exit(EXIT_FAILURE);
            }
            strcpy(output[index], "&&");
            index++;
            i += 2; // Skip '&&'
            tokenStart = i + 1;
        } else if (input[i] == '|' && input[i + 1] == '|' && (i + 2 == len || input[i + 2] == ' ')) {
            if (i > tokenStart) {
                output[index] = (char *)malloc((i - tokenStart + 1) * sizeof(char));
                if (output[index] == NULL) {
                    perror("Memory allocation failed");
                    exit(EXIT_FAILURE);
                }
                strncpy(output[index], input + tokenStart, i - tokenStart);
                output[index][i - tokenStart] = '\0';
                index++;
            }
            output[index] = (char *)malloc(3 * sizeof(char)); // Allocate memory for "||"
            if (output[index] == NULL) {
                perror("Memory allocation failed");
                exit(EXIT_FAILURE);
            }
            strcpy(output[index], "||");
            index++;
            i += 2; // Skip '||'
            tokenStart = i + 1;
        }
        i++;
    }

    if (i > tokenStart) {
        output[index] = (char *)malloc((i - tokenStart + 1) * sizeof(char));
        if (output[index] == NULL) {
            perror("Memory allocation failed");
            exit(EXIT_FAILURE);
        }
        strncpy(output[index], input + tokenStart, i - tokenStart);
        output[index][i - tokenStart] = '\0';
        index++;
    }

    output[index] = NULL; // Null-terminate the array

    return output;
}

int countLength(char **arr)
{
    int i = 0;
    while (arr[i] != NULL)
    {
        i += 1;
    }
    return i;
}


char **tokenizeCommand(char *str, char *delimiter)
{
    int count = 0;
    char **tokens = (char **)malloc(TOTAL_ARGUMENTS * sizeof(char *));
    if (tokens == NULL)
    {
        fprintf(stderr, "Memory allocation error\n");
        return NULL;
    }

    // Allocate memory for all tokens
    char *tokenized_str = strdup(str);
    if (tokenized_str == NULL)
    {
        fprintf(stderr, "Memory allocation error\n");
        free(tokens);
        return NULL;
    }

    // Tokenize the string
    char *token = strtok(tokenized_str, delimiter);
    while (token != NULL)
    {
        // Remove leading spaces
        while (isspace(*token))
            token++;

        // Remove trailing spaces
        int end = strlen(token) - 1;
        while (end >= 0 && isspace(token[end]))
            end--;
        token[end + 1] = '\0';

        // Copy token to tokens array
        tokens[count++] = strdup(token);

        token = strtok(NULL, delimiter);
    }

    // Add NULL to indicate end
    tokens[count] = NULL;

    // Free the memory allocated for the tokenized string
    free(tokenized_str);

    return tokens;
}

char *trimString(char *str) {
    char *end;

    // Skip leading spaces
    while (isspace((unsigned char)*str))
        str++;

    // If the string is empty or contains only spaces
    if (*str == '\0')
        return str;

    // Trim trailing spaces
    end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char)*end))
        end--;

    // Null-terminate the trimmed string
    *(end + 1) = '\0';

    return str;
}

// int getLenght(int *p)
// {
//     // variable that holds the lenght of the string
//     int c = 0;
//     // iterating till -2 (-2 denotes the end of the array)
//     for (int i = 0; p[i] != -2; i++)
//     {
//         c += 1;
//     }
//     c += 1;
//     return c;
// }


void readTopmostBgProcess(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Unable to open file.\n");
        return;
    }

    // Read values from the file
    int values[1000]; // Assuming maximum 1000 values
    int count = 0;
    while (fscanf(file, "%d", &values[count]) == 1) {
        count++;
    }

    if (count > 0) {
        // Get the last value
        last_value = values[count - 1];

        // Rewind the file to overwrite it
        fclose(file);
        file = fopen(filename, "w");

        // Write the remaining values back to the file, excluding the last one
        for (int i = 0; i < count - 1; i++) {
            fprintf(file, "%d\n", values[i]);
        }
    } else {
        printf("File is empty.\n");
    }

    fclose(file);
}

// char* generateRandomStringForBashId(int length) {
//     const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
//     char* randomString = (char*)malloc((length + 1) * sizeof(char));
//     if (randomString == NULL) {
//         fprintf(stderr, "Memory allocation failed\n");
//         exit(1);
//     }

//     srand((unsigned int)time(NULL));

//     for (int i = 0; i < length; ++i) {
//         randomString[i] = charset[rand() % (sizeof(charset) - 1)];
//     }
//     randomString[length] = '\0';
//     return randomString;
// }

char* generateRandomStringForBashId(int length) {
    const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    char* randomString = (char*)malloc((length + 5) * sizeof(char)); // Additional space for ".txt\0"
    if (randomString == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(1);
    }

    srand((unsigned int)time(NULL));

    for (int i = 0; i < length; ++i) {
        randomString[i] = charset[rand() % (sizeof(charset) - 1)];
    }

    // Append ".txt" at the end
    strcpy(randomString + length, ".txt");

    return randomString;
}

// check if the filename exists or not 
int checkIfFilePresent(const char *filename) {
    // Check if the file exists by trying to access it in read mode
    if (access(filename, F_OK) != -1) {
        // File exists
        return 1;
    } else {
        // File does not exist
        return 0;
    }
}

char** tokenizeString(const char* str, const char* delimiter) {
    char** tokens = NULL;
    char* token = strtok(strdup(str), delimiter);
    int tokenCount = 0;

    // Count tokens
    while (token != NULL) {
        token = strtok(NULL, delimiter);
        tokenCount++;
    }

    // Allocate memory for token array
    tokens = (char**)malloc(tokenCount * sizeof(char*));
    if (tokens == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(1);
    }

    // Split string and store tokens
    token = strtok((char*)str, delimiter);
    for (int i = 0; i < tokenCount; i++) {
        // Strip leading spaces
        while (isspace(*token)) {
            token++;
        }

        // Strip trailing spaces
        char* end = token + strlen(token) - 1;
        while (end > token && isspace(*end)) {
            *end = '\0';
            end--;
        }

        tokens[i] = token;
        token = strtok(NULL, delimiter);
    }

    // Set count
    // *count = tokenCount;

    return tokens;
}




int* readProcessIDsFromFile(const char* filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        fprintf(stderr, "Error opening file: %s\n", filename);
        exit(1);
    }

    // Allocate memory for storing process IDs
    int* processIDs = (int*)malloc(MAX_PROCESS_COUNT * sizeof(int));
    if (processIDs == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(1);
    }

    int count = 0;
    int id;
    // Read process IDs from the file
    while (fscanf(file, "%d", &id) == 1) {
        processIDs[count] = id;
        (count)++;
        if (count >= MAX_PROCESS_COUNT) {
            fprintf(stderr, "Maximum number of process IDs exceeded\n");
            exit(1);
        }
    }

    fclose(file);
    return processIDs;
}
// kill recent process
int handler(){
    if (checkIfFilePresent(process_file))
    {
        // int * process_ids=readProcessIDsFromFile(process_file);
        // printf("%d",process_ids[0]);
        printf("KILL PROCESS %d\n",last_value);
        kill(last_value, SIGINT);
    }
    printf("\n");
}

void writeProcessIDToFile(const char* filename, int processID) {
    FILE *file = fopen(filename, "a"); // Open file in append mode
    if (file == NULL) {
        fprintf(stderr, "Error opening file: %s\n", filename);
        return;
    }

    // Write process ID to file
    fprintf(file, "%d\n", processID);

    fclose(file);
}

char **addCatPrefix(char **array, size_t size) {
    // Allocate memory for the modified array
    char **result = malloc(size * sizeof(char *));
    if (result == NULL) {
        fprintf(stderr, "Memory allocation error\n");
        return NULL;
    }

    // Prefix "cat " to each string in the original array
    for (size_t i = 0; i < size; i++) {
        size_t prefix_len = strlen("cat ");
        size_t str_len = strlen(array[i]);
        result[i] = malloc((prefix_len + str_len + 1) * sizeof(char));
        if (result[i] == NULL) {
            // Free previously allocated memory
            for (size_t j = 0; j < i; j++) {
                free(result[j]);
            }
            free(result);
            fprintf(stderr, "Memory allocation error\n");
            return NULL;
        }
        strcpy(result[i], "cat ");
        strcat(result[i], array[i]);
    }

    return result;
}
void handleCommands(char *command, char *terminal_id){
    printf("hello from handle commands\n");
    if (strstr(command,"fg")!=NULL)
    {
        if (!checkIfFilePresent(terminal_id))
        {
            printf("file does not exist\n");
            return;
        }
        // int *pids = readProcessIDsFromFile(terminal_id);
        readTopmostBgProcess(terminal_id);
        printf("last value %d\n",last_value);
        // int tLen = strlen(terminal_id);
        // unlink(terminal_id);
        // int l = getLenght(pids);
        // for (int i = 0; pids[i] != -2; i++)
        // {
        //     // check if the process belongs to the current process tree
        //     if (i == l - 2)
        //     {
        //         writeProcessIDToFile(process_file,pids[i]);
                // wait(NULL);
        //     }
        //     else
        //     {
        //         // if no add it back to the file
        //         writeProcessIDToFile(terminal_id,pids[i]);
        //     }
        // }
        
    }
    else if (strstr(command, "&&") != NULL || strstr(command, "||") != NULL)
    {
        printf("helloooooooo\n");
        char **output = separateAndStore(command);
        int len=countLength(output);
        int child = fork();
        if (child == 0)
        {
            runChainingAndOr(output, len);
            exit(0);
        }
        else
        {
            waitpid(child, NULL, 0);
        }

            // Printing the stored tokens
        // for (int i = 0; output[i] != NULL; i++) {
        //     printf("%s\n", output[i]);
        // }
    }
    else if (strstr(command,"&")!=NULL)
    {
        printf("hello");
        char **strings = tokenizeString(command, "&");
        signal(SIGINT, handler);
        int child = fork();
        if (child > 0)
        {
            if (strlen(strings[0]) > 0)
                writeProcessIDToFile(terminal_id,child);
            // To print which order it is inthe stack
            // int *pids = readProcessIDsFromFile(terminal_id);
            // int size = sizeof(pids) / sizeof(pids[0]);
            // printf("[%d] %d\n", size - 1, cpid);
        }
        if (child == 0)
        {
            if (setpgid(0, 0) == -1)
            {
                return 1;
            }
            if (strlen(strings[0]) > 0)
                runCommand(strings[0]);
        }
    }
    else if (strstr(command, ">>") != NULL)
    {
        char **strings = tokenizeCommand(command,">>");
        char **execstring=tokenizeCommand(strings[0]," ");
        int len2=countLength(execstring);
        int len=countLength(strings);
        
        int child=fork();
        if ( child == 0)
        {
            int fd =open(strings[1], O_CREAT|O_RDWR | O_APPEND, 0777);
            dup2(fd, 1);
            execvp(execstring[0],execstring);
            close(fd);
        }
        else
        {
            // wait(NULL);
            waitpid(child, NULL, 0);
        }
    }
    else if (strstr(command, ">") != NULL)
    {
        char **strings = tokenizeCommand(command,">");
        char **execstring=tokenizeCommand(strings[0]," ");
        int len2=countLength(execstring);
        int len=countLength(strings);
        
        int child=fork();
        if ( child == 0)
        {
            
            int fd =open(strings[1], O_CREAT|O_RDWR, 0777);
            close(fd);
            // close(fd);
            // ftruncate(fd, 0);
            unlink(strings[1]);
            // close(fd);
            int fd2 =open(strings[1], O_CREAT|O_RDWR, 0777);
            dup2(fd2, 1);
            execvp(execstring[0],execstring);
            close(fd2);
        }
        else
        {
            // wait(NULL);
            waitpid(child, NULL, 0);
        }
    }
    else if(strstr(command, "<") != NULL)
    {
        char **strings = tokenizeCommand(command,"<");
        char **execstring=tokenizeCommand(strings[0]," ");
        int len2=countLength(execstring);
        int len=countLength(strings);
        
        int child=fork();
        if ( child == 0)
        {
            
            int fd =open(strings[1], O_RDONLY, 0777);
            dup2(fd, 0);
            execvp(execstring[0],execstring);
            close(fd);
        }
        else
        {
            // wait(NULL);
            waitpid(child, NULL, 0);
        }
    }
    else if (strstr(command, ";") != NULL)
    {
        char **strings = tokenizeCommand(command,";");
        int len=countLength(strings);
        execute(strings,len,0);
    }
    else if (strstr(command, "#") != NULL)
    {
        char **strings = tokenizeCommand(command,"#");
        int len=countLength(strings);
        char **modified_array = addCatPrefix(strings, len);
        // for (size_t i = 0; i < len; i++)
        // {
            execute(modified_array,len,0);
            printf("\n");
        // }
        
        
    }
        else if (strstr(command, "|") != NULL)
    {
        printf("HELLO FROM PIPE\n");
        char **strings = tokenizeCommand(command,"|");
        int len=countLength(strings);
        executePipe(strings, len);
        // char **modified_array = addCatPrefix(strings, len);
        // // for (size_t i = 0; i < len; i++)
        // // {
        //     execute(modified_array,len,0);
        //     printf("\n");
        // // }
        
        
    }     
    else if (strstr(command, "exit\n") != NULL)
    {
        exit(0);
    }
    else
    {
        printf("in else: \n");
        forkCommand(trimString(command));
    }

    
    

    
}

// Helper method to run sequential piping operations and redirecting output of first to the next pipe until the end
void executePipe(char **commands, int num_commands)
{
    int prev_pipe[2], next_pipe[2];
    int i;

    // Loop through commands
    for (i = 0; i < num_commands; i++)
    {
        // Initialize the next pipe
        if (i < num_commands - 1 && pipe(next_pipe) == -1)
        {
            perror("pipe");
            exit(EXIT_FAILURE);
        }

        // Fork a child process
        int pid = fork();
        if (pid == -1)
        {
            perror("fork");
            exit(EXIT_FAILURE);
        }
        else if (pid == 0)
        { // Child process
            // Set up redirection
            if (i > 0)
            {
                dup2(prev_pipe[0], 0); // Set input from previous pipe
                close(prev_pipe[1]);   // Close write end of previous pipe
            }
            if (i < num_commands - 1)
            {
                close(next_pipe[0]);   // Close read end of next pipe
                dup2(next_pipe[1], 1); // Set output to next pipe
            }

            // Close pipe ends not needed by this process
            if (i > 0)
            {
                close(prev_pipe[0]);
            }
            if (i < num_commands - 1)
            {
                close(next_pipe[1]);
            }

            // Execute command
            runCommand(commands[i]);
            exit(EXIT_SUCCESS); // Exit child process after command execution
        }
        else
        { // Parent process
            // Close previous pipe if it's not the first command
            if (i > 0)
            {
                close(prev_pipe[0]);
                close(prev_pipe[1]);
            }

            // Set up next pipe if it's not the last command
            if (i < num_commands - 1)
            {
                prev_pipe[0] = next_pipe[0];
                prev_pipe[1] = next_pipe[1];
            }
        }
        waitpid(pid,NULL,0);
    }

    // // Wait for all child processes to finish
    // for (i = 0; i < num_commands; i++)
    // {
    //     wait(NULL); // Wait for any child process
    // }
}

int runCommand(const char *command) {
    // Duplicate the command
    char *args[COMMAND_LENGTH];
    int i = 0;

    // Tokenize the input command based on space
    char *token = strtok(strdup(command), " ");
    while (token != NULL) {
        args[i++] = token;
        token = strtok(NULL, " ");
    }
    args[i] = NULL; // Set the last argument to NULL

    // Execute the command using execvp
    if (execvp(args[0], args) == -1) {
        printf("Command '%s' not found\n", args[0]);
        return 0;
    }
    // return 1; // Return 1 if execution is successful (This line is added for consistency)
}

void runChainingAndOr(char **commands, int num_commands)
{
    // Runs the first command
    int prev = forkCommand(commands[0]);

    // Iterate through commands
    for (int i = 1; i < num_commands; i += 2)
    {
        if (prev == 1 && strstr(commands[i], "&&") != NULL)
        {
            prev = runCommand(trimString(commands[i + 1])) == 0 ? 0 : 1;
        }
        else if (prev == 0 && strstr(commands[i], "||") != NULL)
        {
            prev = runCommand(trimString(commands[i + 1])) == 0 ? 0 : 1;
        }
    }
}
// Executes commands sequentially
void execute(char **commands, int len, int stopOnFailure)
{   
    int i=0;
    while(i<len)
    {
        int pid = fork();
        if(pid>0)
        {
            int status;
            wait(&status);
            if (WEXITSTATUS(status) == 30)
            {
                if (stopOnFailure)
                    break;
            }
        }
        else
        { // Child process

            if (runCommand(commands[i]) == 0)
            {
                printf("%s command failed to execute \n", commands[i]);
                exit(30);
            }
        }
    i++;
    }
}

// Uses the runCommand function to execute command, alonside also returns a status of exectuion of the command
int forkCommand(char *command)
{
    // Fork a child process
    int pid = fork();
    if (pid == -1)
    {
        printf("Failed to fork");
        exit(0);
    }
    else if (pid > 0)
    { // parent
                int status;
        waitpid(pid, &status, NULL);
        if (WIFEXITED(status))
        {
            if(WEXITSTATUS(status) == 0){
            return 1;
            }
        }
        return 0;
    }
    else
    {

        // Execute the command
        if (runCommand(command) == 0)
        {
            // In case of failure return -1
            exit(30);
        }

    }
}

int start(){
    char command[COMMAND_LENGTH];
    // terminal_id = "1.txt";
    terminal_id = generateRandomStringForBashId(10);
    // printf("%s\n",terminal_id);
    asprintf(&process_file, "fg_%s", terminal_id);
    // printf("\n");
    // printf("%s",process_file);
    // printf("\n");
    
     while (strcmp(command, "exit") != 0)
    {
        printf("shell24$ ");
        fgets(command, COMMAND_LENGTH, stdin);
        if (strstr(strdup(command), "cd") != NULL)
        {
            // handleCd(command);
            continue;
        }
        // printf("1");
        // printf("commmand %s\n",command);
        // printf("2");
        // printf("2");
        // printf("process_file %s\n",process_file);
        // printf("hello from start\n");
        handleCommands(command, terminal_id);
    }
    unlink(terminal_id);
    return 0;
    
}

int main(int argc, char const *argv[])
{
    signal(SIGINT,handler);
    start();
    return 0;
}
