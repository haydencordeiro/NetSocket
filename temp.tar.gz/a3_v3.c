#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>

#define MAX_TOKENS 100
#define MAX_TOKEN_LEN 50
// Function to separate input based on '&&' and '||' and store in an array
void separateAndStore(char *input, char *output[]) {
    int i = 0;
    int index = 0;
    int tokenStart = 0;
    int len = strlen(input);

    while (i < len && index < MAX_TOKENS - 1) {
        if (input[i] == '&' && input[i + 1] == '&' && (i + 2 == len || input[i + 2] == ' ')) {
            if (i > tokenStart) {
                output[index] = malloc((i - tokenStart + 1) * sizeof(char));
                if (output[index] == NULL) {
                    perror("Memory allocation failed");
                    exit(EXIT_FAILURE);
                }
                strncpy(output[index], input + tokenStart, i - tokenStart);
                output[index][i - tokenStart] = '\0';
                index++;
            }
            output[index++] = "&&";
            i += 2; // Skip '&&'
            tokenStart = i + 1;
        } else if (input[i] == '|' && input[i + 1] == '|' && (i + 2 == len || input[i + 2] == ' ')) {
            if (i > tokenStart) {
                output[index] = malloc((i - tokenStart + 1) * sizeof(char));
                if (output[index] == NULL) {
                    perror("Memory allocation failed");
                    exit(EXIT_FAILURE);
                }
                strncpy(output[index], input + tokenStart, i - tokenStart);
                output[index][i - tokenStart] = '\0';
                index++;
            }
            output[index++] = "||";
            i += 2; // Skip '||'
            tokenStart = i + 1;
        }
        i++;
    }

    if (i > tokenStart) {
        output[index] = malloc((i - tokenStart + 1) * sizeof(char));
        if (output[index] == NULL) {
            perror("Memory allocation failed");
            exit(EXIT_FAILURE);
        }
        strncpy(output[index], input + tokenStart, i - tokenStart);
        output[index][i - tokenStart] = '\0';
        index++;
    }

    output[index] = NULL; // Null-terminate the array
}

// void infinite_loop() {
//     while(1) {
//         // Do whatever you need in the loop
//         printf("Child process executing...\n");
//         sleep(1); // Sleep for 1 second
//     }
// }


// Function to tokenize a string based on a delimiter
char** tokenize_string(const char* str, const char* delim, int* token_count) {
    char** tokens = NULL;
    char* token;
    int count = 0;
    char* str_copy = strdup(str); // Make a copy of the string to avoid modifying the original

    // Tokenize the string using strtok
    token = strtok(str_copy, delim);
    while (token != NULL) {
        tokens = realloc(tokens, (count + 1) * sizeof(char*)); // Allocate memory for each token
        if (tokens == NULL) {
            perror("realloc");
            exit(EXIT_FAILURE);
        }
        tokens[count] = strdup(token); // Copy token into the array of tokens
        token = strtok(NULL, delim);
        count++;
    }

    free(str_copy); // Free the memory allocated for the copied string
    *token_count = count; // Set the token count
    return tokens;
}
void handleUserInput(char *string)
{

    if (strstr(string, ";") != NULL)
    {
        printf(" ;  option  string breakdown:\n");
        int token_count;
        char** tokens=tokenize_string(string, ";",token_count);
        //
            if (tokens != NULL) {
            printf("Tokens:\n");
            for (int i = 0; i < token_count; ++i) {
                printf("%s\n", tokens[i]);
                free(tokens[i]); // Free memory allocated for each token
            }
            free(tokens); // Free memory allocated for array of tokens
        } else {
            printf("No tokens found.\n");
        }
        //

        // sequentialExecution(tokens,token_count);
    }
    // else{
    //     exit(0);
    // }
}


int main() {
    // signal(SIGINT, siginthandler);
    // char input[] = "ls -1 -t && yoloy && grep a.c && folor";
    // char *output[MAX_TOKENS];

    // separateAndStore(input, output);

    // // Printing the stored tokens
    // for (int i = 0; output[i] != NULL; i++) {
    //     printf("%s\n", output[i]);
    //     // No need to free the memory, as no dynamic allocation is done
    // }

    char input[1000]; // Assuming maximum input length of 100 characters
    // Take input from the user
    while (1)
    {
        printf("Enter a string: ");
        fgets(input, sizeof(input), stdin);
        if (strcmp(input, "exit\n") == 0)
        {
            exit(0);
        }
        

        pid_t child_pid = fork();

        if (child_pid == -1) {
            // Fork failed
            perror("fork");
            exit(EXIT_FAILURE);
        } else if (child_pid == 0) {
            // Child process
            printf("Child process created.\n");
            // infinite_loop();
            handleUserInput(input); // Call the function for infinite loop
            exit(0);
        } else {
            // Parent process
            printf("Parent process waiting...\n");
            // Wait for the child process to finish
            int status;
            wait(&status);
            printf("Child process finished with status %d. Exiting parent process.\n",status);
        }
    }
    
   
    return 0;
}
