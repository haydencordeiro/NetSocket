// sequential done
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <pwd.h>


#define COMMAND_LENGTH 1000
#define MAX_PROCESS_COUNT 100
#define TOTAL_ARGUMENTS 5
char *terminal_id;
char *process_file;
int last_value;

int countLength(char **arr)
{
    int i = 0;
    while (arr[i] != NULL)
    {
        i += 1;
    }
    return i;
}

char **tokenizeCommand(char *str, char *delimiter)
{
    int count = 0;
    char **tokens = (char **)malloc(TOTAL_ARGUMENTS * sizeof(char *));
    if (tokens == NULL)
    {
        // fprintf(stderr, "Memory allocation error\n");
        return NULL;
    }

    // Tokenize the string
    char *token = strtok(str, delimiter);
    while (token != NULL)
    {
        // Allocate memory
        tokens[count] = (char *)malloc((strlen(token) + 1) * sizeof(char));
        if (tokens[count] == NULL)
        {
            // fprintf(stderr, "Memory allocation error\n");
            for (int i = 0; i < count; i++)
                free(tokens[i]);
            free(tokens);
            return NULL;
        }

        // Copy token to tokens array and strip leading/trailing spaces
        int i = 0, j = strlen(token) - 1;
        while (isspace(token[i]))
            i++;
        while (j >= 0 && isspace(token[j]))
            j--;
        strncpy(tokens[count], token + i, j - i + 1);
        tokens[count][j - i + 1] = '\0';

        count++;
        token = strtok(NULL, delimiter);
    }

    // Add NULL to indicate end
    tokens[count] = NULL;
    return tokens;
}

char *trimString(char *str) {
    char *end;

    // Skip leading spaces
    while (isspace((unsigned char)*str))
        str++;

    // If the string is empty or contains only spaces
    if (*str == '\0')
        return str;

    // Trim trailing spaces
    end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char)*end))
        end--;

    // Null-terminate the trimmed string
    *(end + 1) = '\0';

    return str;
}

// int getLenght(int *p)
// {
//     // variable that holds the lenght of the string
//     int c = 0;
//     // iterating till -2 (-2 denotes the end of the array)
//     for (int i = 0; p[i] != -2; i++)
//     {
//         c += 1;
//     }
//     c += 1;
//     return c;
// }


void readTopmostBgProcess(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Unable to open file.\n");
        return;
    }

    // Read values from the file
    int values[1000]; // Assuming maximum 1000 values
    int count = 0;
    while (fscanf(file, "%d", &values[count]) == 1) {
        count++;
    }

    if (count > 0) {
        // Get the last value
        last_value = values[count - 1];

        // Rewind the file to overwrite it
        fclose(file);
        file = fopen(filename, "w");

        // Write the remaining values back to the file, excluding the last one
        for (int i = 0; i < count - 1; i++) {
            fprintf(file, "%d\n", values[i]);
        }
    } else {
        printf("File is empty.\n");
    }

    fclose(file);
}

// char* generateRandomStringForBashId(int length) {
//     const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
//     char* randomString = (char*)malloc((length + 1) * sizeof(char));
//     if (randomString == NULL) {
//         fprintf(stderr, "Memory allocation failed\n");
//         exit(1);
//     }

//     srand((unsigned int)time(NULL));

//     for (int i = 0; i < length; ++i) {
//         randomString[i] = charset[rand() % (sizeof(charset) - 1)];
//     }
//     randomString[length] = '\0';
//     return randomString;
// }

char* generateRandomStringForBashId(int length) {
    const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    char* randomString = (char*)malloc((length + 5) * sizeof(char)); // Additional space for ".txt\0"
    if (randomString == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(1);
    }

    srand((unsigned int)time(NULL));

    for (int i = 0; i < length; ++i) {
        randomString[i] = charset[rand() % (sizeof(charset) - 1)];
    }

    // Append ".txt" at the end
    strcpy(randomString + length, ".txt");

    return randomString;
}

// check if the filename exists or not 
int checkIfFilePresent(const char *filename) {
    // Check if the file exists by trying to access it in read mode
    if (access(filename, F_OK) != -1) {
        // File exists
        return 1;
    } else {
        // File does not exist
        return 0;
    }
}

char** tokenizeString(const char* str, const char* delimiter) {
    char** tokens = NULL;
    char* token = strtok(strdup(str), delimiter);
    int tokenCount = 0;

    // Count tokens
    while (token != NULL) {
        token = strtok(NULL, delimiter);
        tokenCount++;
    }

    // Allocate memory for token array
    tokens = (char**)malloc(tokenCount * sizeof(char*));
    if (tokens == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(1);
    }

    // Split string and store tokens
    token = strtok((char*)str, delimiter);
    for (int i = 0; i < tokenCount; i++) {
        // Strip leading spaces
        while (isspace(*token)) {
            token++;
        }

        // Strip trailing spaces
        char* end = token + strlen(token) - 1;
        while (end > token && isspace(*end)) {
            *end = '\0';
            end--;
        }

        tokens[i] = token;
        token = strtok(NULL, delimiter);
    }

    // Set count
    // *count = tokenCount;

    return tokens;
}

int* readProcessIDsFromFile(const char* filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        fprintf(stderr, "Error opening file: %s\n", filename);
        exit(1);
    }

    // Allocate memory for storing process IDs
    int* processIDs = (int*)malloc(MAX_PROCESS_COUNT * sizeof(int));
    if (processIDs == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(1);
    }

    int count = 0;
    int id;
    // Read process IDs from the file
    while (fscanf(file, "%d", &id) == 1) {
        processIDs[count] = id;
        (count)++;
        if (count >= MAX_PROCESS_COUNT) {
            fprintf(stderr, "Maximum number of process IDs exceeded\n");
            exit(1);
        }
    }

    fclose(file);
    return processIDs;
}
// kill recent process
int handler(){
    if (checkIfFilePresent(process_file))
    {
        // int * process_ids=readProcessIDsFromFile(process_file);
        // printf("%d",process_ids[0]);
        printf("KILL PROCESS %d\n",last_value);
        kill(last_value, SIGINT);
    }
    printf("\n");
}

void writeProcessIDToFile(const char* filename, int processID) {
    FILE *file = fopen(filename, "a"); // Open file in append mode
    if (file == NULL) {
        fprintf(stderr, "Error opening file: %s\n", filename);
        return;
    }

    // Write process ID to file
    fprintf(file, "%d\n", processID);

    fclose(file);
}

void handleCommands(char *command, char *terminal_id){
    printf("hello from handle commands\n");
    if (strstr(command,"fg")!=NULL)
    {
        if (!checkIfFilePresent(terminal_id))
        {
            printf("file does not exist\n");
            return;
        }
        // int *pids = readProcessIDsFromFile(terminal_id);
        readTopmostBgProcess(terminal_id);
        printf("last value %d\n",last_value);
        // int tLen = strlen(terminal_id);
        // unlink(terminal_id);
        // int l = getLenght(pids);
        // for (int i = 0; pids[i] != -2; i++)
        // {
        //     // check if the process belongs to the current process tree
        //     if (i == l - 2)
        //     {
        //         writeProcessIDToFile(process_file,pids[i]);
                wait(NULL);
        //     }
        //     else
        //     {
        //         // if no add it back to the file
        //         writeProcessIDToFile(terminal_id,pids[i]);
        //     }
        // }
        
    }
    else if (strstr(command,"&")!=NULL)
    {
        printf("hello");
        char **strings = tokenizeString(command, "&");
        signal(SIGINT, handler);
        int child = fork();
        if (child > 0)
        {
            if (strlen(strings[0]) > 0)
                writeProcessIDToFile(terminal_id,child);
            // To print which order it is inthe stack
            // int *pids = readProcessIDsFromFile(terminal_id);
            // int size = sizeof(pids) / sizeof(pids[0]);
            // printf("[%d] %d\n", size - 1, cpid);
        }
        if (child == 0)
        {
            if (setpgid(0, 0) == -1)
            {
                return 1;
            }
            if (strlen(strings[0]) > 0)
                runCommand(strings[0]);
        }
    }
    else if (strstr(command, ";") != NULL)
    {
        char **strings = tokenizeCommand(command,";");
        int len=countLength(strings);
        execute(strings,len,0);


    }
    
    else if (strstr(command, "exit\n") != NULL)
    {
        exit(0);
    }
    else
    {
        printf("in else: \n");
        forkCommand(trimString(command));
    }

    
    

    
}


int runCommand(const char *command) {
    // Duplicate the command
    char *args[COMMAND_LENGTH];
    int i = 0;

    // Tokenize the input command based on space
    char *token = strtok(strdup(command), " ");
    while (token != NULL) {
        args[i++] = token;
        token = strtok(NULL, " ");
    }
    args[i] = NULL; // Set the last argument to NULL

    // Execute the command using execvp
    if (execvp(args[0], args) == -1) {
        printf("Command '%s' not found\n", args[0]);
        return 0;
    }
    // return 1; // Return 1 if execution is successful (This line is added for consistency)
}

// Executes commands sequentially
void execute(char **commands, int len, int stopOnFailure)
{   
    int i=0;
    while(i<len)
    {
        int pid = fork();
        if(pid>0)
        {
            int status;
            wait(&status);
            if (WEXITSTATUS(status) == 10)
            {
                if (stopOnFailure)
                    break;
            }
        }
        else
        { // Child process

            if (runCommand(commands[i]) == 0)
            {
                printf("%s command failed to execute \n", commands[i]);
                exit(10);
            }
        }
    i++;
    }
}

// Uses the runCommand function to execute command, alonside also returns a status of exectuion of the command
int forkCommand(char *command)
{
    // Fork a child process
    int pid = fork();
    if (pid == -1)
    {
        printf("Failed to fork");
        exit(0);
    }
    else if (pid == 0)
    { // Child process

        // Execute the command
        if (runCommand(command) == 0)
        {
            // In case of failure return -1
            exit(10);
        }
    }
    else
    {
        int status;
        waitpid(pid, &status, NULL);
        if (WIFEXITED(status))
        {
            if(WEXITSTATUS(status) == 0){
            return 1;
            }
        }
        return 0;
    }
}

int start(){
    char command[COMMAND_LENGTH];
    // terminal_id = "1.txt";
    terminal_id = generateRandomStringForBashId(10);
    // printf("%s\n",terminal_id);
    asprintf(&process_file, "fg_%s", terminal_id);
    // printf("\n");
    // printf("%s",process_file);
    // printf("\n");
    
     while (strcmp(command, "exit") != 0)
    {
        printf("shell24$ ");
        fgets(command, COMMAND_LENGTH, stdin);
        if (strstr(strdup(command), "cd") != NULL)
        {
            // handleCd(command);
            continue;
        }
        printf("1");
        printf("commmand %s\n",command);
        printf("2");
        printf("2");
        // printf("process_file %s\n",process_file);
        printf("hello from start\n");
        handleCommands(command, terminal_id);
    }
    unlink(terminal_id);
    return 0;
    
}

int main(int argc, char const *argv[])
{
    signal(SIGINT,handler);
    start();
    return 0;
}
