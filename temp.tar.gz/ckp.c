#include <stdio.h>
#include <stdlib.h> 
#include <sys/signal.h> 
#include <sys/types.h>
#include <signal.h>

int main(int argc, char *argv[]){ //ckp.c //Child sends SIGINT toparent
pid_t pid;
if((pid=fork()) > 0){ //Parent Process
int i=0;
for(;;){
printf("Parent process id is %d\n", getpid());
sleep(2);
}
}
else{ //Child Process
int k=0;
for(;;){
if(k==5){
printf("The parent process will now be kiled by the child process\n");
kill(getppid(),SIGINT);
}
printf("Child process id is %d\n", getpid());
sleep(2);
k=k+1;
}//End for
}
}
