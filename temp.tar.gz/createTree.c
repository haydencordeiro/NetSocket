#include <stdio.h>

int create_child_for_a;
int create_child_for_bs_child;
int create_child_for_createchildforc;
int lastchild1;
int lastchild2;
// int child_of_child_of_c;

int main(){
    
    int a = fork();
    int b = fork();
    int c = fork();
    if (a == 0 && b > 0 && c > 0)
    {
        create_child_for_a=fork();
    }

    if (a > 0 && b == 0 && c == 0)
    {
        create_child_for_bs_child=fork();
    }

    if (a==0 && b==0 && c==0 )
    {
        int lastchild1=fork();
        if(lastchild1==0)
        {

        }
        else{
            lastchild2=fork();
        }
        
    }
    if (a>0 && b>0 && c==0)
    {
        exit(0);
    }
    if (a == 0 && b>0 && c>0 && create_child_for_a ==0 )
    {   
        exit(0);
    }
    if (a == 0 && b == 0 && c == 0 && lastchild1 == 0 )
    {
        printf("3");
        exit(0);
    }

      
    for (;; )
    {
        // infinite loop
    }
    
    sleep(600);



    return 0;

}



    // if (a=0 && b>0 && c>0)
    // {
    //     int a1morechild=fork();
    // }
    // if (a>0 && b>0 && c==0)
    // {
    //     child_of_c=fork();
    // }

    // if (child_of_c==0 &&a>0 && b>0 && c>0)
    // {
    //     int child_of_child_of_c=fork();
    // }

    // if (a==0 && b>0 && c==0)
    // {
    //     int create_second_last=fork();
    //     int create_last_child=fork();

    // }