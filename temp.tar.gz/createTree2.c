#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>

int main(){
    int p1,p2,p3,p4,p5;
    p1 = fork();
    p2 = fork();
    p3 = fork();
    int p6 = -1;
    if(p6>0){
        fork();
    }
    else if(p1 == 0 && p2 >0 && p3 > 0 ){
        p4 = fork();
        if(p4==0)
        exit(0);

    }

    else if(p1 >0 && p2 ==0 && p3 ==0){
         p5 = fork();
        //  exit(0);

    }
    else if(p1 >0 && p2 ==0 && p3 ==0){
         p5 = fork();
        //  exit(0);

    }
    else if(p1==0 && p2==0 && p3==0){
        p6 = fork();
        if(p6 > 0){
            int p7 = fork();
            if(p7 ==0)
            exit(0);
        }
    }
    else if(p1 > 0 && p2 >0 && p3 ==0){
        exit(0);
    }
    else if(p1==0 && p2>0 && p3 ==0 ){
        exit(0);
    }

    // for(;;);
    sleep(1200);
    


}