// Neel Manish Pandya       Student Id:110095825        ASP Section 1
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>

#define MAXIMUM_STR_LEN 512
#define ARGUMENT 128

int pro_Elapsed_Time = 1;      // Elapsed time for process termination
int num_Defunct_Cpro = 1;      // Number of defunct child processes
int sourceProcessID;           // ID of the root process
int arrayIndex = 0;            // Index for storing terminated process IDs
int timeStatus = 0;            // Flag indicating whether elapsed time option is enabled
int countStatus = 0;           // Flag indicating whether defunct child process count option is enabled

int processIDs[ARGUMENT];      // Array to store terminated process IDs

void termi_pro(pid_t proid)    // Function to terminate a process 
{
    kill(proid, SIGKILL);      // Using SIGKILL to kill the process
    printf("%d\n", proid);
}

int Defunct(pid_t proid)           // Function to check if a process is a zombie
{
    char comd[MAXIMUM_STR_LEN];
    snprintf(comd, MAXIMUM_STR_LEN, "ps -o stat %d", proid);
    FILE *filePointer = popen(comd, "r");
    if (filePointer == NULL) 
    {
        printf("\n ERROR: Failed to open pdr \n");
        return 1;
    }
    char str[512];
    fgets(str, sizeof(str), filePointer);

    if (fgets(str, sizeof(str), filePointer) != NULL) 
    {
        char status = str[0];
        if (status == 'Z') {
            pclose(filePointer);
            return 1;
        }
    }
    pclose(filePointer);
    return 0;
}


void manage_chld_pro(pid_t proid, pid_t excludeProcessID)    // Function to handle child processes
 {
    char comd[MAXIMUM_STR_LEN];
    snprintf(comd, MAXIMUM_STR_LEN, "pgrep -P %d", proid);

    FILE *filePointer = popen(comd, "r");
    if (filePointer == NULL) {
        perror("popen");
        exit(EXIT_FAILURE);
    }

    char str[512];
    int zombieCount = 0;

    while (fgets(str, sizeof(str), filePointer) != NULL) {
        int childPID = atoi(str);

        if (Defunct(childPID)) {
            if (excludeProcessID != proid) {
                processIDs[arrayIndex] = proid;
                arrayIndex++;
            }
            zombieCount++;
        }
    }

    pclose(filePointer);

    if (zombieCount >= num_Defunct_Cpro && countStatus == 1 && excludeProcessID != proid) {
        processIDs[arrayIndex] = proid;
        arrayIndex++;
    }
}

void parseTree(pid_t proid, pid_t excludeProcessID)  // Recursive function to traverse the process tree
    {
    manage_chld_pro(proid, excludeProcessID);

    char comd[MAXIMUM_STR_LEN];
    snprintf(comd, MAXIMUM_STR_LEN, "pgrep -P %d", proid);

    FILE *filePointer = popen(comd, "r");
    char str[512];
    while (fgets(str, sizeof(str), filePointer) != NULL) {
        int childPID = atoi(str);
        parseTree(childPID, excludeProcessID);
    }

    pclose(filePointer);

    if (proid == sourceProcessID) {
        for (int z = 0; z < ARGUMENT; z++) {
            if (processIDs[z] != 0) {
                termi_pro(processIDs[z]);
            }
        }
    }
}

int main(int argc, char *argv[]) {     // Main function
    if (argc < 2) {
        printf("Usage: %s [root_process] [OPTION1] [OPTION2] [-excludeProcessID]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    pid_t source_proid = atoi(argv[1]);
    pid_t excludeProcessID = 0;
    if (source_proid <= 0) {
        printf("\n This is Invalid root process ID\n");
        exit(EXIT_FAILURE);
    }

    int z;
    for (z = 2; z < argc; z++) {
        if (strcmp(argv[z], "-t") == 0 && z + 1 < argc)        // for elapse time -t
            {
            timeStatus = 1;
            pro_Elapsed_Time = atoi(argv[++z]);
            if (pro_Elapsed_Time < 1) {
                printf("\n This is Invalid Elapsed Time\n");
                exit(EXIT_FAILURE);
            }
        } else if (strcmp(argv[z], "-b") == 0 && z + 1 < argc)   // for killing defunct processes -b
            {
            countStatus = 1;
            num_Defunct_Cpro = atoi(argv[++z]);
            if (num_Defunct_Cpro < 1) {
                printf("\n This is Invalid number of defunct child processes\n");
                exit(EXIT_FAILURE);
            }
        } else {
            printf("It is Invalid option: %s\n", argv[z]);
            exit(EXIT_FAILURE);
        }

        if (strcmp(argv[z], "-t") != 0 && z + 1 < argc && strcmp(argv[z], "-b") != 0) {
            excludeProcessID = atoi(argv[z]);
        }
    }

    sourceProcessID = source_proid;
    parseTree(source_proid, excludeProcessID);

    exit(EXIT_SUCCESS);
}

