// group.c  using kill(0,SIGINT)
#include <stdio.h>
#include <stdlib.h>
#include <sys/signal.h>
main()
{
int a;
int main_pid=getpid();
a=fork();
a=fork();
a=fork();
if(getpid()==main_pid){
sleep(12);
printf("Main sends SIGINT to the entire group\n");
kill(0,SIGINT);
}
else
for(;;);
}
