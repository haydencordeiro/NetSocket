#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

void test(int **ptr){
    *ptr = (int *)malloc(4*sizeof(int));
    // *(ptr) = 1;


}

int main(){
    int *ptr;
    test(&ptr);
    printf("%d", *(ptr));
}