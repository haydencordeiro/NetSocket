#include<stdio.h>
int main(){
    printf("hello\n");
    return 0;
}