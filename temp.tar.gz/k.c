#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>

//function1 for thread 1
void *func1(void *p){
	printf(" %s \n",(char *)p);
	//print thread id
	printf(" Thread 1 : %lu \n",pthread_self());
	pthread_exit(NULL);
}

// function2 for thread 2
void *func2(void *p){
	printf(" %s \n",(char *)p);
	//print the thead id
	printf(" Thread 2 : %lu \n",pthread_self());
	pthread_exit(NULL);
}

// function3 for thread 3
void *func3(void *p){
	printf(" %s \n",(char *)p);
	//print the thread id
	printf(" Thread 3 : %lu \n",pthread_self());
	pthread_exit(NULL);
}

// function4 for thread 4
void *func4(void *p){
	printf(" %s \n",(char *)p);
	//print the thread id
	printf(" Thread 4 : %lu \n",pthread_self());
	pthread_exit(NULL);
}

// function5 for thread 5
void *func5(void *p){
	printf(" %s \n",(char *)p);
	//print the thread id
	printf(" Thread 5 : %lu \n",pthread_self());
	pthread_exit(NULL);
}

int main(){
	char *msg = "Welcome To COMP8567-Winter 2024";
	pthread_t p1,p2,p3;
	void *r1,*r2,*r3;
	// create a thread p3
	pthread_create(&p3,NULL,func3,msg);
	// wait for p3 to complete
	pthread_join(p3,NULL);	
	// create a thread p1
	pthread_create(&p1,NULL,func1,msg);
	// wait for p1 to complete 
	pthread_join(p1,NULL);
	// create a thread p2
	pthread_create(&p2,NULL,func2,msg);
	// wait for p2 to complete
	pthread_join(p2,NULL);
	printf(" Main %lu \n",pthread_self());

	return 0;
}