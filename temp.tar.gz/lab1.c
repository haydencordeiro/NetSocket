#include<stdio.h>
#include<stdlib.h>
int *max(int* arr,int n){
    int*maximum=arr;
    for (int i = 0; i < n; i++)
    {
        if (*(arr+i)>*maximum)
        {
            maximum=arr+i;
        }
        
    }
    return maximum;
}

int main(){
    int n;
    printf("enter n \n");
    scanf("%d",&n);

    int *list=(int*)malloc(n*sizeof(int));
    if (list==NULL)
    {
        printf("unable to allocate memory");
        return 0;
    }
    
    for (int i = 0; i < n; i++)
    {
        scanf("%d",list+i);
    }

    printf("\n");
    printf("maximum value is %d \n",*(max(list,n)));
}