#include<stdio.h>
#include<pthread.h>

// Mutex step1 - GLobal Declaration
pthread_mutex_t lock;

// declare global variable
int num = 20;

// pointer to function that accepts generic pointer
void* decrement(void* val) {
    int* threadId = val;

    pthread_mutex_lock(&lock);
    // prints thread id and decrement num by one if it is joinable mode
    if (*threadId == PTHREAD_CREATE_JOINABLE) {
        num = num - 1;
        printf("\n Thread id : %lu n: %d ", pthread_self(), num);
    }
    else if (*threadId == PTHREAD_CREATE_DETACHED) {
        num = num - 2;
        printf("\n Thread id : %lu n: %d ", pthread_self(), num);
    }
    // release lock
    pthread_mutex_unlock(&lock);
    return NULL;
}

int main() {
    // threads array
    pthread_t threads[8];
    // detach array
    int d[8];
    // Initialize loop counter
    int j=0;
    while (j<8)
    {
        if (j % 2 == 0)
        {
            d[j] = PTHREAD_CREATE_JOINABLE;
        } 
        else
        {
            d[j] = PTHREAD_CREATE_DETACHED;
            
        }
        j++;
    }
    
    int i = 0;
    while (i < 8) {
        // declare and initialize thread attribute
        pthread_attr_t attr;
        pthread_attr_init(&attr);
        // create a thread in joinable and detached state
        pthread_attr_setdetachstate(&attr, d[i]);
        // create a thread
        pthread_create(&threads[i], &attr, decrement, (d + i));
        // destroy thread attribute
        pthread_attr_destroy(&attr);
        i++;
    }

    // Reset loop counter
    i = 0;
    while (i < 8) {
        // wait for the thread if it is created in joinable state
        if (d[i] == PTHREAD_CREATE_JOINABLE)
            pthread_join(threads[i], NULL);
        i++;
    }
    
    printf("\n the value of num  is :  %d \n", num);

    pthread_mutex_destroy(&lock);

    return 0;
}
