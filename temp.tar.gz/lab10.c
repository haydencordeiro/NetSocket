s#include <stdio.h>
#include <pthread.h>

pthread_mutex_t use_lock; // Declaration of lock
int t_cnt = 6; // Declared global variable for count

void* func(void* arg) 
{
    int isDetached = (int)arg;
    if (isDetached) { // Checking whether the thread is detached is detached or not
        pthread_mutex_lock(&use_lock); // Mutex - Lock mechanism 
        t_cnt--; // Will decrease count if the thread is detached
        printf("Thread Id is= %lu, The count is= %d\n", pthread_self(), t_cnt); // Print id of theread and the value of count
        pthread_mutex_unlock(&use_lock); // Mutex - Unlock Mechanism
    }
    
    return NULL;
}

int main() 
{    
    pthread_t thds[6]; // Declaration of thread
    pthread_attr_t attr; // Declaration of attr attribute
    pthread_mutex_init(&use_lock, NULL); // Mutex - Initialization mechanism
    pthread_attr_init(&attr); // Initialization of attr attribute with the thread
    int v = 0;

    for ( v = 0; v < 6; ++v) 
    { 
    	int pos = v+1;
    	int e = pos % 2;
    
    	if(e == 1){ // alternative create thread with detached
	    	int isDetached = 1; // Therads with detached
		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
		pthread_create(&thds[v], &attr, func, &isDetached);
    	}else{
	    	int isDetached = 0; // Therads without detached
		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
		pthread_create(&thds[v], &attr, func, &isDetached);
    	}
        
    }


    pthread_attr_destroy(&attr); // Using this we will destroy thread

    for ( v = 0; v < 6; ++v) {
        pthread_join(thds[v], NULL); // joining thread
    }

    pthread_mutex_destroy(&use_lock); // lock mechanism destroyed

    return 0;
}
