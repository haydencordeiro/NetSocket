#include <stdio.h>
#include <stdlib.h>

int main() {
    int n;
    int* ar;

    printf("Enter the number of elements: ");
    scanf("%d", &n);

    ar = (int*) malloc(n * sizeof(int));

    if (ar == NULL) {
        printf("Memory Allocation unsuccessful !!! Exit program\n");
        return 1;
    }

    printf("Enter the number elements:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &ar[i]);
    }

    printf("The Elements in Array:\n");
    for (int a = 0; a < n; a++) {
        printf("%d ", ar[a]);
    }
    printf("\n");

    printf("Elements in array after reversing it:\n");
    for (int a = n - 1; a >= 0; a--) {
        printf("%d ", *(ar + a));
    }
    printf("\n");

    free(ar);

    return 0;
}