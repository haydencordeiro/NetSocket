#include <stdio.h>
#include <stdlib.h>

int smallest2(int *n1, int *n2, int *n3, int *n4);
int largest2(int *n1, int *n2, int *n3, int *n4);
int difference(int smallest2, int largest2, int *n1, int *n2, int *n3, int *n4);



int main() {
 int num1 = rand();
int num2 = rand();
 int num3 = rand();
 int num4 = rand();

int result = difference(smallest2, largest2, &num1, &num2, &num3, &num4);
printf("Difference between second smallest and second largest: %d\n", result);

	int smallest = smallest2(&num1, &num2, &num3, &num4);
	int largest = largest2(&num1, &num2, &num3, &num4);
	printf("Smallest two numbers: %d, %d\n", smallest, smallest2(&num1, &num2, &num3, &num4));  
	printf("Largest two numbers: %d, %d\n", largest, largest2(&num1, &num2, &num3, &num4));
return 0;
}



int smallest2(int *n1, int *n2, int *n3, int *n4) {
int smallest = *n1;



if (*n2 < smallest)
smallest = *n2;
if (*n3 < smallest)
smallest = *n3;
if (*n4 < smallest)
smallest = *n4;



 int second_smallest = *n1;



if (*n1 != smallest && *n1 < second_smallest)
 second_smallest = *n1;
if (*n2 != smallest && *n2 < second_smallest)
second_smallest = *n2;
if (*n3 != smallest && *n3 < second_smallest)
second_smallest = *n3;
 if (*n4 != smallest && *n4 < second_smallest)
second_smallest = *n4;



 return second_smallest;
}



int largest2(int *n1, int *n2, int *n3, int *n4) {
int largest = *n1;



if (*n2 > largest)
largest = *n2;
if (*n3 > largest)
largest = *n3;
 if (*n4 > largest)
largest = *n4;



int second_largest = *n1;



if (*n1 != largest && *n1 > second_largest)
second_largest = *n1;
if (*n2 != largest && *n2 > second_largest)
 second_largest = *n2;
if (*n3 != largest && *n3 > second_largest)
 second_largest = *n3;
 if (*n4 != largest && *n4 > second_largest)
 second_largest = *n4;



 return second_largest;
}



int difference(int smallest2, int largest2, int *n1, int *n2, int *n3, int *n4) {
 return largest2 - smallest2;
}
