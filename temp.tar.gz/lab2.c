#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

int main(){
    umask(0000);
    int fd;
    fd=open("sample.txt",O_CREAT|O_RDWR,0777);

    char welcome[] = "Welcome to COMP 8567";
    long int n;
    n = write(fd, welcome, sizeof(welcome)-1);
    close(fd);

    fd = open("sample.txt", O_APPEND | O_RDWR);
    char ASP[] = "Advanced Systems Programming";
    n = write(fd, ASP, sizeof(ASP)-1);

    close(fd);

    fd = open("sample.txt", O_RDWR);
    char star[] = "*****";
    n = lseek(fd, 15, SEEK_SET);
    n = write(fd, star, sizeof(star)-1);

    n = lseek(fd, 10, SEEK_END);
    n = write(fd, star, sizeof(star)-1);

    n = lseek(fd, 5, SEEK_CUR);
    n = write(fd, star, sizeof(star)-1);

    n = lseek(fd, 0, SEEK_SET);
    char data;
    while(read(fd, &data, 1) >0){
        if(data == '\0'){
            lseek(fd, -1, SEEK_CUR);
            write(fd, "$", 1);
        }
    }
    close(fd);

    fd = open("sample.txt", O_RDONLY);
    char line[10];
    n = lseek(fd, 0, SEEK_SET);
    int count = 0;
    while(read(fd,line,10)>0){
        printf("\n %s",line);
        count+=sizeof(line);
    }
    printf("Length of file: %d", count);
    close(fd);
    
}