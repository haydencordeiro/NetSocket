#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <string.h>
#include <signal.h>

int main() {
    int num1 = 10, num2 = 20, num3 = 30;
    int fd = open("sample.txt", O_RDWR | O_CREAT, 0777);

    if (fd == -1) {
        perror("\n Error in opening file");
        exit(1);
    }

    int child;

    child = fork();
    child = fork();
    child =fork();
    if (child == -1) {
        printf("Error creating child process");
        exit(1);
    } else if (child == 0) {
        char message[] = "COMP 8567";
        write(fd, message, strlen(message));

        for (int i = 0; i < 15; i++) {
            printf("Child : PID = %d, PPID = %d\n", getpid(), getppid());
            sleep(1);
        }

        num1 += 10;
        num2 += 10;
        num3 += 10;

        printf("num1 = %d, num2 = %d, num3 = %d\n", num1, num2, num3);
        exit(0);
    }else{
	    // Parent process
	    int status;
	    pid_t completedChild = wait(&status);
	   

	    if (WIFEXITED(status)) {
		printf("Child process with PID %d completed normally. Exit status: %d\n", completedChild, WEXITSTATUS(status));
	    } else if (WIFSIGNALED(status)) {
		printf("Child process with PID %d terminated by signal. Signal number: %d\n", completedChild, WTERMSIG(status));
	    }

	    char message[] = "HELLO! FROM PARENT";
	    write(fd, message, strlen(message));
	    close(fd);

	    num1 += 25;
	    num2 += 25;
	    num3 += 25;

	    printf("Parent: num1 = %d, num2 = %d, num3 = %d\n", num1, num2, num3);
    }

    return 0;
}
