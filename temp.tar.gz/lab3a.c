#include<stdio.h>
#include<unistd.h>
int main(){
//three consecutive system calls;
int a = fork();
int b = fork();
int c = fork();



if(a==-1){
printf("error while in fork ");
}
// first level
if (a!=0 && b!=0 && c!=0)
{
	printf(" PID :  %d , PPID : %d \n", getpid(),getppid());
}
// second level
if((a==0 && b!=0 && c!=0) ||(a!=0 &&  b==0 && c!=0) || (a!=0 && b!=0 && c==0)){
	//print pid an ppid;
 printf(" PID :  %d , PPID : %d \n", getpid(),getppid());
}

//third level
if((a==0 && b==0 && c!=0) ||(a==0 &&  b==0 && c==0) || (a!=0 && b==0 && c==0)){
	//print pid an ppid;
 printf(" PID :  %d , PPID : %d \n", getpid(),getppid());
}
return 0;
}
