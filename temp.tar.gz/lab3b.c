#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<stdlib.h>

int main(){
//fork system to create child process
int a = fork();

if(a==-1){
printf("\n error while forking \n");
}else if(a==0){
  int option;
  printf("please choose an option \n");
  printf("1. User Input 1\n");
  printf("2. User Input 2\n");
  printf("3. User Input 3\n");
  //read from the user input
  scanf("%d",&option);
  if(option==3){
   	int num = 89/0; 
  }else if(option==2){
     	exit(68);
  }
}else{
   // take status value of child based on user input
   int status ;
   int childPID = wait(&status);
   // if for normal termination WIFEXITED status is true
   if(WIFEXITED(status)){
	   printf("normal termination of child pid %d and return value is %d \n", childPID,WEXITSTATUS(status));
   }else{
     // abnormal ternimation and print signal value
	   printf("abonormal termination of child pid %d and signal value is %d \n", childPID, WTERMSIG(status));
   }
}


return 0;
}

