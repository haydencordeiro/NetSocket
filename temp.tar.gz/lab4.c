#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>


int main(){

int a = fork();
int b = fork();
int c = fork();

int c2PID ;
if(a>0 && b==0 && c>0){
  c2PID = getpid();
  printf("\n c2PID : %d \n",c2PID);
}

// printf(" hellp %d,%d",b,c2PID);
if(a>0 && b>0 && c>0){
		
		// int c2PID = getpid();
		printf("\n Main waiting for c2");
		int status; 
		int ret = waitpid(c2PID,&status,0);
		if(WIFEXITED(status)){
			printf("\n Normal termination %d",WEXITSTATUS(status));
		}else{
			printf("\n Abnormal termination %d",WTERMSIG(status));
		}
}else if(a>0 && b==0 && c>0){
	
	printf("C2 will now differentiate");
	if(chdir("/home/jivin/chapter5/child2")==-1){
		printf("\n Unable to change directory\n ");
	}else{
		printf("I am here");
		char *program = "ls";
		char *args[] = {"ls","-1",NULL};
		int ex = execvp(program,args);
		if(ex==-1){
			printf("\n error \n");
		}
	}
}

}
