#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    pid_t c1, c2, gc;

    // Fork C2
    c2 = fork();

    if (c2 < 0) {
        // Error occurred while forking C2
        perror("Fork failed for C2");
        exit(1);
    } else if (c2 == 0) {
        // c2 process execution

        // ls -1 /home/neelpandya
        execl("/bin/ls", "ls", "-1", "/home/neelpandya", NULL);

        // if error occurs execl() will return
        printf("execl() function failed");
        exit(1);
    } else {
        // MAIN process

        // Fork GC
        gc = fork();

        if (gc < 0) {
            // Error occurred while forking GC
            printf("The fork is failed for Grandchild GC");
            exit(1);
        } else if (gc == 0) {
            // gc process execution

            // Wait for C2 process to complete
            int status;
            waitpid(c2, &status, 0);

            if (WIFEXITED(status)) {
                printf("Grandchild GC process: C2 exited normally\n");
            } else {
                printf("Grandchild GC process: C2 did not exit normally\n");
            }

            char p[100];

            // current working directory of grandchild gc
            printf("The current working directory of grandchild GC is %s\n", getcwd(p, 100));

            // using chdir command
            chdir("/home/neelpandya/lab4");

            // new working directory of grandchild gc
            printf("The new working directory of grandchild GC is %s\n", getcwd(p, 100));

            // Creating sample.txt with permissions 0777
            FILE *fp = fopen("sample.txt", "w");
            if (fp == NULL) {
                printf("It failed to create sample.txt");
                exit(1);
            }
            fclose(fp);

            printf("The Grandchild GC process has been completed\n");
            exit(0);
        } else {
            // Wait for gc process to complete
            int status;
            waitpid(gc, &status, 0);

            if (WIFEXITED(status)) {
                printf("Main process: Grandchild GC exited normally\n");
            } else {
                printf("Main process: Grandchild GC did not exit normally\n");
            }

            // Fork C1
            c1 = fork();

            if (c1 < 0) {
                // Error occurred while forking C1
                printf("The fork is failed for Child C1");
                exit(1);
            } else if (c1 == 0) {
                // Process for c1 continues execution

                printf("Child 1 (C1) process is executed\n");
                exit(0);
            } else {
                // Wait for c1 process to complete
                wait(NULL);
                printf("Main process: Child 1 (C1) exited\n");
            }

            printf("Main process has been completed\n");
        }
    }

    return 0;
}
