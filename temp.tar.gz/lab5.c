#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

int cfsig = 0;     // Initializing the count value

void alAct()    // alAct is called
{   
    cfsig = 0;  // It has been reset to zero
    
   alarm(5);     //alarm set for 5 secs
}

void action(int SIG)   // action function
{

   
    if (SIG == SIGINT)    // signal checked
    {      
        cfsig++;         // count is incremented

        
        if (cfsig >= 2)   // Checking for rule 2
        {
            printf("\nThe Process is terminated");    // CTRL-C is pressed twice within 5 sec the process is terminated
            exit(0);
        }
    }
}

int main()   // main function
{
    
    signal(SIGINT, action);   // Signal Handlers
    signal(SIGALRM, alAct);

    alarm(5);

    while (1)
    {
        printf("\nWelcome to Lab5-Signals");   // will print the statement
        sleep(1);             // sleep for 1 sec
    }
}
