#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>

pid_t main_pid;               // pid of the main process i.e parent process
int is_signalled;
void sigint_manager(int s)    // Shows Signal handler for SIGINT
 {
    pid_t current_pid = getpid();   // pid of the current running process
    is_signalled = 1;               // using flag to validate that we have received the signal
    if (current_pid != 0 && current_pid != main_pid && getppid() != main_pid)  // Checking if the process is not the main process and the child of the main process
    {
        printf("Terminating process with PID %d and parent PID %d\n", current_pid, getppid());
        killpg(current_pid, SIGTERM);  // Killing the group of process
    }
}
void sigterm_manager(int sig)  // Signal handler for SIGTERM
{ 
     printf("Process %d (PPID %d) has now been killed\n", getpid(), getppid());
    exit(0);
}

void sigcount_manager(int signum) // Signal handler for SIGCONT
{
    printf("This is from process %d\n", getpid());
    sleep(2);
}

int smain()   // calling method smain 
{
    signal(SIGINT, sigint_manager);   // the registration of SIGINT signal handler
    main_pid = getpid();              // getting pid of the ain process i.e parent process
    printf("Main process PID = %d\n", main_pid); // printing to indicate the pid of the main i.e parent process

    pid_t child_pid_1 = fork();  // Creating the fork child processes
    pid_t child_pid_2 = fork();
    pid_t child_pid_3 = fork();

    if (child_pid_1 == 0)  // Set signal handler for child processes to handle SIGTERM for child 1
    {
        signal(SIGTERM, sigterm_manager);
    }
    if (child_pid_2 == 0)  // Set signal handler for child processes to handle SIGTERM for child 2 
    {
        signal(SIGTERM, sigterm_manager);
    }
    if (child_pid_3 == 0)  // Set signal handler for child processes to handle SIGTERM for child 1
    {
        signal(SIGTERM, sigterm_manager);
    }
   
    while (1)   // using while loop to wait until a signal is received
    {
        printf("This is from process %d and parent %d\n", getpid(), getppid());
        if (is_signalled == 1) // if the signal has been received
         {
            sleep(2);   // sleep for 2 seconds
            break;
        }
        sleep(2);
    }

    if (getpid() == main_pid) // Executing the code for the main process
    {
        while (1) {
            printf("This is from main process %d\n", getpid());  // printing the current runnung process in sequence
            sleep(2);

            // Send SIGCONT and SIGSTOP signals to child processes in sequence
            kill(child_pid_1, SIGCONT);  // sending SIGCONT to the first non child process
            sleep(2);
            kill(child_pid_1, SIGSTOP);  // sending SIGCONT to the first non child process

            kill(child_pid_2, SIGCONT);  // sending SIGCONT to the second non child process
            sleep(2);
            kill(child_pid_2, SIGSTOP);  // sending SIGCONT to the second non child process

            kill(child_pid_3, SIGCONT);  // sending SIGCONT to the third non child process
            sleep(2);
            kill(child_pid_3, SIGSTOP);  // sending SIGCONT to the third non child process
        }
    }

    if (child_pid_1 == 0)   // Execute code for child process 1
    {
        signal(SIGCONT, sigcount_manager);
        while (1) 
        {
            // Code for child process 1
        }
    }

    // Execute code for child process 2
    if (child_pid_2 == 0)   // Execute code for child process 2
    {
        signal(SIGCONT, sigcount_manager);
        while (1) 
        {
            // Code for child process 2
        }
    }

    if (child_pid_3 == 0)   // Execute code for child process 3
    {
        signal(SIGCONT, sigcount_manager);
        while (1) 
        {
            // Code for child process 3
        }
    }
    return 1;
}

int main() 
{
   return smain();
}



