#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

int main() {
    int pipeone[2], pipetwo[2], pipethree[2], statusOfProces;
    pid_t prtid1, prtid2, prtid3, prtid4;

    if (pipe(pipeone) == -1)   // created frst pipe
    {
        printf("pipe");
        return 1;
    }
    
    prtid1 = fork();    // here forking the 1st child using cat input.txt  

    if (prtid1 == -1) {
        printf("fork");
        return 1;
    }

 

    if (prtid1 == 0) 
    {
        dup2(pipeone[1], STDOUT_FILENO);   // stdout writing at the end of the pipeone
        close(pipeone[0]);
        close(pipeone[1]);

        execlp("cat", "cat", "input.txt", NULL);   // Executing the command cat
        printf("exec");
        return 1;
    }

    if (pipe(pipetwo) == -1)  // created frst pipe
    {
        printf("pipe");
        return 1;
    }
    
    prtid2 = fork();     // Forking the second chile using grep COMP

    if (prtid2 == -1) {
        printf("fork");
        return 1;
    }

    if (prtid2 == 0) 
    {
        dup2(pipeone[0], STDIN_FILENO);  // stdin to read end of the pipe one
        close(pipeone[0]);
        close(pipeone[1]);
        
        dup2(pipetwo[1], STDOUT_FILENO); // stdout to write end of the pipetwo
        close(pipetwo[0]);
        close(pipetwo[1]);

        execlp("grep", "grep", "COMP", NULL);  // Executing the command grep
        printf("exec");
        return 1;
    }

    close(pipeone[0]);  // closing the pipes that are unused
    close(pipeone[1]);

    if (pipe(pipethree) == -1)  // Created pipethree 
    {
        printf("pipe");
        return 1;
    }

    prtid3 = fork();    // Forking child three using wc

 

    if (prtid3 == -1) 
    {
        printf("fork");
        return 1;
    }

 

    if (prtid3 == 0) 
    {
        dup2(pipetwo[0], STDIN_FILENO);  // stdin to read end of pipetwo
        close(pipetwo[0]);
        close(pipetwo[1]);

        dup2(pipethree[1], STDOUT_FILENO);  // stdout to write end of pipethree
        close(pipethree[0]);
        close(pipethree[1]);
        
        execlp("wc", "wc", NULL);  // Executing the wc command
        printf("exec");
        return 1;
    }


    close(pipetwo[0]);   // closing pipes that are unused
    
    close(pipetwo[1]);

    prtid4 = fork();

 

    if (prtid4 == -1) {
        printf("fork");
        return 1;
    }

 

    if (prtid4 == 0) 
    {
        dup2(pipethree[0], STDIN_FILENO);  // stdin to read at end of pipethree
        close(pipethree[0]);
        close(pipethree[1]);


        dup2(STDOUT_FILENO, STDERR_FILENO); // stdout to write to console

        execlp("cat", "cat", "output.txt", NULL);  // Executing cat command
        printf("exec");
        return 1;
    }


    close(pipethree[0]);  // closing pipes that are unused
    close(pipethree[1]);


    waitpid(prtid1, &statusOfProces, 0);  // waiting all child process to finish
    waitpid(prtid2, &statusOfProces, 0);
    waitpid(prtid3, &statusOfProces, 0);
    waitpid(prtid4, &statusOfProces, 0);

 

    return 0;
}

