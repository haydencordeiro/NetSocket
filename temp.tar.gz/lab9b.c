#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdint.h> 
#include <time.h>   // For time function

#define SIZE_OF_ARRAY 100
#define SMALLEST_VALUE 10
#define LARGEST_VALUE 20

int ia1[SIZE_OF_ARRAY];
int ia2[SIZE_OF_ARRAY];
int ia3[SIZE_OF_ARRAY];

void initialize_array(int* decarr, int varsize) // Function to initialize an array with random nubers within a range of 10 to 20
{
    for (int v = 0; v < varsize; v++)  // Filling array with random values in the range of 10 to 20
    {
        decarr[v] = rand() % (LARGEST_VALUE - SMALLEST_VALUE + 1) + SMALLEST_VALUE;
    }
}

void* sum_1(void* arg)  // Thread function to calculate the total sum of array of integers
{
    int* decarr = (int*)arg;
    int ttl = 0;
    for (int v = 0; v < SIZE_OF_ARRAY; v++)  // Calculating total sum of elements in the given array
    {
        ttl += decarr[v];
    }
    pthread_exit((void*)(intptr_t)ttl); // Using pthread_exit to return the result to the main thread
}

void* sum_2(void* arg) // Thread function to calculate thotal sum of array of integers
{
    int* decarr = (int*)arg;
    int ttl = 0;
    for (int v = 0; v < SIZE_OF_ARRAY; v++)  // Calculating total sum of elements in the given array
    {
        ttl += decarr[v];
    }
    pthread_exit((void*)(intptr_t)ttl);  // Using pthread_exit to return the result to the main thread
}

void* sum_3(void* arg) // Thread function to calculate thotal sum of array of integers
{
    int* decarr = (int*)arg;
    int ttl = 0;
    for (int v = 0; v < SIZE_OF_ARRAY; v++) // Calculating total sum of elements in the given array
    {
        ttl += decarr[v];
    }
    pthread_exit((void*)(intptr_t)ttl);  // Using pthread_exit to return the result to the main thread
}

int main() 
{
    pthread_t th1, th2, th3;
    void* r1;
    void* r2;
    void* r3;
    int ttl1, ttl2, ttl3;

    srand(time(NULL));  // Random number generator with the current time
    
    initialize_array(ia1, SIZE_OF_ARRAY); // Initializing three arrays ia1,ia2,ia3 with random values
    initialize_array(ia2, SIZE_OF_ARRAY);
    initialize_array(ia3, SIZE_OF_ARRAY);

    pthread_create(&th1, NULL, sum_1, (void*)ia1);// Creating three threads using pthread_create
    pthread_create(&th2, NULL, sum_2, (void*)ia2);
    pthread_create(&th3, NULL, sum_3, (void*)ia3);

    pthread_join(th1, &r1);  // Waiting for threads to finish using pthread_join and retrieve the results
    pthread_join(th2, &r2);
    pthread_join(th3, &r3);

    ttl1 = (intptr_t)r1;  // Converting the void pointers back to integers
    ttl2 = (intptr_t)r2;
    ttl3 = (intptr_t)r3;

    printf("Total: %d\n", ttl1 + ttl2 + ttl3);  // Total sum of all three arrays

    return 0;
}

