#include <pthread.h>
#include <stdio.h>
#include<stdlib.h>
// func1
void* func1(void* ptr)
{
    char* msg;
    msg = ptr;
    printf("%s\n", msg);
    printf("func1\n");
    pthread_exit(NULL);
}

// func2
void* func2(void* ptr) 
{
    char* msg;
    msg = ptr;
    printf("%s\n", msg);
    printf("func2\n");

    pthread_exit(NULL);
}

// func3
void* func3(void* ptr)
{
    char* msg;
    msg = ptr;
    printf("%s\n", msg);
    printf("func3\n");
    pthread_exit(NULL);
}

// func4
void* func4(void* ptr)
{
    char* msg;
    msg = ptr;
    printf("%s\n", msg);
    printf("func4\n");
    pthread_exit(NULL);
}


// func5
void* func5(void* ptr)
{
    char* msg;
    msg = ptr;
    printf("%s\n", msg);
    printf("func5\n");
    pthread_exit(NULL);
}


int main(int argc, char* argv[]) 
{
    pthread_t t1,t2,t3,t4,t5;

    char* msg = "Welcome to COMP8567 -Winter 2024";

    pthread_create(&t4, NULL, func4, msg);
    pthread_join(t4, NULL);

    pthread_create(&t5, NULL, func5, msg);
    pthread_join(t5, NULL);


    pthread_create(&t3, NULL, func3, msg);
    pthread_join(t3, NULL);

    pthread_create(&t1, NULL, func1, msg);
    pthread_join(t1, NULL);

    pthread_create(&t2, NULL, func2, msg);
    pthread_join(t2, NULL);

    printf("Main %lu \n",pthread_self());
    
    return 0;
}