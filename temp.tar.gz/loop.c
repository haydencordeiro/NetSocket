#include <stdio.h> 
#include <stdlib.h> 

int main(void)
{

for(int i=0;i<=5;i++)
{
sleep(1);
printf("\nWelcome to computer science\n");
}

}
