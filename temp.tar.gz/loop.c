
#include <stdio.h> 
#include <stdlib.h> 

main()
{

for(;;);

}
