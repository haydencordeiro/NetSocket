// NEEL PANDYA      ASP Section-1     Student Id:110095825
#define _XOPEN_SOURCE 500
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <libgen.h>
#include <limits.h>
#include <dirent.h>
#include <ftw.h>



char* homeDir;
char srcPath[PATH_MAX],destPath[PATH_MAX];



int copyFile(const char* srcPath, const char* destiPath, const char** extensions, int numExten) {
    
    mkdir(destiPath, 0777);    // we created destination directory in case if it does not exist

   
    const char* srcDirName = strrchr(srcPath, '/');   // getting the name of source directory
    if (srcDirName != NULL) { 
        srcDirName++;  
    } else {
        srcDirName = srcPath;  
    }

    
    char destiDirectory[PATH_MAX];   // creating path of destination directory
    snprintf(destiDirectory, sizeof(destiDirectory), "%s/%s", destiPath, srcDirName);

    
    mkdir(destiDirectory, 0777);    // destination directory with source dirctory name
   
    DIR* dir = opendir(srcPath);
    if (dir == NULL) {
        printf("Failed to open source directory.\n");
        return 0;
    }

    struct dirent* entry;
    while ((entry = readdir(dir)) != NULL) {
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
            continue;
        }


        char srcFile[PATH_MAX];   // Create source and destination paths for the entry
        char destiFile[PATH_MAX];
        snprintf(srcFile, sizeof(srcFile), "%s/%s", srcPath, entry->d_name);
        snprintf(destiFile, sizeof(destiFile), "%s/%s", destiDirectory, entry->d_name);

        struct stat fileStat;
        if (stat(srcFile, &fileStat) < 0) {
            printf("Failed to get file/directory information.\n");
            continue;
        }

        if (S_ISDIR(fileStat.st_mode)) {
            
            copyFile(srcFile, destiDirectory, extensions, numExten);
        } else {
        
            const char* fileExtension = strrchr(entry->d_name, '.');    // If it is a file check its extension and perform copy operation
            if (fileExtension != NULL) {
                fileExtension++;  
                int shouldCopyFile = 1;

                for (int i = 0; i < numExten; i++) {     // Check whether file extension matches any in extension list
                    if (strcmp(fileExtension, extensions[i]) == 0) {
                        shouldCopyFile = 0;
                        break;
                    }
                }

                if (shouldCopyFile) {
                    FILE* srcFilePtr = fopen(srcFile, "rb");
                    if (srcFilePtr == NULL) {
                        printf("Error opening source file: %s\n", srcFile);
                        continue;
                    }
                    

                    FILE* destiFilePtr = fopen(destiFile, "wb");
                    if (destiFilePtr == NULL) {
                        printf("Error creating destination file: %s\n", destiFile);
                        fclose(srcFilePtr);
                        continue;
                    }

                    int ch;
                    while ((ch = fgetc(srcFilePtr)) != EOF) {
                        fputc(ch, destiFilePtr);
                    }

                    fclose(srcFilePtr);
                    fclose(destiFilePtr);
                }
            }
        }
    }

	return 1;
    closedir(dir);
}


int processCopyFile(const char* filePath, const struct stat* fileStat, int typeflag, struct FTW* ftwbuf) {
    
    if (typeflag == FTW_D) {   // Check if its regular file
    	// Construct destination path by appending the file name to the destination directory
    
        const char *file_name = filePath + ftwbuf->base;
        
        
    	if (copyFile(filePath,destPath ,".",0) == -1) {
            fprintf(stderr, "Failed to copy file: %s\n", filePath);
            return -1;
        }
        
    }

    return 0;
}


int moveFile(const char* srcPath, const char* destiPath) {

	copyFile(srcPath,destiPath,".docs", 0);
	int flag=1;
	if(flag=0)
	{
        rmdir(srcPath);   // Remove the empty source directory
        }
}

int processMoveFile(const char* filePath, const struct stat* fileStat, int typeflag, struct FTW* ftwbuf) {
    
    if (typeflag == FTW_D) {
    
	// Construct destination path by appending the file name to the destination directory
	const char *file_name = filePath + ftwbuf->base;
	

	if (moveFile(filePath, destPath) == -1) {
	    fprintf(stderr, "Failed to move file: %s\n", filePath);
	    return -1;
	}
        
    }

    return 0;
}

int isAbsPath(const char* path) {
    if (path[0] == '/')
        return 1;
    else
        return 0;
}


void ncpmvdir(const char* srcDir, const char* destiDir, const char* options, const char* extensions, int numExten) {


    
    
   
    if(isAbsPath(srcDir)){   // Check whether source directory is absolute or relative
    
    	snprintf(srcPath, sizeof(srcPath), "%s%s", homeDir, srcDir); //create the new source path 
    	
    	//check if the directory exist or not?
    	if (access(srcPath, F_OK) != 0) {
    		
        	printf("Source directory does not exist.\n");
        	return;
    	}
    }else{
    	
    	snprintf(srcPath, sizeof(srcPath), "%s/%s", homeDir, srcDir); //create the new source path for further process
    	
    
    	if (access(srcPath, F_OK) != 0) {   //check whether directory exist or not?
        	printf("Source directory does not exist.\n");
        	return;
    	}
    }
    
    
    
    if(isAbsPath(destiDir)){
    	//path is absolute then do this process eg. /folder1
    	snprintf(destPath, sizeof(destPath), "%s%s", homeDir, destiDir); //create the new destination path for further process
    	
    	
    
	    if (access(destPath, F_OK) == 0) {
	    	//Directory exist
	    	
	    	if(strcmp(options, "-cp") == 0){
	    		
		    	if (nftw(srcPath, processCopyFile, 10, FTW_PHYS) == -1) {
				perror("Failed to traverse source directory");
				return ;
			 }
	    	}else if(strcmp(options, "-mv") == 0){
	    		
		    	if (nftw(srcPath, processMoveFile, 10, FTW_NS) == -1) {
				perror("Failed to traverse source directory");
				return ;
			 }
	    	}
	    }else{
	    
	    // Directory not exists
		if (mkdir(destPath, 0777) != 0) {
		    printf("Failed to create destination directory");
		    return;
		}else{
			//after the create perform the operation
			if(strcmp(options, "-cp") == 0){
		    		
		    		//use the nftw() for copy
			    	if (nftw(srcPath, processCopyFile, 10, FTW_NS) == -1) {
					perror("Failed to traverse source directory");
					return ;
				 }
		    	}else if(strcmp(options, "-mv") == 0){
		    		
		    		//use the nftw() for move
			    	if (nftw(srcPath, processMoveFile, 10, FTW_NS) == -1) {
					perror("Failed to traverse source directory");
					return ;
				 }
		    	}
			
		}
	    }
    }else{

    	snprintf(destPath, sizeof(destPath), "%s/%s", homeDir, destiDir); //create the new destination path
    	// Check if destination directory exists
	    if (access(destPath, F_OK) == 0) {
	    	//Directory exist
	    	
	    	if (nftw(srcPath, processCopyFile, 10, FTW_NS) == -1) {
			perror("Failed to traverse source directory");
			return ;
		 }
	    	
	    	
	    	if(strcmp(options, "-cp") == 0){
	    		
	    		//use the nftw() for copy
		    	if (nftw(srcPath, processCopyFile, 10, FTW_NS) == -1) {
				perror("Failed to traverse source directory");
				return ;
			 }
	    	}else if(strcmp(options, "-mv") == 0){
	    		
	    		//use the nftw() for move
		    	if (nftw(srcPath, processMoveFile, 10, FTW_NS) == -1) {
				perror("Failed to traverse source directory");
				return ;
			 }
	    	}
	    }else{
	    
	    	//make the directory it is not exist
		if (mkdir(destPath, 0777) != 0) {
		    printf("Failed to create destination directory");
		    return;
		}else{
			//after the create perform the operation
			if(strcmp(options, "-cp") == 0){
		    		
		    		//use the nftw() for copy
			    	if (nftw(srcPath, processCopyFile, 10, FTW_NS) == -1) {
					perror("Failed to traverse source directory");
					return ;
				 }
		    	}else if(strcmp(options, "-mv") == 0){
		    		
		    		//use the nftw() for move
			    	if (nftw(srcPath, processMoveFile, 10, FTW_NS) == -1) {
					perror("Failed to traverse source directory");
					return ;
				 }
		    	}
			
		}
	    }
    }
    
}

int main(int argc, char* argv[]) {
    // Get home directory path
    homeDir = getenv("HOME");
    
    // Check if home directory path is available
    if (homeDir == NULL) {
        printf("Failed to get home directory path.\n");
        return 1;
    }
    
    // Check the number of command-line arguments
    if (argc < 4) {
        printf("Usage: %s [source_dir] [destination_dir] [options] [extension_list]\n", argv[0]); //show the proper command formate if it's input wrong.
        return 1;
    }
    
    // Extract command-line arguments
    const char* srcDir = argv[1]; //get the source directory
    const char* destiDir = argv[2]; //get the destination directory
    const char* options = argv[3]; //get the option -mv or -cp
    const char* extensions = &argv[4]; //get the extensions 
    int numExten = 0; // list of extenstion
    
    
  
    
    // Check if extensions are provided
    if (argc > 4) {
        extensions = &argv[4];
        numExten = argc - 4;
    }
    
    // Call the ncpmvdir function
    ncpmvdir(srcDir, destiDir, options, extensions, numExten);
    
    return 0;
}
