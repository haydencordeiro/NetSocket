// Neel Manish Pandya       Student Id:110095825        ASP Section 1
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#define MAXIMUM_STR_LEN 512
#define MAXIMUM_CHILD 512

int chldproids[30];

int rootproid;
int status = 0;

void chld_pro(int prntid)                           //method that shows child processes
{

    printf("\nThe Child Processes are:\n");
    char comd[MAXIMUM_STR_LEN];
    sprintf(comd, "ps --ppid %d --no-headers -o pid", prntid);
    FILE *file = popen(comd, "r");
    if (file != NULL) {
        char str[MAXIMUM_STR_LEN];
        while (fgets(str, sizeof(str), file) != NULL)    // It store each line of output in str buffer after reading it
        { 
            int child_prntid;
            int MAX_NAME_SIZE = MAXIMUM_STR_LEN;
            char child_co[MAX_NAME_SIZE];
            sscanf(str, "%d %s", &child_prntid, child_co);

            char comd[MAXIMUM_STR_LEN];
            sprintf(comd, "ps -p %d -o stat=", prntid);
            FILE *file2 = popen(comd, "r");              // To read the output of the command it opens the stream
            char status = ' ';
            if (file2 != NULL) {
                status = fgetc(file2);
                pclose(file2);
            }
            printf("%d\n", child_prntid);
        }
        pclose(file);
    }
}

int Defunct(pid_t prntid)
{
    char comd[MAXIMUM_STR_LEN];
    snprintf(comd, MAXIMUM_STR_LEN, "ps -o stat %d", prntid);
    FILE *pdr = popen(comd, "r");
    char str[512];                                   // avoid the headers
    fgets(str, sizeof(str), pdr);

    if(fgets(str, sizeof(str), pdr) != NULL)
    {
        char status = str[0];

        if(status == 90)
        {
            pclose(pdr);
            return 1;
        }
    }
    pclose(pdr);
    return 0;
}

void sib_zom_pro(int prntid)                    // method to display the sibling processes
{
    printf("The Sibling Zombie Processes are:\n");
    const char* generatedFilename = "output.txt";
    char comd[MAXIMUM_STR_LEN],executedCommand[MAXIMUM_STR_LEN];
    sprintf(comd, "ps --ppid $(ps -o ppid= -p %d) --no-headers -o pid", prntid);
    const char* streamRedirectCommand = "%s > %s";
    
    
    snprintf(executedCommand, sizeof(executedCommand), streamRedirectCommand, comd, generatedFilename);
    
    int result = system(executedCommand);
	FILE* generatedFile = fopen(generatedFilename, "r");   // open the file in read mode
	if (generatedFile) {
	    char str[MAXIMUM_STR_LEN];
	    while (fgets(str, sizeof(str), generatedFile)) 
	    {
		int isZombieProcess = atoi(str);   // processing every line of generayed output
		//Defunct(isZombieProcess);          // Checking if the process is zombie
		
		if(Defunct(isZombieProcess) == 1)
		{
		    printf("\n Zombie Process: %d \n", isZombieProcess); // Print the process_id if it is defunct process
		}
		else
		{
		    printf("\n Not Defunct process: %d \n",isZombieProcess); // Print the process_id if it is no defunct process
		}
		
	    }
	    fclose(generatedFile);
	} 
	else {
	    printf("Failed to open output file\n");
	}
}

void sib_pro(int prntid)             // method for showing sibling processes
{
    printf("\n The Sibling Processes are:\n");
    char comd[MAXIMUM_STR_LEN];
    sprintf(comd, "ps --ppid $(ps -o ppid= -p %d) --no-headers -o pid", prntid);
    system(comd);
}

void grndchld_pro(int prntid, int status) // method for showing grandchild processes
{
    if(status == 0){
    	// Find the Child process of the PID.
    	printf("\n The Grandchild Processes are:\n");
    	char comd[MAXIMUM_STR_LEN];
	sprintf(comd, "ps --ppid %d --no-headers -o pid", prntid);
	FILE *file = popen(comd, "r");
	if (file != NULL) 
	{
		char str[MAXIMUM_STR_LEN];
		while (fgets(str, sizeof(str), file) != NULL) {  // It store each line of output in str buffer after reading it
		    int c_prntid;
		    int MAX_NAME_SIZE = MAXIMUM_STR_LEN;
		    char child_co[MAX_NAME_SIZE];
		    sscanf(str, "%d %s", &c_prntid, child_co);

		    char comd[MAXIMUM_STR_LEN];
		    sprintf(comd, "ps -p %d -o stat=", c_prntid);
		    FILE *file2 = popen(comd, "r");            // To read the output of the command it opens the stream
		    char status = ' ';
		    if (file2 != NULL) 
		    {
			status = fgetc(file2);
			pclose(file2);
		    }
		    grndchld_pro(c_prntid,1);
		}
		pclose(file);
	}
    }
    else
    {
    	char comd[MAXIMUM_STR_LEN];   // Search the child process of PID's child which produce grand chid processes 
	sprintf(comd, "ps --ppid %d --no-headers -o pid", prntid);
	FILE *file = popen(comd, "r");
	if (file != NULL) {
		char str[MAXIMUM_STR_LEN];
		while (fgets(str, sizeof(str), file) != NULL)  // Reads each line of the output and stores it in str buffer
		    {
		    int last_Generation_Parentid;
		    int MAX_NAME_SIZE = MAXIMUM_STR_LEN;
		    char child_co[MAX_NAME_SIZE];
		    sscanf(str, "%d %s", &last_Generation_Parentid, child_co);

		    char comd[MAXIMUM_STR_LEN];
		    sprintf(comd, "ps -p %d -o stat=", last_Generation_Parentid);
		    FILE *file2 = popen(comd, "r");          // To read the output of the command it opens the stream
		    char status = ' ';
		    if (file2 != NULL) 
		    {
			status = fgetc(file2);
			pclose(file2);
		    }
		    printf("%d\n", last_Generation_Parentid);
		}
		pclose(file);
	}
    }
}

void manage_chld_pro(pid_t pro_id,int status) 
{

    char comd[MAXIMUM_STR_LEN];
    snprintf(comd, MAXIMUM_STR_LEN, "pgrep -P %d", pro_id);

    FILE *pdr = popen(comd, "r");
    if (pdr == NULL) 
    {
        perror("popen");
        exit(EXIT_FAILURE);
    }

    char str[512];

    while (fgets(str, sizeof(str), pdr) != NULL) 
    {
        int child_pid = atoi(str);
        
        if (status != 0) {
        	printf("%d\n",child_pid);
        }
    }
    

    pclose(pdr);   
}

void non_direct_des_pro(int prntid)
{
	if(prntid == rootproid)
	{
		manage_chld_pro(prntid, status ); // Parsing the PID allows to determine child process linked to the current PID.
		status++;
	}
	else
	{
		manage_chld_pro(prntid, status);  // Parsing the PID allows to determine child process not linked to the current PID.
	}
	
	char comd[MAXIMUM_STR_LEN];
	snprintf(comd, MAXIMUM_STR_LEN, "pgrep -P %d", prntid);

	FILE *pdr = popen(comd, "r");
	if (pdr == NULL) {
		perror("popen");
		exit(EXIT_FAILURE);
	}

	char str[512];
	while (fgets(str, sizeof(str), pdr) != NULL) 
	{
		int c_prntid = atoi(str);
		non_direct_des_pro(c_prntid);      // calling recursively to process tree
	}

	pclose(pdr);                               // Closing file
}

void zom_chld__pro(int prntid)
{
    	char comd[MAXIMUM_STR_LEN];
    	printf("The Zombie Child processes are : \n");
	sprintf(comd, "ps --ppid %d --no-headers -o pid", prntid); 
	FILE *file = popen(comd, "r");
	if (file != NULL) {
		char str[MAXIMUM_STR_LEN];
		while (fgets(str, sizeof(str), file) != NULL)  // Reads each line of the output and stores it in str buffer
		    {
		    int c_prntid;
		    int MAX_NAME_SIZE = MAXIMUM_STR_LEN;
		    char chld_co[MAX_NAME_SIZE];
		    sscanf(str, "%d %s", &c_prntid, chld_co);

		    char comd[MAXIMUM_STR_LEN];
		    sprintf(comd, "ps -p %d -o stat=", c_prntid);
		    FILE *file2 = popen(comd, "r");             // To read the output of the command it opens the stream
		    char status = ' ';
		    if (file2 != NULL)
		    {
			status = fgetc(file2);
			pclose(file2);
		    }
		    
		    if(Defunct(c_prntid) == 1)
		    {
		    	printf("%d\n", c_prntid);
		    }
		}
		pclose(file);
	}
}

void pro_tree(pid_t root, pid_t prntid,int dd, int sb, int nd, int gc, int sz, int zc, int zz, int pro_depth)
{
    if(dd == 1)
	{
	    chld_pro(prntid);         //  immediate descendent of the process
        }
        
    if(sb == 1)
        {
        char comd[MAXIMUM_STR_LEN];   // sibling process of the process
        snprintf(comd, MAXIMUM_STR_LEN, "ps -o ppid %d", prntid);    
        FILE *pdr = popen(comd, "r");
        if (pdr == NULL) {
            printf("\n ERROR in opening pdr \n");
            return;
        }
        char str[512];
        fgets(str, sizeof(str), pdr);

        if(fgets(str, sizeof(str), pdr) != NULL)
        {
            prntid = atoi(str); // convert the char buffer into the integer to print on the screen.
        }
        
        sib_pro(prntid); // call the method to print the sibling process.
    }
        
    if(nd == 1)
	{
	    non_direct_des_pro(prntid);    // for non-directed descendent exculding child and grand child of the process process_id1
        }
    
    if(gc == 1)
        {
            grndchld_pro(prntid,0);   // for grandchild of the process_id1
        }
    
    if(sz == 1)                       // sibling process of process_id1 that are defunct
    {
        char comd[MAXIMUM_STR_LEN];
        snprintf(comd, MAXIMUM_STR_LEN, "ps -o ppid %d", prntid); // ps -o ppid (prntid)
        FILE *pdr = popen(comd, "r");
        if (pdr == NULL) {
            printf("\n ERROR in opening pdr \n");
            return;
        }
        // Skip the first line of output (headers)
        char str[512];
        fgets(str, sizeof(str), pdr);


        if(fgets(str, sizeof(str), pdr) != NULL)
        {
            prntid = atoi(str); // convert the char buffer into the integer to print on the screen.
        }
        
        sib_zom_pro(prntid); // call the method to print the sibling zombie process.
    }
    
    if(zc == 1)
    {
    	zom_chld__pro(prntid); // Print the child of process_id1 if its defunct of zombie.
    }
   
    if(zz == 1)
    {
    	if(Defunct(prntid) == 1)   // prints the status of process_id1 (Defunct/Not Defunct)
        {
            printf("\n Defunct process id : %d\n", prntid); // print process id of the process that are defunct  
        }
        else
        {
            printf("\n Not Defunct process id : %d\n",prntid); // print process id of the process that are not defunct
        }
        return;
    }
    
}
int main(int argc, char *argv[])
{
    if (argc < 3)                   // check the number of arguments provided by the user
    {
        printf("Usage: %s [root_process] [process_id1] ... [process_id(n)]  [OPTION]\n", argv[0]);   // user will get this message if the format of argument provided is not as per the need
        return 1;
    }
    
    pid_t root_id = atoi(argv[1]);        // get root id
    pid_t pro_id = atoi(argv[2]);         // get process id
    pid_t pro_ids[4];
    if (argc > 3)
    {
    	for (int j = 3; j < argc; j++)
	{
		if (strcmp(argv[j], "nd") != 0 && strcmp(argv[j], "dd") != 0  && strcmp(argv[j], "sb") != 0  && strcmp(argv[j], "sz") != 0  && strcmp(argv[j], "gc") != 0 && strcmp(argv[j], "zz") != 0 && strcmp(argv[j], "zc") != 0)
		{		
			pro_ids[j-3] = atoi(argv[j]);         // if the number of processes are more than 2.
		    
		}
	}
    }

    int option_dd = 0;   // user requests for direct descendent prcocesses
    int option_sb = 0;   // user requests for sibling processes
    int option_nd = 0;   // user requests for non direct descendent processes
    int option_gc = 0;   // user requests for grand child processes
    int option_sz = 0;   // user requests for sibling zombie processes
    int option_zc = 0;   // user requests for zombie child processes
    int option_zz = 0;   // user requests for zombie processes
    int opt;
    for (int j = 2; j < argc; j++)
    {
        if ( strcmp(argv[j], "-dd") == 0 )
        {
            option_dd = 1;      // list PIDs of all immediate descendents of process_id1
        }
        else if( strcmp(argv[j], "-sb") == 0 )
        {
            option_sb = 1;      // list PIDs of all sibling processes of process_id1
        }
        else if( strcmp(argv[j], "-nd") == 0 )
        {
            option_nd = 1;     // list PIDs of all non-direct immediate descendents of process_id1
        }
        else if( strcmp(argv[j], "-gc") == 0 )
        {
            option_gc = 1;     // list PIDs of all grandchildren of process_id1
        }
        else if( strcmp(argv[j], "-sz") == 0 )
        {
            option_sz = 1;     // list PIDs of all sibling processes of process_id1 that are defunct
        }
        else if( strcmp(argv[j], "-zc") == 0 )
        {
            option_zc = 1;     // list PIDs of all non-direct immediate descendents of process_id1 that are currently in defunct state 
        }
        else if( strcmp(argv[j], "-zz") == 0 )
        {
            option_zz = 1;    // prints the status of process_id1 (Defunct / Not Defunct)
        }
        
    }
    rootproid = pro_id;
    
    pro_tree(root_id, pro_id, option_dd, option_sb, option_nd, option_gc, option_sz, option_zc, option_zz, 10);   // Parsing the variable our function
    return 0;
};
