
#define _XOPEN_SOURCE 500
#include <stdint.h>
#include <ftw.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>

#define MAX_PATHS 1000
char *target;
char *filePaths[MAX_PATHS]; 
int numPaths = 0;
char *filenames[MAX_PATHS];
int counter=0;
#define MAX_TOKENS 100 // Maximum number of tokens
char *tokens[MAX_TOKENS];
int numTokens;

// nftw callback function in argc =4 to check if file has extensioton and to take unique paths
int callback(const char *fpath, const struct stat *sb, int typeflag, struct FTW *ftwbuf) {
    if (typeflag == FTW_F) { // Check if it's a regular file
        const char *filename = strrchr(fpath, '/');
        if (filename == NULL) {
            filename = fpath; // use whole path as filename if no '/' 
        } else {
            filename++; // skip / by moving  a character ahead
        }

        if (hasExtension(filename, target)) {
            if (filenameExists(filename)==0)
            {
                filePaths[numPaths] = strdup(fpath);
                numPaths++;
            }                     
            filenames[counter] = strdup(filename);
            counter++;  
        }
    }
    return 0; //continue to traverse
}



int main(int argc, char *argv[]) {
    int result;
    //     else if (argc == 4) //tar file
    // {
        // fileutil [root_dir] [storage_dir] extension
        //   0            1           2           3
    char *path = argv[1];
    char *storage_dir=argv[2];
    target=argv[3];
    int result = nftw(path, callback, 20, FTW_DEPTH);
    if (result == -1) {
        perror("nftw");
        return 1;
    }

    numTokens = tokenizeString(storage_dir);
    constructPaths();
        createTheTar(storage_dir);

        return 0;  
}

