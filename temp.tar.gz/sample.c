#include<stdio.h>
int main(){
    int num1=100;
    int num2=200;
    int num3=300;
    int num4=400;
    int *ar[]={&num1,&num2,&num3,&num4};
    for (int i = 0; i < 4; i++)
    {
        printf("%d %d \n",**(ar+i),(ar+i));
    }
    
}