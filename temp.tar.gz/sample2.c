#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

int main()
{
    int pfd[2];

    if (pipe(pfd) == -1)
    {
        exit(1);
    }

    if (fork() > 0) // parent
    {
        close(pfd[0]); // optional but recommended
        dup2(pfd[1], 1);
        execlp("cat", "cat", "w24.txt", NULL);
    }
    else{
        // Child 1
        close(pfd[1]); // optional but recommended
        int cfd[2];
        if(pipe(cfd)  == -1){
            exit(0);
        }
        if(fork() > 0){
            close(cfd[0]);
            dup2(pfd[0], 0);
            dup2(cfd[1], 1);
            execlp("grep", "grep", "01234", NULL);

        }
        else{
            // // Child 2
            close(cfd[1]);
            dup2(cfd[0],0);
            execlp("wc", "wc", NULL);


        }

    }
}