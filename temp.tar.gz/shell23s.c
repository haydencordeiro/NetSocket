// Neel Pandya    Student id:110095825      ASP Section-1       

#include <stdio.h>  
#include <stdlib.h> 
#include <string.h> 
#include <unistd.h> 
#include <sys/types.h> 
#include <sys/wait.h>
#include <fcntl.h> 

#define MAXI_PIPE_COMMANDS 8 // Maximum no. of commands in a pipeline
#define MAXI_COMMAND_ARGUMENTS 6 // Maximum no. of arguments in a command
#define MAXI_LGTH_COMMAND 1000 // Maximum length of command

const char* user_home_directory; // Stores home directory path

void commd_parsed(char* commd, char* argmts[MAXI_COMMAND_ARGUMENTS])  // Function to parse the command and extract arguments from it
{
    char* parsedToken = strtok(commd, " "); // Tokenize the command
    int v = 0; // Initialize argument index
    while (parsedToken != NULL && v < MAXI_COMMAND_ARGUMENTS) 
    {
        argmts[v] = parsedToken; // Store parsed argument in array of arguments
        parsedToken = strtok(NULL, " "); // Move to next token
        v++; // Increment the index arguemnet
    }
    
    if (v == MAXI_COMMAND_ARGUMENTS) // checking if the maximum number of arguments is reached
    {
        printf("Provide less than %d arguments\n", MAXI_COMMAND_ARGUMENTS - 1); // Display error message if provided argumennt are more
        argmts[0] = NULL; // Set the first argument as NULL
        return;
    }
    
    argmts[v] = NULL; // Set the last argument as NULL to show end of arguments
}

void run_command_pipeline(char* commds[MAXI_PIPE_COMMANDS], int number_of_commds)  // Function to run a command pipeline
{
    int pipes[MAXI_PIPE_COMMANDS - 1][2]; // Array to store file descriptors of pipes

    for (int v = 0; v < number_of_commds - 1; v++) // Iterate to create pipes for commands
    {
        if (pipe(pipes[v]) < 0) // Creatng a pipe and checking for errors
        {
            printf("pipe error"); // Display error message for pipe
            exit(EXIT_FAILURE); // Exit program with a failure status
        }
    }

    for (int v = 0; v < number_of_commds; v++) // Iterate to fork child processes
    {
        pid_t proid = fork(); // Creating a child process and getting its process ID
        if (proid < 0) // Check for fork error
        {
            printf("fork error"); // Display error message for fork
            exit(EXIT_FAILURE); // Exit the program with a failure status
        }
        else if (proid == 0)
        {
            if (v != 0) // Commands other than first one
            {
                dup2(pipes[v - 1][0], STDIN_FILENO); // Redirect standard input to read from previous pipe
                close(pipes[v - 1][0]); // Closing read end of the previous pipe
            }
            if (v != number_of_commds - 1) // Commands other than last one
            {
                dup2(pipes[v][1], STDOUT_FILENO); // Redirect standard output to write to current pipe
                close(pipes[v][1]); // Closing write end of current pipe
            }

            for (int j = 0; j < number_of_commds - 1; j++) // Closing all remaining pipe file descriptors in child
            {
                close(pipes[j][0]);
                close(pipes[j][1]);
            }

            char* commd_argmts[MAXI_COMMAND_ARGUMENTS]; // Create an array to store command arguments
            commd_parsed(commds[v], commd_argmts); // Parse the current command

            for (int v = 0; commd_argmts[v] != NULL; v++) // Code for changing the Home Path and Iterate through command arguments
            {
                if(strstr(commd_argmts[v], "~")) // If argument contains '~' sign
                {
                    char path[MAXI_LGTH_COMMAND]; // Create a buffer to store the new path
                    snprintf(path, sizeof(path), "%s%s", user_home_directory, commd_argmts[v] + 1); // Replacing '~' with home directory path
                    commd_argmts[v] = path; // Update argument with new path
                }
            }

            execvp(commd_argmts[0], commd_argmts); // Execute the command with arguments
            printf("execvp"); // Display an error message if execvp returns
            exit(EXIT_FAILURE); // Exit child process with a failure status
        }
    }

    for (int v = 0; v < number_of_commds - 1; v++) // Closing all pipe file descriptors in parent
    {
        close(pipes[v][0]);
        close(pipes[v][1]);
    }

    for (int v = 0; v < number_of_commds; v++) // Wait for all child processes to finish
    {
        wait(NULL);
    }
}

void run_file_redirection(char* commd, char* fl, int operationMode)  // Function to run command with file redirection
{
    pid_t proid = fork(); // Creating a child process
    if (proid < 0) // Checking for fork error
    {
        printf("fork"); // Display an error message for fork
        exit(EXIT_FAILURE); // Exit the program with a failure status
    }
    else if (proid == 0)
    {
        int fd = open(fl, operationMode, 0644); // Open the file with the specified operation mode and permissions
        if (fd < 0) // Checking for error in opening file
        {
            perror("open"); // Display an error message
            exit(EXIT_FAILURE); // Exit the child process with a failure status
        }

        dup2(fd, STDOUT_FILENO); // Redirect standard output to write to file
        close(fd); // Close file descriptor

        char* commd_argmts[MAXI_COMMAND_ARGUMENTS]; // Creating array to store command arguments
        commd_parsed(commd, commd_argmts); // Parse the command

        execvp(commd_argmts[0], commd_argmts); // Execute command with arguments
        printf("execvp"); // Display an error message if execvp returns
        exit(EXIT_FAILURE); // Exit the child process with a failure status
    }
    else // Parent process
    {
        wait(NULL); // Wait for child process to complete
    }
}

void evaluate_conditional_commd(char* firstcommand, char* secondcommand, int checkCondition) // Function to evaluate conditional commands (commands separated by && or ||)
{
    pid_t proid = fork(); // Creating child process
    if (proid < 0) // Checking for fork error
    {
        printf("fork"); // Display an error message for fork
        exit(EXIT_FAILURE); // Exit program with a failure status
    }
    else if (proid == 0) // Child process
    {
        char* commd_argmts[MAXI_COMMAND_ARGUMENTS]; // Creating array to store command arguments
        commd_parsed(firstcommand, commd_argmts); // Parsing first command

        execvp(commd_argmts[0], commd_argmts); // Execute first command with arguments
        printf("execvp"); // Display an error message if execvp returns
        exit(EXIT_FAILURE); // Exit child process with a failure status
    }
    else // Parent process
    {
        int status;
        waitpid(proid, &status, 0); // Wait for child process to finish and get its exit status
        if ((checkCondition == 0 && status == 0) || (checkCondition == 1 && status != 0)) 
        {
            proid = fork(); // Creating another child process
            if (proid < 0) // Checking for fork error
            {
                printf("fork error"); // Display an error message for fork
                exit(EXIT_FAILURE); // Exit the program with a failure status
            }
            else if (proid == 0) // Child process
            {
                char* commd_argmts[MAXI_COMMAND_ARGUMENTS]; // Creating array to store command arguments
                commd_parsed(secondcommand, commd_argmts); // Parsing second command

                execvp(commd_argmts[0], commd_argmts); // Executing second command with arguments
                printf("execvp"); // Display an error message if execvp returns
                exit(EXIT_FAILURE); // Exit child process with a failure status
            }
            else // Parent process
            {
                wait(NULL); // Wait for child process to complete
            }
        }
    }
}

void run_in_background(char* commd) // Function to run a command in the background
{
    pid_t proid = fork(); // Creating child process
    if (proid < 0) // Checking for fork error
    {
        printf("fork error"); // Display an error message for fork
        exit(EXIT_FAILURE); // Exit the program with a failure status
    }
    else if (proid == 0) // Child process
    {
        char* commd_argmts[MAXI_COMMAND_ARGUMENTS]; // Creating array to store command arguments
        commd_parsed(commd, commd_argmts); // Parse the command

        execvp(commd_argmts[0], commd_argmts); // Execute the command with arguments
        printf("execvp"); // Display an error message if execvp returns
        exit(EXIT_FAILURE); // Exit the child process with a failure status
    }
    else // Parent process
    {
        printf("Background process started: %s\n", commd); // Display a message showing that background process has started
    }
}

void run_commands_sequentially(char* commds[MAXI_PIPE_COMMANDS], int number_of_commds)  // Function to run multiple commands sequentially (commands separated by ;)
{
    for (int v = 0; v < number_of_commds; v++) // Iterate through the commands
    {
        pid_t proid = fork(); // Creating child process
        if (proid < 0) // Checking for fork error
        {
            perror("fork"); // Display an error message
            exit(EXIT_FAILURE); // Exit the program with a failure status
        }
        else if (proid == 0) // Child process
        {
            char* commd_argmts[MAXI_COMMAND_ARGUMENTS]; // Creating array to store command arguments
            commd_parsed(commds[v], commd_argmts); // Parse current command

            execvp(commd_argmts[0], commd_argmts); // Executing command with arguments
            printf("execvp"); // Display an error message if execvp returns
            exit(EXIT_FAILURE); // Exit child process with a failure status
        }
        else // Parent process
        {
            wait(NULL); // Wait for child process to complete
        }
    }
}

int pipe_present(char* commd)  // Function to check if a pipe '|' is present in the command
{
    int len = strlen(commd);
    for (int v = 1; v < len -1 ; v++) // Iterate through characters of the command
    {
        if (commd[v - 1] != '|' && commd[v] == '|' && commd[v + 1] != '|') // Checking presence of a single pipe '|'
        {
            return 1; // Return 1 if a pipe is found
        }
    }
    return 0; // Return 0 if pipe is not found
}

int condition_present(char* commd)     // Function to check if a conditional operator '||' is present in the command
{
    int len = strlen(commd);
    for (int v = 0; v < len - 1; v++) // Iterate through characters of the command
    {
        if (commd[v] == '|' && commd[v + 1] == '|') // Checking presence of the conditional operator '||'
        {
            return 1; // Return 1 if conditional operator is found
        }
    }
    return 0; // Return 0 if conditional operator is not found
}

int main() 
{
    char input[MAXI_LGTH_COMMAND]; // Creating a buffer to store user input
    user_home_directory = getenv("HOME"); // Getting home directory path

    while (1) // Infinite loop to read user commands
    {
        printf("mshell$ "); // Display the shell prompt
        fgets(input, MAXI_LGTH_COMMAND, stdin); // Read user input

        if (strlen(input) == MAXI_LGTH_COMMAND - 1) // Checking if command length exceeds the maximum length
        {
            printf("error: command length is too long\n"); // Display an error message regarding the length of command
            continue; 
        }

        if (input[strlen(input) - 1] == '\n') // Remove newline character from the input
            input[strlen(input) - 1] = '\0';

        if (strcmp(input, "exit") == 0) // If the user enters "exit", exit the shell
            break;

        char* commds[MAXI_PIPE_COMMANDS]; // Creating array to store commands in a pipeline
        int number_of_commds = 0; // Initialize no. of commands to zero
        
        if (pipe_present(input)) // If a single pipe '|' is present in the command
        {
            char* parsedToken = strtok(input, "|"); // Tokenize the command based on the pipe delimiter
            while (parsedToken != NULL && number_of_commds < MAXI_PIPE_COMMANDS) // Iterate through the tokens
            {
                commds[number_of_commds] = parsedToken; // Storing parsed command in the array
                number_of_commds++; // Increment no. of commands
                parsedToken = strtok(NULL, "|"); // Move to the next token
            }
            if(number_of_commds > 7) // Checking if no. of commands exceeds the maximum allowed
            {
                printf("The No. of operations must be less than 7\n"); // Display an error message if no. of commands are more than limit
            }
        }
        else // If no pipe '|' is present check for the conditional operator '||'
        {
            char* parsedToken = strtok(input, "||"); // Tokenize the command
            while (parsedToken != NULL && number_of_commds < MAXI_PIPE_COMMANDS) // Iterate through the tokens
            {
                commds[number_of_commds] = parsedToken; // Storing parsed command in the array
                number_of_commds++; // Increment number of commands
                parsedToken = strtok(NULL, "||"); // Move to the next token
            }
            if(number_of_commds > 7) // Checking if no. of commands exceeds the maximum allowed
            {
                printf("The No. of operations must be less than 7\n"); // Display an error message for number of commands
            }
            else
            {
                number_of_commds = 0; // If no conditional operator is found reset the no. of commands to zero
            }
        }

        if (number_of_commds > 1) // If there are multiple commands in the pipeline
        {
            run_command_pipeline(commds, number_of_commds); // Executing command pipeline
        }
        else // If there is only one command or no command in the pipeline
        {
            char* commd = commds[0]; // Get the single command from the array
            if (strstr(commd, ">") || strstr(commd, ">>")) // Checking if file redirection is present in the command
            {
                char* commd_redirect ;
                char* fl ;
                int operationMode ;
                if (strstr(commd, ">>")) // If '>>' is present set the operation mode for appending
                {
                    commd_redirect = strtok(commd, ">>"); // Tokenize the command based on '>>'
                    fl = strtok(NULL, ">>"); // Geting filename for redirection
                    operationMode = O_WRONLY | O_CREAT | O_APPEND; // Set the operation mode for appending
                }
                else // If '>' is present set the operation mode for truncation
                {
                    commd_redirect = strtok(commd, ">"); // Tokenize the command based on '>'
                    fl = strtok(NULL, ">"); // Geting filename for redirection
                    operationMode = O_WRONLY | O_CREAT | O_TRUNC; // Set the operation mode for truncation
                }
                run_file_redirection(commd_redirect, fl, operationMode); // Execute the command with file redirection
            }
            else if (strstr(commd, "<")) // Checking if input file redirection is present in the command
            {
                char* commd_redirect = strtok(commd, "<"); // Tokenize the command based on '<'
                char* fl = strtok(NULL, "<"); // Get the filename for input redirection
                run_file_redirection(commd_redirect, fl, O_RDONLY); // Execute the command with input file redirection
            }
            else if (strstr(commd, "&&") || strstr(commd, "||")) // Checking if conditional operator '&&' or '||' is present in the command
            {
                char* firstcommand = strtok(commd, "&&"); // Tokenize the command based on '&&'
                char* secondcommand = strtok(NULL, "&&"); // Get the second command after '&&'
                int checkCondition = 0;
                if (strstr(commd, "||")) // If '||' is present, set the check condition to 1
                {
                    checkCondition = 1;
                }
                evaluate_conditional_commd(firstcommand, secondcommand, checkCondition); // Evaluating the conditional commands
            }
            else if (strstr(commd, "&")) // Checking if the command is to be executed in the background
            {
                run_in_background(commd); // run command in the background
            }
            else if (strstr(commd, ";")) // Checking if multiple commands are to be executed sequentially
            {
                char* commds_sequence[MAXI_PIPE_COMMANDS]; // Creating an array to store commands in sequence
                int v = 0;
                char* commd_sequence = strtok(commd, ";"); // Tokenize the command based on ';'
                while (commd_sequence != NULL && v < MAXI_PIPE_COMMANDS) // Iterate through the tokens
                {
                    commds_sequence[v] = commd_sequence; // Storing parsed command in the array
                    v++; // Increment the index
                    commd_sequence = strtok(NULL, ";"); // Move to the next token
                }
                run_commands_sequentially(commds_sequence, v); // Executing commands sequentially
            }
            else 
            {
                pid_t proid = fork(); // Creating a child process
                if (proid < 0) // Checking for fork error
                {
                    printf("fork error"); // Display an error message for fork
                    continue; // Skip to the next iteration of the loop
                }
                else if (proid == 0) // Child process
                {
                    char* commd_argmts[MAXI_COMMAND_ARGUMENTS]; // Creating an array to store command arguments
                    printf("cmd : %s",commd); // Display the current command
                    commd_parsed(commd, commd_argmts); // Parsing the command

                    for (int v = 0; commd_argmts[v] != NULL; v++) // Iterate through command arguments
                    {
                        if(strstr(commd_argmts[v], "~")) // If argument contains '~'
                        {
                            char path[MAXI_LGTH_COMMAND]; // Creating buffer to store the new path
                            snprintf(path, sizeof(path), "%s%s", user_home_directory, commd_argmts[v] + 1); // Replace '~' with home directory path
                            commd_argmts[v] = path; // Update the argument with the new path
                        }
                    }

                    execvp(commd_argmts[0], commd_argmts); // Executing command with arguments
                    printf("execvp"); // Display an error message if execvp returns
                    exit(EXIT_FAILURE); // Exit the child process with a failure status
                }
                else // Parent process
                {
                    wait(NULL); // Wait for child process to complete
                }
            }
        }
    }

    return 0; // Exit program with a success status
}

