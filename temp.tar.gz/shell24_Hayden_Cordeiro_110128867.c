#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <pwd.h>

#define MAX_NO_ARGUMENTS 5
#define MAX_CMD_LEN 1000

char* bashID;
char* fgFile;

// Check if file exist
int fileExists(const char* filename)
{
    // Try to open the file in read-only mode
    int fd = open(filename, O_RDONLY);
    if (fd == -1)
    {
        // File open failed, it doesn't exist
        return 0;
    }
    else
    {
        // File open succeeded, close the file descriptor and return 1
        close(fd);
        return 1;
    }
}

// Helper method to duplicate an integer array
int* intdup(int const* src, size_t len)
{
    int* p = malloc(len * sizeof(int));
    memcpy(p, src, len * sizeof(int));
    return p;
}

// Helper method to get lenght of the string
int getLenght(int* p)
{
    // variable that holds the lenght of the string
    int c = 0;
    // iterating till -2 (-2 denotes the end of the array)
    for (int i = 0; p[i] != -2; i++)
    {
        c += 1;
    }
    c += 1;
    return c;
}

// converts  a string of integers into an integer array
int* formatStringToInteger(char* input)
{
    // char input[] = "4974\n4975\n4977\n"; // Input string
    // Assuming a maximum of 100 integers
    int* array = (int*)malloc(100);
    int num, i = 0;
    // Tokenizing the input based on new line character
    char* token = strtok(input, "\n");
    while (token != NULL)
    {
        // convert the string token to integer
        num = atoi(token);
        // add the integer token to the integer
        array[i++] = num;
        token = strtok(NULL, "\n");
    }
    // add a -2 to denote end of the array
    array[i++] = -2;
    // make a copy of the array and return it
    int n = getLenght(array);
    int* ar = intdup(array, n);
    free(array);
    return ar;
}
// Count spaces from a given string
int countSpaces(const char* str) {
    int count = 0;
    while (*str) {
        if (strchr(" ", *str))
            count++;
        str++;
    }
    return count;
}

// Returns 1 if there are more than 5 arguments else 0
int moreThan5Arguments(char** s, int l) {
    int i = 0;
    while (i < l)
    {
        if (countSpaces(s[i]) > 4) {
            printf("More than 5 arguments\n");
            return 1;
        }
        i+=1;
    }
    return 0;
}

// Helper method to print error in case of open, read, write and lseek operations
int errorHandlingORWL(int value, char* operation)
{
    if (value == -1)
    {
        printf("Error in %s operation\n", operation);
        exit(0);
    }
    return value;
}

// Read a file of pids to get a list of pids of all paused processes and returns an integer array
int* readFileToString(char* filename)
{

    // Open the file
    int fd = errorHandlingORWL(open(filename, O_RDONLY), "open");
    // Get the file size using lseek
    int file_size = errorHandlingORWL(lseek(fd, 0, SEEK_END), "lseek");
    // use malloc to alloocate memory
    char* file_contents = (char*)malloc(file_size + 1);
    // set the file ofset back to 0 using LSEEK
    errorHandlingORWL(lseek(fd, 0, SEEK_SET), "lseek");
    // Read the contents of the file using read system call
    errorHandlingORWL(read(fd, file_contents, file_size), "lseek");
    close(fd);
    return formatStringToInteger(file_contents);
}

// Used to write process Ids to the specified file
void writeToFile(int number, char* filename)
{
    // Open the file in append mode (create if not present)
    int fd = errorHandlingORWL(open(filename, O_WRONLY | O_CREAT | O_APPEND, 0644), "open");
    // Convert the number to string
    char numberStr[20];
    int length = snprintf(numberStr, sizeof(numberStr), "%d\n", number);
    // Write the number to the file
    int bytes_written = errorHandlingORWL(write(fd, numberStr, length), "write");
    // Close the file
    close(fd);
}

// Handler for SIGINT
void siginthandler()
{
    // Used to check if the fg process txt file exist
    if (fileExists(fgFile))
    {
        // Kills the processes if were put into bg and then brought into fg
        int* pids = readFileToString(fgFile);
        // printf("Sending SIGINT to %d", getpid());
        kill(pids[0], SIGINT);
        unlink(fgFile);
    }
    printf("\n");
}

// Given a string returns a list of delimeters in order
// Eg "ls&&ls||ls" -> ["&&", "||"]
char** extractDelimiters(const char* input)
{
    char** delimiters = (char**)malloc(MAX_NO_ARGUMENTS * sizeof(char*));
    if (!delimiters)
    {
        printf("Memory allocation failed\n");
        exit(0);
    }

    const char* delimiters_to_find[] = { "&&", "||" };
    int num_delimiters_to_find = sizeof(delimiters_to_find) / sizeof(delimiters_to_find[0]);
    int count = 0;

    for (int i = 0; input[i] != '\0'; ++i)
    {
        for (int j = 0; j < num_delimiters_to_find; ++j)
        {
            int delimiter_length = strlen(delimiters_to_find[j]);
            if (strncmp(input + i, delimiters_to_find[j], delimiter_length) == 0)
            {
                delimiters[count] = (char*)malloc((delimiter_length + 1) * sizeof(char));
                if (!delimiters[count])
                {
                    printf("Memory allocation failed\n");
                    exit(0);
                }
                strncpy(delimiters[count], input + i, delimiter_length);
                delimiters[count][delimiter_length] = '\0'; // Null-terminate the string
                count++;
                i += delimiter_length - 1; // Move the pointer to skip the delimiter
                break;
            }
        }
    }

    return delimiters;
}

// Function to interleave commands and delimiters
// Given 2 arrays interleaves them
// EG (["ls","ls","ls"], ["&&","||"]) -> ["ls", "&&", "ls", "||", "ls"]
char** interleaveCommandsAndDelimiters(char** commands, int commandsLength, char** delimiters, int delimitersLength)
{
    // Get total Lenght of the final array
    int totalLength = commandsLength + delimitersLength;
    // Allocate memory
    char** result = (char**)malloc(sizeof(char*) * (totalLength + 1));
    if (result == NULL)
    {
        printf("Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    // iternate over the elements are append them to the new array
    int i = 0, j = 0, k = 0;
    while (i < commandsLength && j < delimitersLength)
    {
        result[k++] = strdup(commands[i++]);
        result[k++] = strdup(delimiters[j++]);
    }

    // Copy remaining commands, if any
    while (i < commandsLength)
    {
        result[k++] = strdup(commands[i++]);
    }

    // Copy remaining delimiters, if any
    while (j < delimitersLength)
    {
        result[k++] = strdup(delimiters[j++]);
    }

    result[k] = NULL; // Null-terminate the result array
    return result;
}

// Given a command convets it into the format requried by execvp and executes it
int runCommand(const char* command)
{
    // Duplicate the command
    char* commandDup = strdup(command);
    char* args[MAX_CMD_LEN];
    char* token;
    int i = 0;

    // Tokenize the input command based on space
    token = strtok((char*)command, " ");
    while (token != NULL)
    {
        args[i++] = token;
        token = strtok(NULL, " ");
    }
    args[i] = NULL; // Set the last argument to NULL

    // Execute the command using execvp
    if (execvp(args[0], args) == -1)
    {
        printf("Command '%s' not found\n", commandDup);
        return 0;
    }
}

// Helper method to remove spaces from a string
char* stripSpaces(char* word)
{
    // Skip leading spaces
    while (isspace(*word))
        word++;
    if (*word == '\0') // If the string is empty or contains only spaces
        return word;
    // Trim trailing spaces
    char* end = word + strlen(word) - 1;
    while (end > word && isspace(*end))
        end--;
    // Null-terminate the trimmed string
    *(end + 1) = '\0';
    return word;
}

// Helper method to split a given string by the specified delimeter
// eg: ("ls -1", " ") -> ["ls","-1"]
char** splitString(char* str, char* delimenter)
{
    int count = 0;
    char** tokens = (char**)malloc(MAX_NO_ARGUMENTS * sizeof(char*));
    if (tokens == NULL)
    {
        printf("Memory allocation error\n");
        return NULL;
    }

    // tokenize the string
    char* token = strtok(str, delimenter);
    while (token != NULL)
    {
        // allocate memory
        tokens[count] = (char*)malloc((strlen(token) + 1) * sizeof(char));
        if (tokens[count] == NULL)
        {
            fprintf(stderr, "Memory allocation error\n");
            for (int i = 0; i < count; i++)
                free(tokens[i]);
            free(tokens);
            return NULL;
        }
        // remove any extra spaces
        strcpy(tokens[count], stripSpaces(token));
        count++;
        token = strtok(NULL, delimenter);
    }
    // add NULL to indicate end
    tokens[count] = NULL;
    return tokens;
}

// Helper method for >> and >
// Executes the command and redirects the output
void opRedirection(char* filename, int mode, char command[])
{
    if (countSpaces(command) > 4) {
        printf("More than 5 arguments\n");
        return;
    }
    // Child
    int pid = fork();
    if (pid == 0)
    {

        char** result = splitString(command, " ");
        // Open the file
        int o = errorHandlingORWL(open(filename, mode, 0644), "open");
        // printf("Opened file %d %s", o, filename);
        // Redirect the output
        dup2(o, 1);
        // Run the command
        execvp(result[0], result);
        errorHandlingORWL(close(o), "close");
    }
    else
    {
        // Wait for child
        waitpid(pid, NULL, 0);
    }
}

// Helper method for <>
// Executes the command and redirects the input
void ipRedirection(char* filename, int mode, char command[])
{
    if (countSpaces(command) > 4) {
        printf("More than 5 arguments\n");
        return;
    }
    int pid = fork();
    if (pid == 0)
    {
        // Open the file for reading
        int o = errorHandlingORWL(open(filename, mode, 0644), "open");
        // Redirect the input
        dup2(o, 0);
        // Execute the command
        char** result = splitString(command, " ");
        execvp(result[0], result);
        // Close the file after reading input
        errorHandlingORWL(close(o), "close");
    }
    else
    {
        // Wait for child
        waitpid(pid, NULL, 0);
    }
}

// Helper method to run sequential piping operations and redirecting output of first to the next pipe until the end
void executePipe(char** commands, int num_commands)
{
    int prev_pipe[2], next_pipe[2];
    int i;
    // Loop through commands
    for (i = 0; i < num_commands; i++)
    {
        // Initialize the next pipe
        if (i < num_commands - 1 && pipe(next_pipe) == -1)
        {
            perror("pipe");
            exit(EXIT_FAILURE);
        }

        // Fork a child process
        int pid = fork();
        if (pid == -1)
        {
            perror("fork");
            exit(EXIT_FAILURE);
        }
        else if (pid == 0)
        { // Child process
            // Set up redirection
            if (i > 0)
            {
                dup2(prev_pipe[0], 0); // Set input from previous pipe
                close(prev_pipe[1]);   // Close write end of previous pipe
            }
            if (i < num_commands - 1)
            {
                close(next_pipe[0]);   // Close read end of next pipe
                dup2(next_pipe[1], 1); // Set output to next pipe
            }

            // Close pipe ends not needed by this process
            if (i > 0)
            {
                close(prev_pipe[0]);
            }
            if (i < num_commands - 1)
            {
                close(next_pipe[1]);
            }

            // Execute command
            runCommand(commands[i]);
            exit(EXIT_SUCCESS); // Exit child process after command execution
        }
        else
        { // Parent process
            // Close previous pipe if it's not the first command
            if (i > 0)
            {
                close(prev_pipe[0]);
                close(prev_pipe[1]);
            }

            // Set up next pipe if it's not the last command
            if (i < num_commands - 1)
            {
                prev_pipe[0] = next_pipe[0];
                prev_pipe[1] = next_pipe[1];
            }
            waitpid(pid, NULL, 0);
        }
    }

}

// Uses the runCommand function to execute command, alonside also returns a status of exectuion of the command
int runCommandHelper(char* command)
{
    // Fork a child process
    int pid = fork();
    if (pid == -1)
    {
        printf("Failed to fork");
        exit(0);
    }
    else if (pid == 0)
    { // Child process

        // Execute the command
        if (runCommand(command) == 0)
        {
            // In case of failure return -1
            exit(10);
        }
    }
    else
    {
        int status;
        waitpid(pid, &status, 0);
        if (WIFEXITED(status))
        {
            if (WEXITSTATUS(status) == 0) {
                return 1;
            }
        }
        return 0;
    }
}

// Executes the boolean And and OR operation
void andOrExecution(char** commands, int num_commands)
{
    // Runs the first command
    int prev = runCommandHelper(commands[0]);
    int i = 1;
    // Based on boolean && or || it checks status of the previous command
    // In case of or prev command status should be 0
    // In case of && the prev status should be 1
    while (i < num_commands)
    {
        if (strstr(commands[i], "&&") != NULL)
        {
            if (prev == 1)
            {
                int nextE = runCommandHelper(stripSpaces(commands[i + 1]));
                if (nextE == 0)
                {
                    prev = 0;
                }
                else
                {
                    prev = 1;
                }
            }
            i += 1;
        }
        else if (strstr(commands[i], "||") != NULL)
        {
            if (prev == 0)
            {
                int nextE = runCommandHelper(stripSpaces(commands[i + 1]));
                if (nextE == 0)
                {
                    prev = 0;
                }
                else
                {
                    prev = 1;
                }
            }
            i += 1;
        }
        else
        {
            i += 1;
        }
    }
}

// Executes commands sequentially
void sequentialExecution(char** commands, int num_commands, int stopOnFailure)
{
    for (int i = 0; i < num_commands; i++)
    {
        // Fork a child process
        int pid = fork();
        if (pid == -1)
        {
            printf("Failed to fork");
            exit(0);
        }
        else if (pid == 0)
        { // Replace the child process with the executable command

            if (runCommand(commands[i]) == 0)
            {
                printf("%s command failed to execute \n", commands[i]);
                // Send an exit 10 status
                exit(10);
            }
        }
        else
        {
            // wait for the child to complete
            int status;
            waitpid(pid, &status, 0);
            if (WEXITSTATUS(status) == 10)
            {
                // Used to stop on failure
                if (stopOnFailure)
                    break;
            }
        }
    }
}

// Helper method to get lenght of an array
int getLenghtofCommandsArray(char** commands)
{
    int i = 0;
    while (commands[i] != NULL)
    {
        i += 1;
    }
    return i;
}
// Helper function that appends cat to filenames
// Eg  first.txt # second.txt -> cat first.txt # cat second.txt
char* generateCatCommand(const char* input)
{
    // Initialize variables
    size_t output_size = 0;
    size_t current_length = 0;
    char* output = NULL;
    const char* delimiter = "#";

    // Tokenize the input string using '#' as delimiter
    char* token = strtok(strdup(input), delimiter);

    // Process each token
    while (token != NULL)
    {
        // Trim leading and trailing whitespace from the token
        while (isspace(*token))
        {
            token++;
        }
        size_t token_length = strlen(token);
        while (token_length > 0 && isspace(token[token_length - 1]))
        {
            token_length--;
        }

        // Resize the output buffer
        output_size += token_length + strlen("cat ") + 1; // Add space for "cat " and '\0'
        output = realloc(output, output_size);

        // Append "cat <trimmed_token> #" to the output string
        current_length += snprintf(output + current_length, output_size - current_length, "cat %.*s", (int)token_length, token);

        // Get the next token
        token = strtok(NULL, delimiter);

        // If there is a next token, append " # " to the output string
        if (token != NULL)
        {
            output_size += strlen(" # ");
            output = realloc(output, output_size);
            current_length += snprintf(output + current_length, output_size - current_length, " # ");
        }
    }

    // Ensure the output string is null-terminated
    if (output != NULL && current_length < output_size)
    {
        output[current_length] = '\0';
    }

    return output;
}

// Add a new terminal
void newt()
{
    // Create a fork
    pid_t pid = fork();
    // Error handling
    if (pid == -1)
    {
        // Fork failed
        perror("fork");
        return;
    }
    // Replace child with new shell24
    else if (pid == 0)
    {
        if (setpgid(0, 0) == -1)
        {
            // The system call failed
            perror("setpgid");
            return;
        }
        // Launch a new xterm
        // char* args[] = { "gnome-terminal","--", "bash", "-c", "./a.out", NULL };
        char* args[] = { "xterm", "-e", "shell24", NULL };
        if (execvp(args[0], args) == -1)
        {
            perror("couldnt launch new shell");
            exit(EXIT_FAILURE); // Terminate the child process with failure status
        }                       // execvp only returns if it fails
    }
    else
    {
        // Parent process
        // Wait for the child process to finish
        // waitpid(pid, NULL, 0);
    }
}

// Handle all the special characters
void handleString(char* string, char* bashID)
{
    // Handle user opening new terminal
    if (strstr(string, "newt") != NULL)
    {
        newt();
    }
    // User wants to exit
    else if (strstr(string, "exit") != NULL)
    {
        unlink(fgFile);
        unlink(bashID);
        exit(0);
        return;
    }
    // Handle boolean operations
    else if (strstr(string, "&&") != NULL || strstr(string, "||") != NULL)
    {
        // Split command based on && And || and return an Array 
        char** commands = splitString(strdup(string), "&&||");
        int commandsLength = getLenghtofCommandsArray(commands);
        if (moreThan5Arguments(commands, commandsLength))
            return;
        // Split command and get a list of && and || and return an array
        char** delimiters = extractDelimiters(string);
        int delimitersLength = getLenghtofCommandsArray(delimiters);
        // Error handling
        if (delimitersLength > 5) {
            printf("Only supports upto 5 conditional operations\n");
            return;
        }
        // Interleave the 2 arraays to get this format [command1, boolean_operation, command2]
        char** interleavedArray = interleaveCommandsAndDelimiters(commands, commandsLength, delimiters, delimitersLength);
        int interlen = getLenghtofCommandsArray(interleavedArray);
        int child = fork();
        // Create a fork and run the boolean commands
        if (child == 0)
        {
            andOrExecution(interleavedArray, interlen);
            exit(0);
        }
        else
        {
            waitpid(child, NULL, 0);
        }
    }
    // Handle concatination of files
    else if (strstr(string, "#") != NULL)
    {
        // Split the command based on #
        char** commands = splitString(generateCatCommand(string), "#");

        int commandsLenght = getLenghtofCommandsArray(commands);
        if (moreThan5Arguments(commands, commandsLenght))
            return;
        // Error handling
        if (commandsLenght > 6) {
            printf("Only supports 5 # operations\n");
            return;
        }
        // Sequentially Execute
        sequentialExecution(commands, commandsLenght, 1);
        printf("\n");
    }
    // Handle upto 6 piping operations
    else if (strstr(string, "|") != NULL)
    {
        // printf("String contains |\n");
        char** commands = splitString(string, "|");
        int commandsLenght = getLenghtofCommandsArray(commands);
        if (moreThan5Arguments(commands, commandsLenght))
            return;
        // Error Handling
        if (commandsLenght > 7) {
            printf("Only supports 6 | operations \n");
            return;
        }
        // Execute the piping operations
        executePipe(commands, commandsLenght);
    }
    // Handle op redirection (Append)
    else if (strstr(string, ">>") != NULL)
    {
        char* fileName = strtok(string, ">>");
        fileName = stripSpaces(strtok(NULL, ">>"));
        // printf("String contains >>\n");
        opRedirection(fileName, O_CREAT | O_RDWR | O_APPEND, string);
    }
    // Handle op redirection
    else if (strstr(string, ">") != NULL)
    {
        char* fileName = strtok(string, ">");
        fileName = stripSpaces(strtok(NULL, ">"));
        // Delete the file before redirecting output
        unlink(fileName);
        opRedirection(fileName, O_CREAT | O_RDWR, string);
    }
    // Handle ip redirection
    else if (strstr(string, "<") != NULL)
    {
        char* fileName = strtok(string, "<");
        fileName = stripSpaces(strtok(NULL, "<"));
        ipRedirection(fileName, O_RDONLY, stripSpaces(string));
    }
    // Bring BG process to FG
    else if (strstr(string, "fg") != NULL)
    {
        // in the case if there is no background process
        if (!fileExists(bashID)) {
            printf("bash: fg: current: no such job\n");
            return;
        }
        // If there are bg process, then get the list of them from the file
        int* pids = readFileToString(bashID);
        int tLen = strlen(bashID);
        // Delete the file
        unlink(bashID);
        int l = getLenght(pids);
        for (int i = 0; pids[i] != -2; i++)
        {
            // check if the process belongs to the current process tree
            // Push the last background process to the FG
            if (i == l - 2)
            {
                writeToFile(pids[i], fgFile);
                // Wait for the background process which is now in the FG to complete
                waitpid(pids[i], NULL, 0);
            }
            else
            {
                // if no add it back to the file
                writeToFile(pids[i], bashID);
            }
        }
    }
    // Send process to bg
    else if (strstr(string, "&") != NULL)
    {
        // split command based on &
        char** commands = splitString(string, "&");
        int commandsLenght = getLenghtofCommandsArray(commands);

        if (moreThan5Arguments(commands, commandsLenght))
            return;
        signal(SIGINT, siginthandler);
        // Create a fork
        int cpid = fork();
        if (cpid == 0)
        {

            // Set the Child as a group leader by updating the groupID
            if (setpgid(0, 0) == -1)
            {
                // The system call failed
                perror("setpgid");
                return;
            }
            // If the command is valid then execute it and do not wait for it to complete
            if (strlen(stripSpaces(commands[0])) > 0)
                runCommand(stripSpaces(commands[0]));
        }
        if (cpid > 0)
        {
            // Write the pid of the process to the bg file
            if (strlen(stripSpaces(commands[0])) > 0)
                writeToFile(cpid, bashID);
            // To print which index it is in the stack
            int* pids = readFileToString(bashID);
            int size = sizeof(pids) / sizeof(pids[0]);
            printf("[%d] %d\n", size - 1, cpid);
        }
    }
    // Run sequential commadns
    else if (strstr(string, ";") != NULL)
    {
        // Split based on ;
        char** commands = splitString(string, ";");
        int commandsLenght = getLenghtofCommandsArray(commands);
        if (moreThan5Arguments(commands, commandsLenght))
            return;
        // Error handling
        if (commandsLenght > 6) {
            printf("Only supports 5 ; operations\n");
            return;
        }
        sequentialExecution(commands, commandsLenght, 0);
        printf("\n");
    }
    // Run a command that is not a special command
    else
    {
        if (countSpaces(string) > 4) {
            printf("More than 5 arguments\n");
            return;
        }
        runCommandHelper(stripSpaces(string));
    }
}

// Generate a unique bashID based on the groupID
char* generateBashID()
{
    // Get the current group ID of the process
    int pgid = getpgid(0);
    if (pgid == -1)
    {
        perror("getpgid");
        exit(EXIT_FAILURE);
    }

    // Convert the group ID to a string
    char pgid_str[20]; // Assuming the group ID can be represented in 20 characters
    snprintf(pgid_str, sizeof(pgid_str), "%d", pgid);

    // Allocate memory for the new string (group ID + ".txt")
    int len = strlen(pgid_str) + strlen(".txt") + 1; // +1 for the null terminator
    char* result = (char*)malloc(len);
    if (result == NULL)
    {
        perror("malloc");
        exit(EXIT_FAILURE);
    }

    // Combine the group ID string and ".txt"
    snprintf(result, len, "%s.txt", pgid_str);

    return result;
}

// Handle CD logic, when user enters cd -> Change directory
void handleCd(char* input)
{
    // Assuming a maximum of 64 arguments
    char* args[64];
    char* token;
    int i = 0;
    // Tokenize the input command
    token = strtok((char*)input, " ");
    while (token != NULL)
    {
        args[i++] = token;
        token = strtok(NULL, " ");
    }
    args[i] = NULL;
    if (args[1] == NULL || strlen(args[1]) == 0)
    {
        return;
    }
    char* cdPath = stripSpaces(args[1]);

    if (cdPath[0] == '~')
    {
        // Handle '~' by expanding it to the user's home directory
        char* homeDir;
        if (cdPath[1] == '/' || cdPath[1] == '\0')
        {
            // "~" or "~/..." case
            homeDir = getenv("HOME");
            if (homeDir == NULL)
            {
                struct passwd* pw = getpwuid(getuid());
                if (pw != NULL)
                {
                    homeDir = pw->pw_dir;
                }
                else
                {
                    printf("Error: Cannot determine home directory.\n");
                    return;
                }
            }
            // Move past the '~' in the input path
            cdPath++;
            // Move past the '/' if in the input path
            if (cdPath[0] == '/')
            {
                cdPath++;
            }
            // Construct the full path
            size_t homeDirLen = strlen(homeDir);
            size_t cdPathLen = strlen(cdPath);
            char fullPath[homeDirLen + cdPathLen + 2]; // +1 for '/', +1 for '\0'
            snprintf(fullPath, sizeof(fullPath), "%s/%s", homeDir, cdPath);
            // cdPath = fullPath;
            printf("Full Path %s\n", fullPath);
            if (chdir(fullPath) == -1)
            {
                printf("Failed chdir \n");
            }
        }
    }
    else
    {
        if (chdir(cdPath) == -1)
        {
            printf("Failed chdir \n");
        }
    }
}
int mainLogic()
{
    char input[MAX_CMD_LEN]; // Assuming a maximum input length of 1000 characters
    bashID = generateBashID();
    asprintf(&fgFile, "fg_%s", bashID);
    while (strcmp(input, "exit\n") != 0)
    {
        // Prompt the user for input
        printf("shell24$ ");

        // Read the input from the user
        fgets(input, MAX_CMD_LEN, stdin);

        // Fork a process to handle the request
        if (strstr(input, "cd") != NULL)
        {
            handleCd(input);
            continue;
        }

        handleString(input, bashID);
    }
    unlink(bashID);
    return 0;
}

int main()
{
    // Signal Handler
    signal(SIGINT, siginthandler);
    // Clear the intial terminal
    runCommandHelper("clear");
    // Handle the main code logic
    mainLogic();
    // Unlink Files and Bash
    unlink(fgFile);
    unlink(bashID);
    return 0;
}
