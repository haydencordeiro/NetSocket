#include<stdio.h>
#include<unistd.h>
#include<sys/signal.h>
#include<stdlib.h>

int f1;
int f2;
// handler for signal
void sigintHandler(int signo){}
int main(){
       // consecutive two fork calls
	f1 = fork();
	f2 = fork();
	int pid1;
	int pid2;
	int pid11;

		signal(SIGINT,sigintHandler);
         // child f1
	if(f1==0 && f2>0){
		pid1 = getpid();
		while(1){
			kill(getpid(),SIGSTOP);
			printf("From Process %d \n",getpid());
			sleep(2);
			kill(getppid(),SIGCONT);
		}
	}else if(f2==0 && f1>0){
		pid2 = getpid();
                // infinite loop for child f2
		while(f1>0){
			kill(getpid(),SIGSTOP);
			printf("From process %d \n",getpid());
			sleep(2);
			kill(pid1, SIGCONT);
		}
	}else if(f1==0 && f2==0){
		pid11 = getpid();
		while(1){
			printf("From Process %d \n",getpid());
			sleep(2);
                        // set group id for grandchild
			setpgid(getpid(),getpid());
			pause();
			kill(-getpid(), SIGINT);
		}
	}else{
              // parent process
		pause();
		while(1){
			printf("From process %d \n",getpid());
			sleep(2);
			kill(pid2, SIGCONT);
			kill(getpid(), SIGSTOP);
		}
	}

}