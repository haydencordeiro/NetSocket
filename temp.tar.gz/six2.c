#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
pid_t parpid;
volatile int uniqueflag1=0; // it becomes 1 when ctrl c is pressed
void handle_SIGINTJ(int signal) 
{
    pid_t cur_ppid = getpid();
    uniqueFlag = 1;
    printf("groupid \n");
    if (cur_ppid != 0 && cur_ppid != parpid && getppid() != parpid) 
    {
        setpgid(cur_ppid, getpid());
        printf("\n %d \n",parpid);
        printf("\n %d \n",f1);
        kill(parpid, SIGCONT);
        killpg(cur_ppid, SIGTERM);
        // printf("----------------process terminated with id %d and ppid %d \n", cur_ppid, getppid());
    }
}

void handle_SIGTERMJ(int signal) 
{
    printf("Process with pid ID %d has been terminated .\n", getpid());
    exit(0);
}

void handle_SIGCONTJ(int signum) 
{
    printf("This is from process %d\n", getpid());
    sleep(2);
}

int main() 
{
    signal(SIGINT, handle_SIGINTJ); // registering handlefuncTion for SIGINT
    signal(SIGCONT, handle_SIGCONTJ); 
    parpid = getpid();
    printf("Process ID of root process is %d\n", parpid);

    pid_t c1 = fork();
    pid_t c2 = fork();
    pid_t cur_ppid = getpid();

    int i=0;
    while (1) 
    {
        printf("\n %d \n",i);
        printf("\n%d\n",getpid());
        printf("\nparpid %d\n",parpid);
        printf("\n f1 %d\n",f1);
        if (getpid() == parpid) 
        {
            if(f1==1)
            {
                printf("\nhiiiiiiiiiiii\n");
                break;
            }
        }
        printf("From process id %d\n", getpid());
        sleep(2);
        i++;
    }

    if (getpid() == parpid) 
    {

     kill(c1, SIGSTOP); 
//to call processes in sequence 
        while (1) 
        {
            printf("This is from process %d\n", getpid());
            sleep(2);
            kill(c1, SIGCONT); 
            // sleep(2);
            kill(c1, SIGSTOP); 
            kill(c2, SIGCONT); 
            // sleep(2);
            kill(c2, SIGSTOP); 
            // sleep(2);
            //kill(JJ_child3, SIGSTOP); 
            printf("process PID : %d\n", getpid());
            sleep(2);
        }
   }
    return 1;
}
