#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>

int child1;
int child2;

int main(int argc, char const *argv[])
{
    child1=fork();
    child2=fork();
    if (child1=0 && child2>0)
    {
        printf("From process %d\n",child1);
        sleep(2);
    }
    if (child1>0 && child2==0)
    {
        printf("From process %d\n",child2);
    }
    for(;;);
    return 0;
    
}
