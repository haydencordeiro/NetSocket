#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

int flag = 1;
int p1;
int p2;
void signint()
{
    if(p1 == p2){
        exit(0);
    }
    flag = 0;
}
int main()
{
    p1 = fork();
    p2 = fork();
    signal(SIGINT, signint);
    while (flag)
    {
        printf("From process (%d)\n", getpid());
        sleep(2);
    }

    while (1)
    {
        if (p1 > 0 && p2 > 0)
        {
            printf("From process (%d)\n", getpid());
            sleep(2);
            kill(p2, SIGCONT);
            kill(getpid(),SIGSTOP);
        }

        if (p1 == 0 && p2 > 0)
        {
            kill(getpid(),SIGSTOP);
            printf("From process (%d)\n", getpid());
            sleep(2);
            kill(getppid(),SIGCONT);
        }
        if (p1 > 0 && p2 == 0)
        {
            kill(getpid(),SIGSTOP);
            printf("From process (%d)\n", getpid());
            sleep(2);
            kill(p1,SIGCONT);


        }
        sleep(2);
    }
}