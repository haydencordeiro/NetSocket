#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

int main()
{
    int pipe1[2];
    if (pipe(pipe1) == -1)
    {
        printf("error creating pipe");
        exit(0);
    }

    int pipe2[2];
    if (pipe(pipe2)==-1)
    {
        printf("error creating pipe2");
        exit(0);
    }

    int a=fork();
    if (a>0)//parent
    {
        close(pipe1[0]);//close read
        dup2(pipe1[1],1);//write into pipe
        execlp("cat","cat","w24.txt",NULL);// redirecting output to pipe1
    }
    if (a==0)
    {
        // child1
        close(pipe1[1]);//close write since reading only
        if (a>0)
        {
            /* code */
        }
        
        
        
    }
    
    
    
}