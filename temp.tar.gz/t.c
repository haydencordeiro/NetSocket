#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_STRING_LENGTH 100

char* generate_unique_string() {
    char* unique_string = (char*)malloc(MAX_STRING_LENGTH * sizeof(char));

    // Generate random number
    int random_number = 100000000 + rand() % 900000000; // Generates a 9-digit number

    // Concatenate random number with the specified format
    snprintf(unique_string, MAX_STRING_LENGTH, "%d.tar.gz", random_number);

    return unique_string;
}

int main() {
    // Seed the random number generator
    srand(time(NULL));

    // Generate unique string
    char* unique_string = generate_unique_string();

    printf("Unique string: %s\n", unique_string);

    // Remember to free the memory allocated for the unique string
    free(unique_string);

    return 0;
}
