#define _XOPEN_SOURCE 500
#include <stdint.h>
#include <ftw.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>


#define MAX_TOKENS 100 // Maximum number of tokens
char *tokens[MAX_TOKENS];
int numTokens;
// Helper function to tokenize a string by removing "/"
int tokenizeString(const char *str) {
    // Create a copy of the input string to avoid modifying the original
    char *strCopy = strdup(str);

    // Tokenize the string using strtok
    char *token = strtok(strCopy, "/");
    int count = 0;
    while (token != NULL && count < MAX_TOKENS) {
        printf(" heloo :%s\n",token);
        tokens[count++] = strdup(token);
        token = strtok(NULL, "/");
        
    }

    free(strCopy); // Free the allocated memory for the copy

    return count; // Return the number of tokens
}

int callback2(const char *fpath, const struct stat *sb, int typeflag, struct FTW *ftwbuf) {
    return 1;
}

int isvalid(char *intermediatepath){ 
    if (nftw(intermediatepath, callback2, 20, FTW_DEPTH)!=-1)
    {

        return 1;
    }
    else
    {
        return 0;
    }
    
    
}

// Function to make directories given a path and directory name
int makeDirectories(char *path) {
    int status = mkdir(path, 0777); // Create directory with read, write, and execute permissions for owner, group, and others
    if (status == -1) {
        perror("mkdir");
        return 0; // Failed to create directory
    }
    return 1; // Directory created successfully
}
void constructPaths() {
    char path[MAX_TOKENS * (MAX_TOKENS + 1)]; // Maximum size of path
    path[0] = '\0'; // Initialize path
    for (int i = 0; i < numTokens; i++) {
        strcat(path, "/"); // Add "/" separator
        strcat(path, tokens[i]); // Concatenate token
        // printf("%s\n", path); // Print path
        if (isvalid(path))
        {
            printf("path valid %s \n",path);
        }
        else
        {
            printf("making directory");
            makeDirectories(path);
        }
        
        
    }
}





int main() {
    char *storageDirPath = "/home/jivin/Desktop/holo/hayden";
    // Tokenize the storage directory path
    numTokens = tokenizeString(storageDirPath);

    // Print the tokens
    // printf("Tokens:\n");
    // for (int i = 0; i < numTokens; i++) {
    //     printf("%s\n", tokens[i]);
    // }
    constructPaths();

    // char* intermediatepath="/home/jivin/Desktop/dump";
    // printf("%s\n",intermediatepath);
    // isvalid(intermediatepath);
    char* createfolderpath="/home/jivin/Desktop/new_folder";
    // makeDirectories(createfolderpath);

    return 0;
}
