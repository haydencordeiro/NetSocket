#define _XOPEN_SOURCE 500
#include <ftw.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

int callback(const char *fpath, const struct stat *sb, int typeflag, struct FTW *ftwbuf) {
    printf("%d");
    printf("%s\n", fpath);
    return 0;  // Continue traversal
}

int main(int argc, char *argv[]) {
    const char *dirpath = "/home";

    printf("%s",argv[1]); 
    
    int result = nftw(dirpath, callback, 20, FTW_PHYS);

    if (result == -1) {
        perror("nftw");
        return 1;
    }

    return 0;
}
