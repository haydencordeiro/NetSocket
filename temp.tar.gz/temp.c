else if (strstr(command, "w24ft") !=NULL)
        {
            // char *temp = runPopen("find ~ -type f -size +50000c -size -52000c  -name '*.pdf'");
            // char *temp = runPopen("find ~ -type f -size +50500c -size -50800c");
            // char *temp = runPopen("find ~ -type f -size +50000c -size -52000c");
            // char *temp;
            char *find_command = construct_w24ft_command(command);
            if (find_command == NULL) {
                printf("No extension provided.\n");
                exit(0);
            }  
            printf("Constructed command:\n %s \n", find_command);
            // find ~/Desktop/asp/asplab6 -type f \( -name '' -o -name '*.c' -o -name ''  \)
            char * temp2;
            asprintf(&temp2, "find ~/Desktop/asp/asplab6 -type f \( -name '' -o -name '*.c' -o -name ''  \)");
            char *temp = runPopen(temp2);
            // char *temp = runPopen(find_command);
            // char *temp = runPopen("find ~/Desktop/asp/asplab6 -type f \\( -name '*.c'  \\)");
            printf("files %s\n",temp);
            free(find_command); // Free the allocated memory              
            int length = strlen(temp);
            printf("length %d\n",length);
            // printf("no files %d\n",length);
            if (length==0)
            {
                printf("no file found\n");
                // return;
                // its not return
            }
            else{
                printf("%s\n",temp);
                createTheTar(resolve_paths(temp));
                // sendString(new_socket, temp);
                // free(temp);
                printf("server\n");
                sendFile(new_socket);
            }

        }