// sequential done with version2 optimieze of tokenizecommand
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <pwd.h>

#define MAX_TOKENS 100
#define MAX_TOKEN_LEN 50
#define COMMAND_LENGTH 1000
#define MAX_PROCESS_COUNT 100
#define TOTAL_ARGUMENTS 5
char *terminal_id;
char *process_file;
int last_value;


//function to open new bash/terminal
void openNewTerminal()
{
    int pid = fork();

    if (pid > 0)
    {
        waitpid(pid, NULL, 0);
    }
    else
    {
        char *args[] = {"gnome-terminal", "--", "bash", "-c", "./a.out", NULL};
        if (execvp(args[0], args) == -1)
        {
            perror("execvp");
            exit(EXIT_FAILURE); 
        }                       
        printf("execvp");
        return 1;
    }
}

//tokenization logic for  && ||
char **separateAndStore(char *input) {
    char **output = (char **)malloc(MAX_TOKENS * sizeof(char *));
    if (output == NULL) {
        perror("Memory allocation failed");
        exit(EXIT_FAILURE);
    }

    int i = 0;
    int index = 0;
    int tokenStart = 0;
    int len = strlen(input);

    while (i < len && index < MAX_TOKENS - 1) {
        if (input[i] == '&' && input[i + 1] == '&' && (i + 2 == len || input[i + 2] == ' ')) {
            if (i > tokenStart) {
                output[index] = (char *)malloc((i - tokenStart + 1) * sizeof(char));
                if (output[index] == NULL) {
                    perror("Memory allocation failed");
                    exit(EXIT_FAILURE);
                }
                strncpy(output[index], input + tokenStart, i - tokenStart);
                output[index][i - tokenStart] = '\0';
                index++;
            }
            output[index] = (char *)malloc(3 * sizeof(char)); // Allocate memory for "&&"
            if (output[index] == NULL) {
                perror("Memory allocation failed");
                exit(EXIT_FAILURE);
            }
            strcpy(output[index], "&&");
            index++;
            i += 2; // Skip '&&'
            tokenStart = i + 1;
        } else if (input[i] == '|' && input[i + 1] == '|' && (i + 2 == len || input[i + 2] == ' ')) {
            if (i > tokenStart) {
                output[index] = (char *)malloc((i - tokenStart + 1) * sizeof(char));
                if (output[index] == NULL) {
                    perror("Memory allocation failed");
                    exit(EXIT_FAILURE);
                }
                strncpy(output[index], input + tokenStart, i - tokenStart);
                output[index][i - tokenStart] = '\0';
                index++;
            }
            output[index] = (char *)malloc(3 * sizeof(char)); // Allocate memory for "||"
            if (output[index] == NULL) {
                perror("Memory allocation failed");
                exit(EXIT_FAILURE);
            }
            strcpy(output[index], "||");
            index++;
            i += 2; // Skip '||'
            tokenStart = i + 1;
        }
        i++;
    }

    if (i > tokenStart) {
        output[index] = (char *)malloc((i - tokenStart + 1) * sizeof(char));
        if (output[index] == NULL) {
            perror("Memory allocation failed");
            exit(EXIT_FAILURE);
        }
        strncpy(output[index], input + tokenStart, i - tokenStart);
        output[index][i - tokenStart] = '\0';
        index++;
    }

    output[index] = NULL; // Null-terminate the array

    return output;
}

// function to count length of an array passed
int countLength(char **arr)
{
    int i = 0;
    while (arr[i] != NULL)
    {
        i += 1;
    }
    return i;
}

//tokenize based on delimiters specified
char **tokenizeCommand(char *str, char *delimiter)
{
    int count = 0;
    char **tokens = (char **)malloc(TOTAL_ARGUMENTS * sizeof(char *));
    if (tokens == NULL)
    {
        fprintf(stderr, "failed allocation\n");
        return NULL;
    }

    // Allocate memory for all tokens
    char *tokenized_str = strdup(str);
    if (tokenized_str == NULL)
    {
        fprintf(stderr, "failed allocation\n");
        free(tokens);
        return NULL;
    }

    // Tokenize the string
    char *token = strtok(tokenized_str, delimiter);
    while (token != NULL)
    {
        // Remove leading spaces
        while (isspace(*token))
            token++;

        // Remove trailing spaces
        int end = strlen(token) - 1;
        while (end >= 0 && isspace(token[end]))
            end--;
        token[end + 1] = '\0';

        // Copy token to tokens array
        tokens[count++] = strdup(token);

        token = strtok(NULL, delimiter);
    }
    tokens[count] = NULL;
    // free(tokenized_str);
    return tokens;
}

// remove extra space
char *trimString(char *str) {
    char *end;

    // Skip leading spaces
    while (isspace((unsigned char)*str))
        str++;

    // If the string is empty or contains only spaces
    if (*str == '\0')
        return str;

    // Trim trailing spaces
    end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char)*end))
        end--;

    // Null-terminate the trimmed string
    *(end + 1) = '\0';

    return str;
}

// read background processes from the file 
void readTopmostBgProcess(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Unable to open file.\n");
        return;
    }

    // Read values from the file
    int values[1000];
    int count = 0;
    while (fscanf(file, "%d", &values[count]) == 1) {
        count++;
    }

    if (count > 0) {
        // Get the last value
        last_value = values[count - 1];

        // Rewind the file to overwrite it
        fclose(file);
        file = fopen(filename, "w");

        // Write the remaining values back to the file, excluding the last one
        for (int i = 0; i < count - 1; i++) {
            fprintf(file, "%d\n", values[i]);
        }
    } else {
        printf("File is empty.\n");
    }

    fclose(file);
}

// function to generate unique id for bash 
char* generateRandomStringForBashId(int length) {
    const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    char* randomString = (char*)malloc((length + 5) * sizeof(char)); // Additional space for ".txt\0"
    if (randomString == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(1);
    }

    srand((unsigned int)time(NULL));

    for (int i = 0; i < length; ++i) {
        randomString[i] = charset[rand() % (sizeof(charset) - 1)];
    }

    // Append ".txt" at the end
    strcpy(randomString + length, ".txt");

    return randomString;
}

// check if the filename exists or not 
int checkIfFilePresent(const char *filename) {
    // Check if the file exists by trying to access it in read mode
    if (access(filename, F_OK) != -1) {
        return 1;
    } else {
        return 0;
    }
}

// tokenize string based on delimiter specified
char** tokenizeString(const char* str, const char* delimiter) {
    char** tokens = NULL;
    char* token = strtok(strdup(str), delimiter);
    int tokenCount = 0;

    // Count tokens
    while (token != NULL) {
        token = strtok(NULL, delimiter);
        tokenCount++;
    }

    // Allocate memory for token array
    tokens = (char**)malloc(tokenCount * sizeof(char*));
    if (tokens == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(1);
    }

    // Split string and store tokens
    token = strtok((char*)str, delimiter);
    for (int i = 0; i < tokenCount; i++) {
        // Strip leading spaces
        while (isspace(*token)) {
            token++;
        }

        // Strip trailing spaces
        char* end = token + strlen(token) - 1;
        while (end > token && isspace(*end)) {
            *end = '\0';
            end--;
        }

        tokens[i] = token;
        token = strtok(NULL, delimiter);
    }

    return tokens;
}



// function to read  read process id from file
int* readProcessIDsFromFile(const char* filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        fprintf(stderr, "Error opening file: %s\n", filename);
        exit(1);
    }

    // Allocate memory for storing process IDs
    int* processIDs = (int*)malloc(MAX_PROCESS_COUNT * sizeof(int));
    if (processIDs == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(1);
    }

    int count = 0;
    int id;
    // Read process IDs from the file
    while (fscanf(file, "%d", &id) == 1) {
        processIDs[count] = id;
        (count)++;
        if (count >= MAX_PROCESS_COUNT) {
            fprintf(stderr, "Maximum number of process IDs exceeded\n");
            exit(1);
        }
    }

    fclose(file);
    return processIDs;
}

// kill recent process using ctrcl
int handler(){
        if (last_value!=0)
        {
            kill(last_value, SIGINT);
        }
    printf("\n");
}

// function to write process id  to file
void writeProcessIDToFile(const char* filename, int processID) {
    FILE *file = fopen(filename, "a"); // Open file in append mode
    if (file == NULL) {
        fprintf(stderr, "Error opening file: %s\n", filename);
        return;
    }

    // Write process ID to file
    fprintf(file, "%d\n", processID);

    fclose(file);
}

//function to add cat prefix to a string replacing  #
char **addCatPrefix(char **array, size_t size) {
    // Allocate memory for the modified array
    char **result = malloc(size * sizeof(char *));
    if (result == NULL) {
        fprintf(stderr, "Memory allocation error\n");
        return NULL;
    }

    // Prefix "cat " to each string in the original array
    for (size_t i = 0; i < size; i++) {
        size_t prefix_len = strlen("cat ");
        size_t str_len = strlen(array[i]);
        result[i] = malloc((prefix_len + str_len + 1) * sizeof(char));
        if (result[i] == NULL) {
            // Free previously allocated memory
            for (size_t j = 0; j < i; j++) {
                free(result[j]);
            }
            free(result);
            fprintf(stderr, "Memory allocation error\n");
            return NULL;
        }
        strcpy(result[i], "cat ");
        strcat(result[i], array[i]);
    }

    return result;
}

// function to process commands.
void handleCommands(char *command, char *terminal_id){
    if (strstr(command,"fg")!=NULL)
    {
        if (!checkIfFilePresent(terminal_id))
        {
            printf("file does not exist\n");
            return;
        }
        readTopmostBgProcess(terminal_id);
        waitpid(last_value,NULL,0);
        
    }
    else if (strstr(command, "&&") != NULL || strstr(command, "||") != NULL)
    {
        char **output = separateAndStore(command);
        int len=countLength(output);
        int pid = fork();
        if (pid > 0)
        {
            waitpid(pid, NULL, 0);

        }
        else
        {
            runChainingAndOr(output, len);
            exit(0);
        }
    }
    else if (strstr(command,"&")!=NULL)
    {

        char **strings = tokenizeString(command, "&");
        signal(SIGINT, handler);
        int child = fork();
        if (child > 0)
        {
            if (strlen(strings[0]) > 0)
                writeProcessIDToFile(terminal_id,child);
        }
        if (child == 0)
        {
            if (setpgid(0, 0) == -1)
            {
                return 1;
            }
            if (strlen(strings[0]) > 0)
                runCommand(strings[0]);
        }
    }
    else if (strstr(command, ">>") != NULL)
    {
        char **strings = tokenizeCommand(command,">>");
        char **execstring=tokenizeCommand(strings[0]," ");
        int len2=countLength(execstring);
        int len=countLength(strings);
        
        int child=fork();
        if ( child == 0)
        {
            int fd =open(strings[1], O_CREAT|O_RDWR | O_APPEND, 0777);
            dup2(fd, 1);
            execvp(execstring[0],execstring);
            close(fd);
        }
        else
        {
            // wait(NULL);
            waitpid(child, NULL, 0);
        }
    }
    else if (strstr(command, ">") != NULL)
    {
        char **strings = tokenizeCommand(command,">");
        char **execstring=tokenizeCommand(strings[0]," ");
        int len2=countLength(execstring);
        int len=countLength(strings);
        
        int child=fork();
        if ( child == 0)
        {
            
            int fd =open(strings[1], O_CREAT|O_RDWR, 0777);
            close(fd);
            unlink(strings[1]);
            int fd2 =open(strings[1], O_CREAT|O_RDWR, 0777);
            dup2(fd2, 1);
            execvp(execstring[0],execstring);
            close(fd2);
        }
        else
        {
            waitpid(child, NULL, 0);
        }
    }
    else if(strstr(command, "<") != NULL)
    {
        char **strings = tokenizeCommand(command,"<");
        char **execstring=tokenizeCommand(strings[0]," ");
        int len2=countLength(execstring);
        int len=countLength(strings);
        
        int child=fork();
        if ( child == 0)
        {
            
            int fd =open(strings[1], O_RDONLY, 0777);
            dup2(fd, 0);
            execvp(execstring[0],execstring);
            close(fd);
        }
        else
        {
            waitpid(child, NULL, 0);
        }
    }
    else if (strstr(command, ";") != NULL)
    {
        char **strings = tokenizeCommand(command,";");
        int len=countLength(strings);
        execute(strings,len,0);
    }
    else if (strstr(command, "#") != NULL)
    {
        char **strings = tokenizeCommand(command,"#");
        int len=countLength(strings);
        char **modified_array = addCatPrefix(strings, len);
        execute(modified_array,len,0);
        printf("\n");

        
        
    }
        else if (strstr(command, "|") != NULL)
    {
        char **strings = tokenizeCommand(command,"|");
        int len=countLength(strings);
        chainPipes(strings, len);    
    }     
    else if (strstr(command, "exit\n") != NULL)
    {
        unlink(terminal_id);
        exit(0);
    }
    else if (strstr(command, "newt") != NULL)
    {
        openNewTerminal();
    }
    else
    {
        forkCommand(trimString(command));
    }  
}

// Helper method to run sequential piping operations and redirecting output of first to the next pipe until the end
void chainPipes(char **commands, int len)
{
    
    int count=0;
    int pp[2], np[2];

    while (count < len)
    {
        if (count < len - 1 && pipe(np) == -1)
        {
            exit(1);
        }

        int child = fork();
        if (child > 0)
        { 
            if (count < len - 1)
            {
                pp[0] = np[0];
                pp[1] = np[1];
            }
        }
        else
        {
            if (count > 0){
                dup2(pp[0], 0);  
            }
            if (count < len - 1){
                dup2(np[1], 1);
            }
            runCommand(commands[count]);
            exit(0);
        }
        waitpid(child,NULL,0);
        count++;
    }
}

// run execvp
int runCommand(const char *command) {
    // Duplicate the command
    char *args[COMMAND_LENGTH];
    int i = 0;

    // Tokenize the input command based on space
    char *token = strtok(strdup(command), " ");
    while (token != NULL) {
        args[i++] = token;
        token = strtok(NULL, " ");
    }
    args[i] = NULL; // Set the last argument to NULL

    // Execute the command using execvp
    if (execvp(args[0], args) == -1) {
        printf("Command '%s' not found\n", args[0]);
        return 0;
    }
}

//  function to chain && || chaining function
void runChainingAndOr(char **commands, int num_commands)
{
    // Runs the first command
    int prev = forkCommand(commands[0]);

    // Iterate through commands
    for (int i = 1; i < num_commands; i += 2)
    {
        if (prev == 1 && strstr(commands[i], "&&") != NULL)
        {
            prev = runCommand(trimString(commands[i + 1])) == 0 ? 0 : 1;
        }
        else if (prev == 0 && strstr(commands[i], "||") != NULL)
        {
            prev = runCommand(trimString(commands[i + 1])) == 0 ? 0 : 1;
        }
    }
}

// Executes commands sequentially
void execute(char **commands, int len, int stopOnFailure)
{   
    int i=0;
    while(i<len)
    {
        int pid = fork();
        if(pid>0)
        {
            int status;
            wait(&status);
            if (WEXITSTATUS(status) == 30)
            {
                if (stopOnFailure)
                    break;
            }
        }
        else
        { // Child process

            if (runCommand(commands[i]) == 0)
            {
                printf("%s command failed to execute \n", commands[i]);
                exit(30);
            }
        }
    i++;
    }
}

// Uses the runCommand function to execute command, alonside also returns a status of exectuion of the command
int forkCommand(char *command)
{
    // Fork a child process
    int pid = fork();
    if (pid == -1)
    {
        printf("Failed to fork");
        exit(0);
    }
    else if (pid > 0)
    { // parent
                int status;
        waitpid(pid, &status, NULL);
        if (WIFEXITED(status))
        {
            if(WEXITSTATUS(status) == 0){
            return 1;
            }
        }
        return 0;
    }
    else
    {

        // Execute the command
        if (runCommand(command) == 0)
        {
            // In case of failure return -1
            exit(30);
        }

    }
}

void handleCd(char* input)
{
    // Assuming a maximum of 64 arguments
    char* args[64];
    char* token;
    int i = 0;
    
    // Tokenize the input command
    token = strtok(input, " ");
    while (token != NULL)
    {
        args[i++] = token;
        token = strtok(NULL, " ");
    }
    args[i] = NULL;
    
    // Check if the second argument is present and non-empty
    if (args[1] == NULL || args[1][0] == '\0')
    {
        return;
    }
    
    // Get the path to change directory to and trim leading/trailing spaces
    char* cdPath = trimString(args[1]);

    // Handle '~' expansion
    if (cdPath[0] == '~')
    {
        char* homeDir = getenv("HOME");
        if (homeDir == NULL)
        {
            struct passwd* pw = getpwuid(getuid());
            if (pw != NULL)
            {
                homeDir = pw->pw_dir;
            }
            else
            {
                fprintf(stderr, "Error: Cannot determine home directory.\n");
                return;
            }
        }
        // Construct the full path
        size_t homeDirLen = strlen(homeDir);
        size_t cdPathLen = strlen(cdPath + 1); // Skip '~'
        char fullPath[homeDirLen + cdPathLen + 1]; // +1 for null terminator
        snprintf(fullPath, sizeof(fullPath), "%s/%s", homeDir, cdPath + 1);
        cdPath = fullPath;
    }

    // Change directory
    if (chdir(cdPath) == -1)
    {
        perror("chdir");
    }

    // Free dynamically allocated memory
    free(cdPath);
}

int start(){
    char command[COMMAND_LENGTH];
    terminal_id = generateRandomStringForBashId(10);
     while (strcmp(command, "exit\n") != 0)
    {
        printf("shell24$ ");
        fgets(command, COMMAND_LENGTH, stdin);
        if (strstr(strdup(command), "cd") != NULL)
        {
            handleCd(command);
            continue;
        }
        handleCommands(command, terminal_id);
    }
    unlink(terminal_id);
    return 0;
    
}

int main(int argc, char const *argv[])
{
    signal(SIGINT,handler);
    start();
    unlink(terminal_id);
    return 0;
}
