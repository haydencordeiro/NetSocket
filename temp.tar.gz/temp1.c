#define _XOPEN_SOURCE 500
#include <stdint.h>
#include <ftw.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Global variable to store the target filename
const char *targetFilename = "temp.c";

int callback(const char *fpath, const struct stat *sb, int typeflag, struct FTW *ftwbuf) {
    // Extract the filename from the full path
    const char *filename = strrchr(fpath, '/');
    if (filename == NULL) {
        // No '/' found in the path, use the whole path as the filename
        filename = fpath;
    } else {
        // Move one character ahead to skip the '/'
        filename++;
    }

    // Check if the current filename matches the target filename
    if (strcmp(filename, targetFilename) == 0) {
        printf("Found the target file: %s\n", fpath);
        // Optionally, you can return a non-zero value to stop the traversal
        return 1;
    }

    // Continue traversal
    return 0;
}

int main() {
    const char *dirpath = "/home";
    int result = nftw(dirpath, callback, 20, FTW_PHYS);

    if (result == -1) {
        perror("nftw");
        return 1;
    }

    return 0;
}