#define _XOPEN_SOURCE 500
#include <stdint.h>
#include <ftw.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Global variable to store the target directory path
const char *targetDirectoryPath = NULL;

int nftwCallbackFunction(const char *fpath, const struct stat *sb, int typeflag, struct FTW *ftwbuf) {
    // Your callback logic here

    // Check if the current entry is a directory
    if (typeflag == FTW_D) {
        // Assuming you want to stop the traversal when the target directory is found
        if (strcmp(fpath, targetDirectoryPath) == 0) {
            // Optionally, you can store the path or perform any desired action
            printf("Found the target directory: %s\n", fpath);
            // Return a non-zero value to stop the traversal
            return 1;
        }
    }

    // Continue traversal
    return 0;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <directory_path> <target_directory_name>\n", argv[0]);
        return 1;
    }

    const char *dirpath = argv[1];
    const char *targetDirectoryName = argv[2];

    // Set the global variable with the full path of the target directory
    asprintf((char **)&targetDirectoryPath, "%s/%s", dirpath, targetDirectoryName);

    int result = nftw(dirpath, nftwCallbackFunction, 20, FTW_PHYS);

    // Free the memory allocated for the target directory path
    free((void *)targetDirectoryPath);

    if (result == -1) {
        perror("nftw");
        return 1;
    }

    return 0;
}
