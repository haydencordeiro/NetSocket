#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_TOKENS 100
#define MAX_TOKEN_LEN 50

// Function to separate input based on '&&' and '||' and store in an array
void separateAndStore(char *input, char *output[]) {
    int i = 0;
    int index = 0;
    int tokenStart = 0;
    int len = strlen(input);

    while (i < len && index < MAX_TOKENS - 1) {
        if (input[i] == '&' && input[i + 1] == '&' && (i + 2 == len || input[i + 2] == ' ')) {
            if (i > tokenStart) {
                output[index] = malloc((i - tokenStart + 1) * sizeof(char));
                if (output[index] == NULL) {
                    perror("Memory allocation failed");
                    exit(EXIT_FAILURE);
                }
                strncpy(output[index], input + tokenStart, i - tokenStart);
                output[index][i - tokenStart] = '\0';
                index++;
            }
            output[index++] = "&&";
            i += 2; // Skip '&&'
            tokenStart = i + 1;
        } else if (input[i] == '|' && input[i + 1] == '|' && (i + 2 == len || input[i + 2] == ' ')) {
            if (i > tokenStart) {
                output[index] = malloc((i - tokenStart + 1) * sizeof(char));
                if (output[index] == NULL) {
                    perror("Memory allocation failed");
                    exit(EXIT_FAILURE);
                }
                strncpy(output[index], input + tokenStart, i - tokenStart);
                output[index][i - tokenStart] = '\0';
                index++;
            }
            output[index++] = "||";
            i += 2; // Skip '||'
            tokenStart = i + 1;
        }
        i++;
    }

    if (i > tokenStart) {
        output[index] = malloc((i - tokenStart + 1) * sizeof(char));
        if (output[index] == NULL) {
            perror("Memory allocation failed");
            exit(EXIT_FAILURE);
        }
        strncpy(output[index], input + tokenStart, i - tokenStart);
        output[index][i - tokenStart] = '\0';
        index++;
    }

    output[index] = NULL; // Null-terminate the array
}

int main() {
    char input[] = "ls -1 -t && yoloy && grep a.c && folor";
    char *output[MAX_TOKENS];

    separateAndStore(input, output);

    // Printing the stored tokens
    for (int i = 0; output[i] != NULL; i++) {
        printf("%s\n", output[i]);
        // No need to free the memory, as no dynamic allocation is done
    }

    // char input[MAX_CMD_LEN]; // Assuming a maximum input length of 1000 characters
    // char *bashID = generateBashID();
    while (strcmp(input, "exit\n") != 0)
    {
        // Prompt the user for input
        printf("Enter a command: ");

        // Read the input from the user
        fgets(input, MAX_CMD_LEN, stdin);

        // Fork a process to handle the request
        int pid = fork();
        if (pid < 0)
        {
            // Error occurred while forking
            perror("fork");
            exit(EXIT_FAILURE);
        }
        else if (pid == 0)
        {
            // Child process
            handle_string(input, bashID);
            exit(0);
        }
        else
        {
            // Parent process
            // Wait for the child process to finish
            int status;
            wait(&status);
        }
    }
    return 0;
}
