#define _XOPEN_SOURCE 500
#include <stdint.h>
#include <ftw.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
const char *target;
int found = 0;
const char *targetDirectoryName=NULL;
// Callback function that checks if the current filename matches the target filename
int nftwCallbackFunction(const char *fpath, const struct stat *sb, int typeflag, struct FTW *ftwbuf) {
    // Extract the filename from the full path
    const char *filename = strrchr(fpath, '/');

    if (filename == NULL) {
        // No '/' found in the path, use the whole path as the filename
        filename = fpath;
    } else {
        // Move one character ahead to skip the '/'
        filename++;
    }

    // Check if the current filename matches the target filename
    if (strcmp(filename, target) == 0) {
        
        printf("Found the target file: %s\n", fpath);
        found=1;
        // Optionally, you can return a non-zero value to stop the traversal
        return 1;
    }

    // Continue traversal
    return 0;
}


int nftwCallbackFunction2(const char *fpath, const struct stat *sb, int typeflag, struct FTW *ftwbuf) {
    // Your callback logic here

    // Check if the current entry is a directory
    if (typeflag == FTW_D) {
        // printf("HELLO");
        // printf("%s",fpath);
        // printf("%s",targetDirectoryName);
        // Assuming you want to stop the traversal when the target directory is found
        if (strcmp(fpath, targetDirectoryName) == 0) {
            printf("OLA");
            // Optionally, you can store the path or perform any desired action
            printf("Found the target directory: %s\n", fpath);
            // Return a non-zero value to stop the traversal
            return 1;
        }
    }

    // Continue traversal
    return 0;
}

int main(int argc, char *argv[]) {
    // #refactor this if condition
    if (argc != 4) {
        fprintf(stderr, "Usage: %s <directory_path> <target_filename> <target_directory name>\n", argv[0]);
        return 1;
    }

    const char *path = argv[1];
    target = argv[2];
    targetDirectoryName=argv[3];
    int result = nftw(path, nftwCallbackFunction, 20, FTW_PHYS);

    if (result == -1) {
        perror("nftw");
        return 1;
    }
    // if file not found 
    if (found==0)
    {
        printf("file not found in the system");
    }

    int result1 = nftw(path, nftwCallbackFunction2, 20, FTW_PHYS);
    



    return 0;
}