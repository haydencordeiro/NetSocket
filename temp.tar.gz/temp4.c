#include <stdio.h>

void writeProcessIDToFile(const char* filename, int processID) {
    FILE *file = fopen(filename, "a"); // Open file in append mode
    if (file == NULL) {
        fprintf(stderr, "Error opening file: %s\n", filename);
        return;
    }

    // Write process ID to file
    fprintf(file, "%d\n", processID);

    fclose(file);
}

int main() {
    const char* filename = "sample.txt"; // Change this to your file name
    int processID = 123; // Example process ID to write
    
    // Write the process ID to the file
    writeProcessIDToFile(filename, processID);
    
    printf("Process ID %d written to file %s\n", processID, filename);

    return 0;
}
