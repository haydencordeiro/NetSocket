#include<stdio.h>
int main(){
    while (1)
    {
        sleep(2);
        printf("helloo\n");
    }
    return 0;
}
