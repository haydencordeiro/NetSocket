#include <stdio.h>
#include <stdlib.h>

int main() {
    // Specify the source and destination file paths
    const char *sourceFile = "~/a.txt";
    const char *destinationFile = "/home/jivin/Desktop/asp/assignment/dummy/akshar.txt";

    // Construct the copy command
    char copyCommand[256];
    snprintf(copyCommand, sizeof(copyCommand), "cp %s %s", sourceFile, destinationFile);

    // Use the system function to execute the copy command
    int result = system(copyCommand);

    // Check the result of the system call
    if (result == 0) {
        printf("File copied successfully.\n");
    } else {
        fprintf(stderr, "Error copying the file.\n");
    }

    return 0;
}