#include <stdio.h>

int last_value;

void read_last_value_and_remove(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Unable to open file.\n");
        return;
    }

    // Read values from the file
    int values[1000]; // Assuming maximum 1000 values
    int count = 0;
    while (fscanf(file, "%d", &values[count]) == 1) {
        count++;
    }

    if (count > 0) {
        // Get the last value
        last_value = values[count - 1];

        // Rewind the file to overwrite it
        fclose(file);
        file = fopen(filename, "w");

        // Write the remaining values back to the file, excluding the last one
        for (int i = 0; i < count - 1; i++) {
            fprintf(file, "%d\n", values[i]);
        }
    } else {
        printf("File is empty.\n");
    }

    fclose(file);
}

int main() {
    const char *filename = "sample.txt";
    read_last_value_and_remove(filename);
    printf("Last value: %d\n", last_value);
    return 0;
}
