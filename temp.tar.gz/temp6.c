#define _XOPEN_SOURCE 500
#include <stdint.h>
#include <ftw.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char *target;
int found = 0;
int flag3=0;//for argument 3 when i have to print all files 
char *sourcefilepath;

#define MAX_PATHS 1000
char *filePaths[MAX_PATHS]; 
int numPaths = 0;
char *filenames[MAX_PATHS];
int counter=0;


// Callback function that checks if the current filename matches the target filename
int nftwCallbackFunction(const char *fpath, const struct stat *sb, int typeflag, struct FTW *ftwbuf) {
    // Extract the filename from the full path
    const char *filename = strrchr(fpath, '/');

    if (filename == NULL) 
    {
        // No '/' found in the path, use the whole path as the filename
        filename = fpath;
    } 
    else 
    {
        // Move one character ahead to skip the '/'
        filename++;
    }

    // Check if the current filename matches the target filename
    if (strcmp(filename, target) == 0) 
    {   
        if(flag3 == 1){
        printf("Search Successful: %s\n", fpath);
        }
        if(flag3 == 5){
        printf("Search Successful\n");
        }
        
        // copying filepath to global variable to use later
        size_t fpathLength = strlen(fpath);
        sourcefilepath = (char *)malloc(fpathLength + 1); //+1
        strcpy(sourcefilepath, fpath);

        // printf("Found the target file: %s\n", sourcefilepath);  
        
        // Optionally, you can return a non-zero value to stop the traversal
        found=1;
        // if (!(flag3==1))
        // {
            return 1;
        // }
        
    }

    // Continue traversal
    return 0;
}

int callNftwToFindFilePath(char *path, char *val){
        if(strcmp(val,"") != 0){
            flag3=0;
        }
        int result = nftw(path, nftwCallbackFunction, 20, FTW_DEPTH);
        // FTW_PHYS
        // FTW_DEPTH
        // printf("%s %d \n", path ,result);
        if (result == -1)
        {
            // perror("nftw");
            // return 1;
            if (strcmp(val,"root") == 0)
            {
                printf("Invalid root_directory\n");
            }
            if (strcmp(val,"storage") == 0)
            {
                printf("Invalid storage_directory\n");
            }
            exit(0);
            
        }
        // if file not found 
        if (found==0)
        {
            printf("Search Unsuccessful\n");
            exit(0);
        }
}

int copyfile(char *storage_dir){
    char *runcopy;
    // printf("cp %s %s/", sourcefilepath, storage_dir);
    asprintf(&runcopy, "cp %s %s", sourcefilepath, storage_dir);

    // Use the system function to execute the copy command
    // int flag=1;
    int flag = system(runcopy);
    free(runcopy);
    // Check the system call for error.
    if (flag == 0) {
        printf("File copied to the storage_dir\n");
    } else {
        fprintf(stderr, "file not copied\n");
    }
}

int movefile(char *storage_dir){
    char *runmove;
    asprintf(&runmove, "mv %s %s", sourcefilepath, storage_dir);
    // Use the system function to execute the move command
    int flag = system(runmove);
    free(runmove);
    // Check the system call for error.
    if (flag == 0) {
        printf("File moved to storage_dir\n");
    } else {
        fprintf(stderr, "file not found\n");
    }
}

// helper function to append slash at end of the string in not 
char* addSlash(const char* path) {
    char* newpath = (char*)malloc(strlen(path) + 2);
    strcpy(newpath, path);
    int len = strlen(newpath);
    if (newpath[len - 1] != '/') 
    {
        strcat(newpath, "/");
    }
    return newpath;
}

// Function to check if a file name has a specific extension
int hasExtension(const char *filename, const char *extension) {
    const char *dot = strrchr(filename, '.'); // Find the last '.' in the filename
    if (dot != NULL && strcmp(dot, extension) == 0) {
        return 1; // Extension found
    }
    return 0; // Extension not found
}

int filenameExists(char *filename) {
    for (int i = 0; i < counter; i++) {
        if (strcmp(filename, filenames[i]) == 0) {
            return 1; // Filename exists in the array
        }
    }
    return 0; // Filename does not exist in the array
}

// nftw callback function
int callback(const char *fpath, const struct stat *sb, int typeflag, struct FTW *ftwbuf) {
    if (typeflag == FTW_F) { // Check if it's a regular file
        const char *filename = strrchr(fpath, '/');
        if (filename == NULL) {
            filename = fpath; // If no '/', use the full path as the filename
        } else {
            filename++; // Move one character ahead to skip the '/'
        }
        // Check if the file has the ".pdf" extension
        // printf(" FILE NAME: %s\n\n",filename);
      

        if (hasExtension(filename, target)) {
            // printf("%s %d\n", fpath,filenameExists(filename));

            if (filenameExists(filename)==0)
            {
                filePaths[numPaths] = strdup(fpath);
                printf(" EXTENSION %s\n",filePaths[numPaths]);
                numPaths++;
            }                     
// 
            filenames[counter] = strdup(filename);
            counter++;  
// 
        }
    }
    return 0; // Continue traversal
}

int main(int argc, char *argv[]) {
    // if needed move the variable into if or dont for now
    int result;

    //part 1 printf file and extracting source file path into a global varaible called source filepath
    if (argc == 3) 
    {   
        flag3=1;
        char *path = addSlash(argv[1]);
        // printf("%s",path);
        target = argv[2];
        callNftwToFindFilePath(path,"");
        // printf("yolo\n");
        // printf("%s",sourcefilepath);
    }

    else if(argc == 5)
    {
        // fileutil [root_dir] [storage_dir] [options] filename
        //   0            1           2           3       4
        char *path =  addSlash(argv[1]);
        target = argv[4];
        char *options=argv[3];
        char *storage_dir=addSlash(argv[2]);
        
        // check if valid root_dir
        callNftwToFindFilePath(path,"root");
        
        // check if valid storage_dir
        callNftwToFindFilePath(storage_dir,"storage");

        //find path and store in sourcefilepath
        flag3 = 5;
        callNftwToFindFilePath(path,"");
        
        if (strcmp(options,"-cp")==0)
        {   
            copyfile(storage_dir);
            
        }
        else if (strcmp(options,"-mv")==0)
        {
            movefile(storage_dir);
        }
        
        else{
            fprintf(stderr, " error: to move/copy a file -> Usage: %s [root_dir] [storage_dir] [options] filename\n options: copy: <-cp> move :<-mv> \n", argv[0]);
        }
    }
    else if (argc == 4)
    {
        // fileutil [root_dir] [storage_dir] extension
        //   0            1           2           3
        char *path = argv[1];
        char *storage_dir=argv[2];
        target=argv[3];
        // printf("%s",target);
        int result = nftw(path, callback, 20, FTW_DEPTH);
        if (result == -1) {
            perror("nftw");
            return 1;
        }
        // printf("hello\n");

        for (int i = 0; i < numPaths; i++)
        {
            // printf("hello: %s\n\n",filePaths[i]);
        }

        // for (int i = 0; i < counter; i++)
        // {
        //     printf("%s\n\n",filenames[i]);
        // }
        

        return 0;
    }
    else{
        fprintf(stderr, " to find a file -> Usage: %s [ root_dir] filename \n", argv[0]);
        fprintf(stderr, " to move/copy a file -> Usage: %s [root_dir] [storage_dir] [options] filename\n", argv[0]);
        fprintf(stderr, " to find a file -> Usage: %s  [root_dir] [storage_dir] [options] filename\n", argv[0]);
        return 1;
    }
    return 0;
}