#include <stdio.h>
#include <stdlib.h>

#define MAX_CHILD_PROCESSES 100

int* GetChild(int parent_id) {
    FILE *fp;
    char command[100];
    char line[100];
    int *child_pids = malloc(MAX_CHILD_PROCESSES * sizeof(int));
    int count = 0;

    // Construct the command
    snprintf(command, sizeof(command), "ps --ppid %d -o pid=", parent_id);

    // Open the command for reading
    fp = popen(command, "r");
    if (fp == NULL) {
        perror("popen");
        exit(EXIT_FAILURE);
    }

    // Read the output line by line and store the PIDs into the array
    while (fgets(line, sizeof(line), fp) != NULL) {
        // Convert the string representation of PID to integer
        int pid = atoi(line);
        // Store the PID into the array
        child_pids[count++] = pid;
        // Check if the array size exceeds the maximum limit
        if (count >= MAX_CHILD_PROCESSES) {
            fprintf(stderr, "Maximum number of child processes reached\n");
            break;
        }
    }

    // Close the file pointer
    pclose(fp);

    // Resize the array to the number of actual child processes found
    child_pids = realloc(child_pids, count * sizeof(int));

    return child_pids;
}

int main() {
    int parent_id = 2737; // Replace with actual parent process ID
    int *child_pids;
    int i;

    // Call GetChild function
    child_pids = GetChild(parent_id);

    // Print the child process IDs
    printf("Child process IDs of parent process %d:\n", parent_id);
    for (i = 0; child_pids[i] != 0; i++) {
        printf("%d\n", child_pids[i]);
    }

    // Free the dynamically allocated memory
    free(child_pids);

    return 0;
}

