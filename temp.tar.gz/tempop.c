#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int numPaths = 3;


int main() {
    // const char *archiveName = "archive.tar";
    // const char *files[] = {"file1", "file2"};
    // const int numFiles = sizeof(files) / sizeof(files[0]);
    // const char *directory = "directory/";

    const char *filepaths[] = {"The", "quick", "brown"};
    createTheTar("./",filepaths);

    // Generate the tar command
    const char *string1 = "Hello, ";
    const char *string2 = "world!";

    // // Call the function to concatenate the strings
    // char *result = concatenateStrings(string1, string2);
    // printf("%s\n",result);
    // // tar -cvf absolutepath+a1.tar ./temp.txt ./assignment1/temp.txt
    // int numPaths=3;
    // printStrings(filepaths,numPaths);
    return 0;
}