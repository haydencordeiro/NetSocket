#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>

int main(){
    umask(0000);
    int fd=open("stormfury.txt",O_CREAT|O_RDWR,0774);
    if (fd==-1)
    {
        printf("file couldnt be created successfully");
        return 0;
    }
    

    char* string;
    string="univ of windsor";
    // 
    printf("%d\n",fd);
    printf("%s\n",string);
    // 
    
    int w =write(fd,string,15);
    w=write(fd,string,15);
    w=write(fd,string,15);
    printf("value printed 3 times: length will be 45\n");

    close(fd);

    fd=open("stormfury.txt",O_RDWR);
    
    int offset= lseek(fd,10,SEEK_END);
    w=write(fd,string,15);
    w=write(fd,string,15);
    printf("length of entire string will be  85 at this point\n");
    offset= lseek(fd,10,SEEK_CUR);
    w=write(fd,string,15);
    w=write(fd,string,15);
    printf("length of entire string will be  125 at this point\n");
    // write into a list 
    char list[125];
    offset=lseek(fd,0,SEEK_SET);

    printf("offset %d",offset);

    int reading=read(fd,list,125);

    // printf("%s",list);

    for (int i = 0; i < 125; i++)
    {   
        // printf("%c ",list[i]);
        if (list[i]=='\0')
        {
            list[i]='#';
        }
    }
    offset=lseek(fd,0,SEEK_SET);
    w=write(fd,list,125);
    close(fd);
    
    return 0;
}