#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

main()
{
umask(0000);
int fd1=open("check420.txt", O_CREAT|O_RDWR,0744);
umask(0777);
fd1=open("check420.txt", O_CREAT|O_RDWR,0744);
}
