#include <stdio.h>

main()
{

 printf("\nwelcome to comp8657\n");
 
 }
